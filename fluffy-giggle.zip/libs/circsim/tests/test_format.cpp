// ws::circsim test suite. One binary for the whole lib (the workspace
// pattern): test_format.cpp (this file - the .csim format, and the doctest
// main), test_nets.cpp (connectivity), test_erc.cpp (one case per check),
// test_export.cpp (golden decks, analytic full-path runs, error mapping).
//
//   ctest --preset linux -R circsim

#include <string>

#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
// LOCAL SANDBOX NOTE (review build only, not a repo change): GCC 14's
// -Wmaybe-uninitialized fires a known false positive when a
// default-constructed AnalysisSpec variant is moved into a vector at
// -O3; MSVC (the workspace's primary desktop toolchain) and the
// semantics are unaffected.
#if defined(__GNUC__) && !defined(__clang__)
#pragma GCC diagnostic ignored "-Wmaybe-uninitialized"
#endif

#include <doctest/doctest.h>

#include <ws/circsim/export.hpp>
#include <ws/circsim/format.hpp>
#include "fake_fs.hpp"

using ws::circsim::Diag;
using ws::circsim::LoadReport;
using ws::circsim::Part;
using ws::circsim::Schematic;
using ws::circsim::Severity;
using ws::circsim::Wire;

namespace {

Schematic divider() {
    Schematic s;
    // V1 sits clear of the wire's run (the old bench drew V1.p0 to
    // R1.p0 as a straight segment with V1.p1 riding its interior -
    // a pickup the migration now converts to structure on load, which
    // the field-for-field round-trip rightly notices).
    Part* v = s.add_part(Part::make("v", "V1", "5", {0.0, -6.0}));
    Part* r1 = s.add_part(Part::make("r", "R1", "10k", {6.0, 0.0}));
    Part* r2 = s.add_part(Part::make("r", "R2", "10k", {14.0, 0.0}));
    s.add_part(Part::make("gnd", "", "", {6.0, -4.0}));
    s.add_wire(Wire::endpoints(ws::circsim::PinRef{v->id, 0},
        ws::circsim::PinRef{r1->id, 0}));
    s.add_wire(Wire::endpoints(ws::circsim::PinRef{r1->id, 1},
        ws::circsim::PinRef{r2->id, 0}));
    ws::circsim::Label* out = s.add_label({});
    out->pos = {10.0, 0.0};
    out->name = "out";
    s.analysis.entries.push_back(ws::circsim::OpSpec{});
    s.directives = ".model nothing here";
    s.view.zoom = 2.5;
    s.view.center = {3.0, 4.0};
    return s;
}

bool same_schematic(const Schematic& a, const Schematic& b) {
    if (a.grid != b.grid || a.next_id() != b.next_id()) {
        return false;
    }
    if (a.directives != b.directives || a.view.zoom != b.view.zoom ||
        a.view.center.x != b.view.center.x ||
        a.view.center.y != b.view.center.y || a.temp != b.temp) {
        return false;
    }
    if (a.parts().size() != b.parts().size() ||
        a.wires().size() != b.wires().size() ||
        a.labels().size() != b.labels().size() ||
        a.junctions().size() != b.junctions().size()) {
        return false;
    }
    if (a.analysis.entries.size() != b.analysis.entries.size()) {
        return false;
    }
    for (std::size_t i = 0; i < a.parts().size(); ++i) {
        const Part& x = a.parts()[i];
        const Part& y = b.parts()[i];
        if (x.id != y.id || x.symbol != y.symbol || x.ref != y.ref ||
            x.value != y.value || x.pos.x != y.pos.x || x.pos.y != y.pos.y ||
            x.rot != y.rot || x.mirror != y.mirror ||
            x.params != y.params || x.unknown != y.unknown) {
            return false;
        }
    }
    for (std::size_t i = 0; i < a.wires().size(); ++i) {
        const Wire& x = a.wires()[i];
        const Wire& y = b.wires()[i];
        if (x.id != y.id || x.a != y.a || x.b != y.b ||
            x.waypoints != y.waypoints || x.ortho != y.ortho ||
            x.unknown != y.unknown) {
            return false;
        }
    }
    for (std::size_t i = 0; i < a.labels().size(); ++i) {
        if (a.labels()[i].id != b.labels()[i].id ||
            a.labels()[i].name != b.labels()[i].name ||
            a.labels()[i].pos.x != b.labels()[i].pos.x ||
            a.labels()[i].pos.y != b.labels()[i].pos.y) {
            return false;
        }
    }
    // Analysis entries: compare card spellings (a faithful proxy).
    for (std::size_t i = 0; i < a.analysis.entries.size(); ++i) {
        if (ws::circsim::analysis_card(a.analysis.entries[i]) !=
            ws::circsim::analysis_card(b.analysis.entries[i])) {
            return false;
        }
    }
    return true;
}

}  // namespace

TEST_CASE("a schematic round-trips field for field") {
    const Schematic s = divider();
    LoadReport report;
    const auto loaded = ws::circsim::load_csim(ws::circsim::save_csim(s),
                                               report);
    REQUIRE(loaded.has_value());
    CHECK(report.diags.empty());
    CHECK(same_schematic(s, *loaded));

    // And the second save is byte-identical (stable diffs).
    CHECK(ws::circsim::save_csim(*loaded) == ws::circsim::save_csim(s));
}

TEST_CASE("a label's wire binding round-trips") {
    // The authored binding saves (absent for 0) and loads back - the
    // junction taps' own contract: the field is the connection, the
    // file carries it.
    Schematic s;
    s.add_part(Part::make("r", "R1", "1k", {0.0, 0.0}));
    ws::circsim::Junction a{};
    a.id = s.alloc_id();
    a.pos = {0.0, 0.0};
    s.junctions_mut().push_back(a);
    ws::circsim::Junction b{};
    b.id = s.alloc_id();
    b.pos = {10.0, 0.0};
    s.junctions_mut().push_back(b);
    ws::circsim::Wire w =
        ws::circsim::Wire::endpoints(ws::circsim::JunctionRef{a.id},
                                    ws::circsim::JunctionRef{b.id});
    w.id = s.alloc_id();
    s.wires_mut().push_back(w);
    ws::circsim::Label* bound = s.add_label({});
    bound->pos = {5.0, 0.0};
    bound->name = "vcc";
    bound->wire = w.id;
    ws::circsim::Label* free = s.add_label({});
    free->pos = {50.0, 50.0};
    free->name = "note";

    LoadReport report;
    const auto loaded = ws::circsim::load_csim(ws::circsim::save_csim(s),
                                               report);
    REQUIRE(loaded.has_value());
    CHECK(report.diags.empty());
    const ws::circsim::Label* lb = loaded->find_label(bound->id);
    const ws::circsim::Label* lf = loaded->find_label(free->id);
    REQUIRE(lb != nullptr);
    REQUIRE(lf != nullptr);
    CHECK(lb->wire == w.id);
    CHECK(lf->wire == 0);

    // The bound label's save names the wire; the free label's does
    // not (absent, not 0 - the file stays clean).
    const std::string text = ws::circsim::save_csim(s);
    CHECK(text.find("\"wire\"") != std::string::npos);
}

TEST_CASE("arrays save sorted by id regardless of vector order") {
    Schematic s;
    s.add_part(Part::make("r", "R2", "1k", {0.0, 0.0}));  // id 1
    s.add_part(Part::make("r", "R1", "1k", {4.0, 0.0}));  // id 2
    std::swap(s.parts_mut()[0], s.parts_mut()[1]);  // vector order reversed
    const std::string text = ws::circsim::save_csim(s);
    const std::size_t r2 = text.find("\"ref\": \"R2\"");
    const std::size_t r1 = text.find("\"ref\": \"R1\"");
    REQUIRE(r1 != std::string::npos);
    REQUIRE(r2 != std::string::npos);
    CHECK(r2 < r1);  // id 1 saves first
}

TEST_CASE("unknown fields survive a round trip, in place") {
    const std::string text = R"json({
        "format": "circsim",
        "version": 1,
        "grid": 1.0,
        "next_id": 4,
        "author": "someone",
        "parts": [
            {"id": 1, "symbol": "r", "ref": "R1", "value": "1k",
             "pos": [0.0, 0.0], "rot": 0, "mirror": false,
             "params": {"note": "keep"},
             "stock": "thin-film", "custom": {"a": [1, 2]}}
        ],
        "junctions": [],
        "wires": [
            {"id": 2, "a": {"pin": {"part": 1, "pin": 0}},
             "b": {"pin": {"part": 1, "pin": 1}}, "waypoints": [],
             "ortho": true, "color": "blue"}
        ],
        "labels": [],
        "analysis": {"entries": []},
        "directives": "",
        "view": {"zoom": 1.0, "center": [0.0, 0.0], "ruler": true},
        "future-top-level": {"x": 1}
    })json";
    LoadReport report;
    const auto loaded = ws::circsim::load_csim(text, report);
    REQUIRE(loaded.has_value());
    CHECK(report.diags.empty());

    const std::string saved = ws::circsim::save_csim(*loaded);
    CHECK(saved.find("\"author\": \"someone\"") != std::string::npos);
    CHECK(saved.find("\"stock\": \"thin-film\"") != std::string::npos);
    CHECK(saved.find("\"custom\"") != std::string::npos);
    CHECK(saved.find("\"color\": \"blue\"") != std::string::npos);
    CHECK(saved.find("\"ruler\": true") != std::string::npos);
    CHECK(saved.find("\"future-top-level\"") != std::string::npos);
    // Unknowns land after the known fields, not before them.
    CHECK(saved.find("\"stock\"") > saved.find("\"params\""));

    // And they survive ANOTHER round trip.
    LoadReport second_report;
    const auto again = ws::circsim::load_csim(saved, second_report);
    REQUIRE(again.has_value());
    CHECK(ws::circsim::save_csim(*again) == saved);
}

TEST_CASE("version 0 files migrate through the chain") {
    const std::string text = R"json({
        "format": "circsim",
        "grid": 1.0,
        "parts": [],
        "junctions": [], "wires": [], "labels": []
    })json";
    LoadReport report;
    const auto loaded = ws::circsim::load_csim(text, report);
    REQUIRE(loaded.has_value());
    CHECK(report.loaded_version == 0);
    CHECK(report.migrated);
    CHECK_FALSE(report.future);
    CHECK(loaded->directives.empty());

    // The migrated save claims the current version.
    const std::string saved = ws::circsim::save_csim(*loaded);
    CHECK(saved.find("\"version\": 1") != std::string::npos);
}

TEST_CASE("future versions load with a warning, not a failure") {
    const std::string text = R"json({
        "format": "circsim", "version": 99, "grid": 1.0,
        "parts": [{"id": 1, "symbol": "r", "ref": "R1", "value": "1k",
                   "pos": [0.0, 0.0], "rot": 0, "mirror": false,
                   "params": {}}],
        "junctions": [], "wires": [], "labels": []
    })json";
    LoadReport report;
    const auto loaded = ws::circsim::load_csim(text, report);
    REQUIRE(loaded.has_value());
    CHECK(report.future);
    REQUIRE(report.diags.size() == 1);
    CHECK(report.diags[0].code == "circsim.format.future_version");
    CHECK(report.diags[0].severity == Severity::Warning);
}

TEST_CASE("duplicate ids keep the first and raise next_id past both") {
    const std::string text = R"json({
        "format": "circsim", "version": 1, "grid": 1.0, "next_id": 3,
        "parts": [
            {"id": 2, "symbol": "r", "ref": "R2", "value": "2k",
             "pos": [0.0, 0.0], "rot": 0, "mirror": false, "params": {}},
            {"id": 2, "symbol": "r", "ref": "OTHER", "value": "9k",
             "pos": [4.0, 0.0], "rot": 0, "mirror": false, "params": {}}
        ],
        "junctions": [], "wires": [], "labels": []
    })json";
    LoadReport report;
    const auto loaded = ws::circsim::load_csim(text, report);
    REQUIRE(loaded.has_value());
    REQUIRE(loaded->parts().size() == 1);
    CHECK(loaded->parts()[0].ref == "R2");
    REQUIRE(report.diags.size() == 1);
    CHECK(report.diags[0].code == "circsim.format.duplicate_id");
    // next_id above the dropped duplicate's id: never reused.
    CHECK(loaded->next_id() == 3);
    Schematic mutable_copy = *loaded;
    CHECK(mutable_copy.alloc_id() == 3);
}

TEST_CASE("wires referencing missing parts or junctions are dropped") {
    const std::string text = R"json({
        "format": "circsim", "version": 1, "grid": 1.0, "next_id": 6,
        "parts": [
            {"id": 1, "symbol": "r", "ref": "R1", "value": "1k",
             "pos": [0.0, 0.0], "rot": 0, "mirror": false, "params": {}}
        ],
        "junctions": [],
        "wires": [
            {"id": 2, "a": {"pin": {"part": 99, "pin": 0}},
             "b": {"pin": {"part": 1, "pin": 0}}, "waypoints": [],
             "ortho": true},
            {"id": 3, "a": {"junction": {"id": 42}},
             "b": {"pin": {"part": 1, "pin": 1}}, "waypoints": [],
             "ortho": true}
        ],
        "labels": []
    })json";
    LoadReport report;
    const auto loaded = ws::circsim::load_csim(text, report);
    REQUIRE(loaded.has_value());
    CHECK(loaded->wires().empty());
    REQUIRE(report.diags.size() == 2);
    CHECK(report.diags[0].code == "circsim.format.dangling_ref");
    CHECK(report.diags[1].code == "circsim.format.dangling_ref");
}

TEST_CASE("not-json and wrong-format files are hard failures") {
    LoadReport report;
    const auto a = ws::circsim::load_csim("this is not json", report);
    REQUIRE_FALSE(a.has_value());
    CHECK(a.error().category == std::string("circsim"));

    const auto b = ws::circsim::load_csim("{\"format\": \"other\"}", report);
    REQUIRE_FALSE(b.has_value());

    const auto c = ws::circsim::load_csim("[1, 2, 3]", report);
    REQUIRE_FALSE(c.has_value());
}

TEST_CASE("wrong-typed known fields repair to defaults with diagnostics") {
    const std::string text = R"json({
        "format": "circsim", "version": 1, "grid": "coarse", "next_id": 2,
        "parts": [
            {"id": 1, "symbol": "r", "ref": "R1", "value": 42,
             "pos": "nope", "rot": 0, "mirror": false, "params": {
                 "model": 7
             }}
        ],
        "junctions": [], "wires": [], "labels": []
    })json";
    LoadReport report;
    const auto loaded = ws::circsim::load_csim(text, report);
    REQUIRE(loaded.has_value());
    REQUIRE(loaded->parts().size() == 1);
    CHECK(loaded->parts()[0].value.empty());  // non-text value repaired
    CHECK(loaded->parts()[0].pos.x == 0.0);   // bad pos repaired
    CHECK(loaded->parts()[0].params.empty()); // non-text param dropped
    CHECK(loaded->grid == 1.0);               // non-number grid repaired
    CHECK(report.diags.size() >= 3);
    bool saw_pos = false;
    for (const Diag& d : report.diags) {
        if (d.code == "circsim.format.bad_field" &&
            d.message.find("pos") != std::string::npos) {
            saw_pos = true;
        }
    }
    CHECK(saw_pos);
}

TEST_CASE("the disk pair rides the FileSystem seam, writes atomic") {
    ws::circsim::testing::FakeFs fs;
    const Schematic s = divider();
    REQUIRE(ws::circsim::write_csim(fs, "a.csim", s));
    REQUIRE(fs.exists("a.csim"));
    CHECK(fs.writes == 1);

    LoadReport report;
    const auto loaded = ws::circsim::read_csim(fs, "a.csim", report);
    REQUIRE(loaded.has_value());
    CHECK(same_schematic(s, *loaded));

    const auto missing = ws::circsim::read_csim(fs, "b.csim", report);
    REQUIRE_FALSE(missing.has_value());
    CHECK(missing.error().category == std::string("circsim"));
}

TEST_CASE("every analysis spec spelling round-trips") {
    Schematic s;
    s.analysis.entries.push_back(ws::circsim::OpSpec{});
    s.analysis.entries.push_back(
        ws::circsim::DcSpec{.source = "V1", .start = 0.0, .stop = 5.0,
                            .step = 0.1});
    s.analysis.entries.push_back(ws::circsim::TranSpec{
        .tstep = 1e-4, .tstop = 1e-2, .tstart = 0.0, .tmax = 1e-3,
        .uic = true});
    s.analysis.entries.push_back(ws::circsim::AcSpec{
        .sweep = ws::circsim::AcSpec::Sweep::Oct, .n = 20,
        .fstart = 10.0, .fstop = 1e5});
    s.analysis.entries.push_back(ws::circsim::NoiseSpec{
        .sweep = ws::circsim::NoiseSpec::Sweep::Lin, .n = 30,
        .fstart = 100.0, .fstop = 100e3, .output = "out", .ref = "gndref",
        .input = "V1", .pts_per_summary = 5});
    s.temp = 85.0;

    LoadReport report;
    const auto loaded =
        ws::circsim::load_csim(ws::circsim::save_csim(s), report);
    REQUIRE(loaded.has_value());
    CHECK(same_schematic(s, *loaded));
}

TEST_CASE("the temperature field is optional and absent when unset") {
    // Unset: the file carries no temp key at all (an older writer's
    // byte-identical shape), and the load answers nullopt.
    {
        Schematic s;
        LoadReport report;
        const auto loaded =
            ws::circsim::load_csim(ws::circsim::save_csim(s), report);
        REQUIRE(loaded.has_value());
        CHECK(loaded->temp == std::nullopt);
        CHECK(ws::circsim::save_csim(*loaded).find("\"temp\"") ==
              std::string::npos);
    }
    // A non-number repairs to unset with a diagnostic, never a failure.
    {
        constexpr const char* bad =
            R"json({"format":"circsim","version":1,"temp":"hot"})json";
        LoadReport report;
        const auto loaded = ws::circsim::load_csim(bad, report);
        REQUIRE(loaded.has_value());
        CHECK(loaded->temp == std::nullopt);
        REQUIRE(report.diags.size() == 1u);
        CHECK(report.diags[0].code == "circsim.format.bad_field");
    }
}

// --- the hardening batch: the id ceiling, grid snapping, load-time
// analysis validation, analysis unknowns -------------------------------------

TEST_CASE("the reserved id ceiling is rejected and next_id never wraps") {
    // id 4294967295 is the reserved ceiling: loading it would leave the
    // next-id counter nowhere to go, and the next add_part would mint
    // its duplicate. It must drop, like every unusable id.
    LoadReport report;
    const auto at_ceiling = load_csim(R"({
        "format": "circsim", "version": 1, "next_id": 4294967296,
        "parts": [
            {"id": 4294967295, "symbol": "r", "ref": "R1", "value": "1k",
             "pos": [0, 0], "rot": 0, "mirror": false}
        ]
    })",
                                       report);
    REQUIRE(at_ceiling.has_value());
    CHECK(at_ceiling->parts().empty());
    bool dropped = false;
    for (const Diag& d : report.diags) {
        if (d.code == "circsim.format.bad_id") {
            dropped = true;
        }
    }
    CHECK(dropped);

    // One below the ceiling loads, and the counter lands exactly on the
    // ceiling (the first alloc mints 4294967295 - unique, since no
    // stored id can be there).
    report = LoadReport{};
    const auto near_ceiling = load_csim(R"({
        "format": "circsim", "version": 1, "next_id": 1,
        "parts": [
            {"id": 4294967294, "symbol": "r", "ref": "R1", "value": "1k",
             "pos": [0, 0], "rot": 0, "mirror": false}
        ]
    })",
                                         report);
    REQUIRE(near_ceiling.has_value());
    CHECK(near_ceiling->parts().size() == 1);
    CHECK(near_ceiling->next_id() == 4294967295u);

    // A file next_id at the ceiling is out of range (it could only
    // wrap on alloc); it is ignored, and the stored ids still raise
    // the counter above themselves.
    report = LoadReport{};
    const auto clamped = load_csim(R"({
        "format": "circsim", "version": 1, "next_id": 4294967295,
        "parts": [
            {"id": 7, "symbol": "r", "ref": "R1", "value": "1k",
             "pos": [0, 0], "rot": 0, "mirror": false}
        ]
    })",
                                   report);
    REQUIRE(clamped.has_value());
    CHECK(clamped->next_id() == 8);  // the part's id + 1, not the file's
}

TEST_CASE("off-grid coordinates snap to the integer grid with a warning") {
    LoadReport report;
    const auto snapped = load_csim(R"({
        "format": "circsim", "version": 1, "next_id": 10,
        "parts": [
            {"id": 1, "symbol": "r", "ref": "R1", "value": "1k",
             "pos": [1.5, 2.25], "rot": 0, "mirror": false}
        ],
        "junctions": [{"id": 2, "pos": [3.1, -0.9]}],
        "labels": [{"id": 3, "pos": [0.5, 0.5], "name": "out"}],
        "wires": [{"id": 4,
                   "a": {"pin": {"part": 1, "pin": 0}},
                   "b": {"junction": {"id": 2}},
                   "waypoints": [[2.5, 1.5]], "ortho": true}]
    })",
                                   report);
    REQUIRE(snapped.has_value());
    REQUIRE(snapped->parts().size() == 1);
    CHECK(snapped->parts().front().pos.x == 2.0);
    CHECK(snapped->parts().front().pos.y == 2.0);
    CHECK(snapped->junctions().front().pos.x == 3.0);
    CHECK(snapped->junctions().front().pos.y == -1.0);
    CHECK(snapped->labels().front().pos.x == 1.0);
    CHECK(snapped->labels().front().pos.y == 1.0);
    REQUIRE(snapped->wires().size() == 1);
    REQUIRE(snapped->wires().front().waypoints.size() == 1);
    CHECK(snapped->wires().front().waypoints.front().x == 3.0);
    CHECK(snapped->wires().front().waypoints.front().y == 2.0);

    std::size_t off_grid = 0;
    for (const Diag& d : report.diags) {
        if (d.code == "circsim.format.off_grid") {
            ++off_grid;
            CHECK(d.severity == Severity::Warning);
        }
    }
    CHECK(off_grid == 4);  // one per entity: part, junction, label, waypoint

    // The save writes the snapped values (the repair sticks), and a
    // reload of that save is warning-free.
    const std::string saved = save_csim(*snapped);
    LoadReport second;
    const auto reloaded = load_csim(saved, second);
    REQUIRE(reloaded.has_value());
    for (const Diag& d : second.diags) {
        CHECK(d.code != "circsim.format.off_grid");
    }
}

TEST_CASE("invalid analysis values are rejected at load, not at run") {
    LoadReport report;
    const auto loaded = load_csim(R"({
        "format": "circsim", "version": 1, "next_id": 2,
        "parts": [],
        "analysis": {"entries": [
            {"dc": {"source": "V1", "start": 0, "stop": 5, "step": 0}},
            {"ac": {"sweep": "dec", "n": 0, "fstart": 1, "fstop": 1000}},
            {"ac": {"sweep": "dec", "n": 1.5, "fstart": 1, "fstop": 1000}},
            {"tran": {"tstep": 0, "tstop": 0}},
            {"noise": {"output": "", "input": "V1", "sweep": "dec",
                       "n": 10, "fstart": 1, "fstop": 1000}},
            {"op": {}},
            {"dc": {"source": "V1", "start": 0, "stop": 5, "step": 0.1}}
        ]}
    })",
                                  report);
    REQUIRE(loaded.has_value());
    // The five invalid entries are gone; the two valid ones survive,
    // in order.
    REQUIRE(loaded->analysis.entries.size() == 2);
    CHECK(std::holds_alternative<ws::circsim::OpSpec>(
        loaded->analysis.entries.front()));
    const auto* dc = std::get_if<ws::circsim::DcSpec>(
        &loaded->analysis.entries.back());
    REQUIRE(dc != nullptr);
    CHECK(dc->step == 0.1);
    // Each rejection is an error diagnostic that names the analysis.
    std::size_t bad = 0;
    for (const Diag& d : report.diags) {
        if (d.code == "circsim.format.bad_analysis") {
            ++bad;
            CHECK(d.severity == Severity::Error);
            CHECK(d.target.kind == ws::circsim::DiagTarget::Kind::Analysis);
        }
    }
    CHECK(bad == 5);
}

TEST_CASE("analysis entries and the setup preserve unknown fields") {
    LoadReport report;
    const auto loaded = load_csim(R"({
        "format": "circsim", "version": 1, "next_id": 2,
        "parts": [],
        "analysis": {
            "selected": 2,
            "entries": [
                {"dc": {"source": "V1", "start": 0, "stop": 5, "step": 0.1,
                        "frobnicate": 7}, "note": "the input sweep"},
                {"op": {"frob": "x"}, "enabled": false}
            ]
        }
    })",
                                  report);
    REQUIRE(loaded.has_value());
    REQUIRE(loaded->analysis.entries.size() == 2);
    const auto* dc = std::get_if<ws::circsim::DcSpec>(
        &loaded->analysis.entries.front());
    REQUIRE(dc != nullptr);
    CHECK(dc->unknown.find("frobnicate") != nullptr);
    CHECK(dc->unknown.find("note") != nullptr);
    const auto* op = std::get_if<ws::circsim::OpSpec>(
        &loaded->analysis.entries.back());
    REQUIRE(op != nullptr);
    CHECK(op->unknown.find("frob") != nullptr);
    CHECK(op->unknown.find("enabled") != nullptr);
    CHECK(loaded->analysis.unknown.find("selected") != nullptr);

    // And they all come back out on save.
    const std::string saved = save_csim(*loaded);
    CHECK(saved.find("\"selected\"") != std::string::npos);
    CHECK(saved.find("\"frobnicate\"") != std::string::npos);
    CHECK(saved.find("\"note\"") != std::string::npos);
    CHECK(saved.find("\"enabled\"") != std::string::npos);
    CHECK(saved.find("\"frob\"") != std::string::npos);
}
