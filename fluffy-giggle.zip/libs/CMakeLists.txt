# libs/ subset support: the add_subdirectory calls below are each gated on
# the lib being wanted. "Wanted" = the lib is in the configured closure of
# WS_BUILD_LIBS (computed in cmake/WsHelpers.cmake from the dependency
# registry - the single source of truth). Empty WS_BUILD_LIBS (the default:
# the whole workspace) wants everything. Order stays dependency-first:
# core, math, then everything else.

# One ws_want_<lib> variable per lib - CMake's if() cannot call functions,
# and spelling the result out keeps the gating below readable. ws_wants
# lives in WsHelpers.cmake and tests WS_ALL_LIBS (the closure).
get_property(_known_libs GLOBAL PROPERTY ws_lib_known_libs)
foreach(_lib ${_known_libs})
  ws_wants(_want ${_lib})
  set(ws_want_${_lib} ${_want})
endforeach()
unset(_lib)
unset(_want)

if(ws_want_core)
  add_subdirectory(core)
endif()
if(ws_want_math)
  # ws::math: dense Matrix<T> + LU and ws-owned fixed-size vecmath; the spice
  # arc grows the sparse symbolic-reuse LU facade here (its MNA solver's
  # numerics home, consumed PRIVATE - never a ws::math type in spice headers).
  add_subdirectory(math)
endif()
# ws::input is the input family promoted out of ui (stage 3a): the event
# types + the InputFrame snapshot, pure CPU and GLFW-free (codes ride as
# plain ints). ws::ui's platform TUs are the only writers of an InputFrame,
# so ui links this lib - never the other way around.
if(ws_want_input)
  add_subdirectory(input)
endif()
# ws::gfx is the Vulkan device layer promoted out of ui (stage 3b): the
# loader/instance, the surface-via-callback, device/queue selection, the
# VMA allocator. volk/vma stay PRIVATE here (handles cross to ui as
# opaque void*), and ui is the only consumer - never the other way
# around.
# ws::gestures is the multi-touch arbiter (the touch rewrite's lib): a
# pure state machine over ws::input's touch table that decides tap vs
# drag vs pinch per frame - the first finger of a pinch is never a
# click. Any touch-capable surface feeds it one InputFrame per pump and
# applies the answered zoom/pan/tap actions; the editor canvas is the
# first consumer (the ui CanvasView policy and the playground demo still
# carry their own private pinch math - retirement candidates).
if(ws_want_plotmath)
  # ws::plotmath is the shared plotting math core (the unify-plotting
  # merge): the one authoritative implementation of the axis ladder,
  # the engineering-notation label, the range/view invariants, the
  # hover lookup, the min/max decimation and the monotone-run family
  # split - shared by the ui widget and the circsim panel below it.
  # Pure std + core; both tiers link it, neither reaches the other.
  add_subdirectory(plotmath)
endif()
if(ws_want_gestures)
  add_subdirectory(gestures)
endif()
if(ws_want_gfx)
  add_subdirectory(gfx)
endif()
if(ws_want_jobs)
  # ws::jobs is the headless job system (nextplan stage 8): a Result-shaped
  # pool with priorities, cooperative cancellation and coalesced progress +
  # completions marshalled to the owner thread. Pure std + ws::core - no
  # third-party anywhere; consumers (ws::ui first) drain() once per frame.
  add_subdirectory(jobs)
endif()
if(ws_want_settings)
  # ws::settings is the headless settings store (nextplan stage 9): a typed
  # schema (defaults + constraints), layered sources with provenance, change
  # observers and JSON persistence through a minimal FileSystem seam.
  # Pure std + ws::core - no third-party anywhere.
  add_subdirectory(settings)
endif()
if(ws_want_app)
  # ws::app is the headless app-framework services lib (nextplan stage
  # 13): the command registry, then shortcut resolution with user
  # rebinding and the undo stack - the headless halves of stage 13; the
  # ui views over them (menu/toolbar builders, the command palette, the
  # keymap editor) live in ws::ui. Pure std + ws::core; ws::settings
  # joins when keymap persistence lands.
  add_subdirectory(app)
endif()
if(ws_want_ui)
  add_subdirectory(ui)
endif()
if(ws_want_audio)
  # ws::audio builds everywhere: the engine pimpl is OpenAL Soft on both
  # platforms, and OpenAL Soft's own device layer goes AAudio-via-Oboe on
  # Android (cmake/ThirdParty.cmake fetches Oboe there, PRIVATE like every
  # third-party).
  add_subdirectory(audio)
endif()
if(ws_want_net)
  # ws::net is cross-platform on the same libuv backend everywhere: TCP/UDP +
  # LAN discovery, uv private to src/backend/uv (the glfw/openal fetch
  # pattern, unconditional).
  add_subdirectory(net)
endif()
if(ws_want_physics)
  # ws::physics is cross-platform on the same two backends everywhere:
  # Box2D (2D) + Jolt (3D), both private to src/backend and both fetched
  # unconditionally - the 2D and 3D surfaces build identically on Android.
  add_subdirectory(physics)
endif()
if(ws_want_platform)
  # ws::platform is the headless platform-services lib (nextplan stage 12):
  # standard locations and lexical paths now, then dialogs/recent
  # files/autosave/watch on the ws::settings FileSystem + json seams. The
  # os halves stay in per-platform TUs behind Result-only APIs; apps never
  # see a platform header.
  add_subdirectory(platform)
endif()
if(ws_want_spice)
  # ws::spice is the headless circuit simulator (DESIGN.md): netlist parser,
  # elaboration with subckt flattening, MNA assembly over the ws::math sparse
  # LU facade (linked PRIVATE - no ws::math type in a spice header), and the
  # analysis drivers. Pure std + ws::core + ws::math; its CLI is apps/spice.
  add_subdirectory(spice)
endif()
if(ws_want_circsim)
  # ws::circsim is the schematic model + .csim format + nets + ERC + the
  # ws::spice export + the .csym symbol library (the circsim app's
  # headless core, stages 1-2): the schematic data model and every
  # simulation path over ws::spice - never a second solver. The settings
  # link is the json + FileSystem seam (the formats' carrier); no ui
  # include anywhere. Its CLI is apps/circsim_cli.
  add_subdirectory(circsim)
endif()
if(ws_want_schematic)
  # ws::schematic is the explicit-connectivity wire/move core (the docs/
  # schematic-current.md rewrite): a node graph (pins, junctions, labels)
  # + wires over node ids + nets as pure union-find, and the pure
  # resolve_move overlay the editor's drag preview and its ONE undo
  # command both read. No rendering, no ui, no geometry-inferred
  # connectivity anywhere - a T-connection is a junction node that
  # SPLITS the wire, and crossing/touching wires never connect.
  add_subdirectory(schematic)
endif()
