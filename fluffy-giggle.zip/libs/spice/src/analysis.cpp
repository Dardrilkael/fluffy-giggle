// Analysis drivers (DESIGN.md §6/§7). Each analysis runs over an
// IMMUTABLE Circuit plus a per-run RunState (§3.5 rev): the kernel owns
// the MNA system, the Newton loop walks the §5.1 convergence rule, and
// every device mutation (companion coefficients, switch positions)
// happens through state slices. Value sweeps (.dc sources) write
// parameter slots; temperature sweeps re-elaborate. The convergence-aid
// ladder (gmin/source stepping, pseudo-transient) lands with M3; every
// M1/M2 device is linear, so plain Newton converges in two iterations
// (solve + confirm) and the ladder paths stay unexercised rather than
// missing.

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdio>
#include <limits>
#include <map>
#include <memory>
#include <optional>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include <ws/spice/circuit.hpp>
#include <ws/spice/circuit.hpp>
#include "drivers.hpp"
#include "kernel.hpp"
#include "mna.hpp"

#include <ws/spice/deck.hpp>
#include <ws/spice/fourier.hpp>
#include <ws/spice/measure.hpp>
#include <ws/spice/run.hpp>
#include <ws/spice/state.hpp>

namespace ws::spice {

namespace {

using ws::spice::detail::DcKernel;
using ws::spice::detail::SaveList;
using ws::spice::detail::fold_all;
using ws::spice::detail::append_row_columns;
using ws::spice::detail::default_save_list;
using ws::spice::detail::signal_skeleton;

Diagnostic run_diag(ErrorKind kind, std::string code, std::string message) {
    Diagnostic d;
    d.kind = kind;
    d.code = std::move(code);
    d.message = std::move(message);
    return d;
}

// The cooperative-stop error (RunSettings::should_stop): its own kind so a
// caller can tell "the user stopped it" from a deck that failed.
ws::core::unexpected<ws::core::Error> cancelled_run_error() {
    return spice_fail(run_diag(ErrorKind::Cancelled, "spice.cancelled",
                               "the run was cancelled"));
}

[[nodiscard]] bool run_stop_requested(const RunSettings& settings) {
    return settings.should_stop && settings.should_stop();
}

std::string fmt_value(double v) {
    char buf[32];
    std::snprintf(buf, sizeof(buf), "%.6g", v);
    return buf;
}

ws::core::unexpected<ws::core::Error> empty_circuit_error(const std::string& analysis) {
    Diagnostic d = run_diag(ErrorKind::Semantic, "spice.semantic.empty_circuit",
                            "no devices to simulate");
    d.analysis = analysis;
    d.hint = "a deck needs device cards (R, V, I, ...) before its analyses";
    return spice_fail(std::move(d));
}

// A solver failure surfacing from the ws::math facade (category "math":
// factorization, dimension, pattern) keeps its message but gains the spice
// taxonomy + analysis context (§9.1/§9.2). Errors the kernel already
// classified as a spice Diagnostic (category "spice": convergence, NaN
// iterate, ...) pass through UNTOUCHED - re-wrapping them re-branded
// Convergence as Singular, doubled the "error: [analysis]" prefix, and
// lost the original code (spice.convergence.nan/newton).
ws::core::unexpected<ws::core::Error> wrap_solver_error(const ws::core::Status& st,
                                                        const std::string& context) {
    if (std::string_view(st.error().category) == "spice") {
        return ws::core::unexpected<ws::core::Error>(st.error());
    }
    Diagnostic d = run_diag(ErrorKind::Singular, "spice.singular",
                            st.error().message.empty() ? "matrix factorization failed"
                                                       : st.error().message);
    d.analysis = context;
    return spice_fail(std::move(d));
}

// --- .op (§7.2) ---------------------------------------------------------------------

ws::core::Result<Table> run_op(const Circuit& circuit, RunState& state,
                               const RunSettings& settings, AnalysisReport& report,
                               const std::vector<NodesetCard>& nodeset_cards) {
    if (circuit.devices.empty()) {
        return empty_circuit_error(".op");
    }
    // §7.2/M5: the .nodeset hints seed + soften the first iteration.
    std::vector<std::pair<std::size_t, double>> nodesets;
    if (!nodeset_cards.empty()) {
        WS_TRY_ASSIGN(nodesets, detail::resolve_nodesets(circuit, nodeset_cards));
    }

    DcKernel kernel(circuit, state, settings);
    if (const ws::core::Status st = kernel.prepare(); !st) {
        return wrap_solver_error(st, ".op");
    }

    std::vector<double> x;  // cold start: all zeros
    std::size_t iterations = 0;
    if (const ws::core::Status st = kernel.solve(
            x, settings.itl1, ".op", iterations, nullptr,
            nodesets.empty() ? nullptr : &nodesets);
        !st) {
        return wrap_solver_error(st, ".op");
    }

    report.analysis = ".op";
    report.newton_iterations = iterations;
    report.lu_factorizations = kernel.factorizations();
    report.stage = kernel.stage();  // §5.2: which ladder stage converged

    Table t;
    t.analysis = AnalysisKind::Op;
    t.sweep = SweepKind::None;
    const SaveList save = default_save_list(circuit);
    t.signals = signal_skeleton(save);
    append_row_columns(circuit, save, t, x, &state);
    return t;
}

// --- .dc (§7.3) -----------------------------------------------------------------------

struct SweepPlan {
    Token source;    // as spelled ("V1", "I2", "temp")
    bool is_temp = false;
    double start = 0.0;
    double stop = 0.0;
    double step = 0.0;
    std::size_t count = 0;  // floor((stop-start)/step + 1e-9) + 1
    char unit = 'V';        // 'V', 'A' or 'C' - for the error context
};

// A .dc grid is materialized row by row; anything past this is almost
// certainly a typo (start/stop/step units mismatch), not a real sweep.
constexpr std::size_t kMaxSweepPoints = 1'000'000;

ws::core::Result<double> eval_sweep_expr(const ExprProgram& prog,
                                         const ParamTable& params) {
    WS_TRY_ASSIGN(const std::vector<std::optional<double>> bindings, params.bind(prog));
    WS_TRY_ASSIGN(const double v, prog.evaluate(bindings));
    return v;
}

ws::core::Result<SweepPlan> plan_sweep(const DcSweep& sweep, const ParamTable& params,
                                       const Circuit& circuit) {
    SweepPlan plan;
    plan.source = sweep.source;

    WS_TRY_ASSIGN(plan.start, eval_sweep_expr(sweep.start, params));
    WS_TRY_ASSIGN(plan.stop, eval_sweep_expr(sweep.stop, params));
    WS_TRY_ASSIGN(plan.step, eval_sweep_expr(sweep.step, params));

    auto range_fail = [&](std::string message) -> ws::core::unexpected<ws::core::Error> {
        Diagnostic d = run_diag(ErrorKind::Semantic, "spice.semantic.dc_range",
                                std::move(message));
        d.loc = sweep.source.loc;
        return spice_fail(std::move(d));
    };

    // The expression evaluator already rejects NaN/inf results, but the
    // arithmetic below can still overflow (stop-start, or the interval
    // count). Guard both before the size_t cast - an out-of-range double
    // cast to size_t is UB, and a huge count would loop forever.
    if (!std::isfinite(plan.start) || !std::isfinite(plan.stop) ||
        !std::isfinite(plan.step)) {
        return range_fail("sweep values for '" + sweep.source.text +
                          "' must be finite");
    }

    if (plan.step == 0.0) {
        Diagnostic d = run_diag(ErrorKind::Semantic, "spice.semantic.dc_step",
                                "sweep step for '" + sweep.source.text + "' is zero");
        d.loc = sweep.source.loc;
        return spice_fail(std::move(d));
    }
    if ((plan.stop > plan.start && plan.step < 0.0) ||
        (plan.stop < plan.start && plan.step > 0.0)) {
        Diagnostic d = run_diag(
            ErrorKind::Semantic, "spice.semantic.dc_direction",
            "sweep step for '" + sweep.source.text + "' must point toward " +
                fmt_value(plan.stop) + " (start " + fmt_value(plan.start) + ", step " +
                fmt_value(plan.step) + ")");
        d.loc = sweep.source.loc;
        return spice_fail(std::move(d));
    }
    const double span = plan.stop - plan.start;
    const double intervals = std::floor(span / plan.step + 1e-9);
    if (!std::isfinite(span) || !std::isfinite(intervals) || intervals < 0.0) {
        return range_fail("sweep range for '" + sweep.source.text +
                          "' is out of range (start " + fmt_value(plan.start) +
                          ", stop " + fmt_value(plan.stop) + ", step " +
                          fmt_value(plan.step) + ")");
    }
    const double points = intervals + 1.0;
    if (!std::isfinite(points) || points < 1.0 ||
        points > static_cast<double>(kMaxSweepPoints)) {
        return range_fail("sweep for '" + sweep.source.text + "' produces " +
                          fmt_value(points) + " points; the maximum is " +
                          std::to_string(kMaxSweepPoints));
    }
    plan.count = static_cast<std::size_t>(points);

    // Classify the target: temp re-elaborates per point (§7.7); anything
    // else must name a V or I source in the circuit.
    const std::string lower = to_lower(sweep.source.text);
    if (lower == "temp") {
        plan.is_temp = true;
        plan.unit = 'C';
        return plan;
    }
    for (std::size_t i = 0; i < circuit.devices.size(); ++i) {
        if (to_lower(circuit.devices[i]->name()) != lower) {
            continue;
        }
        if (circuit.devices[i]->kind() != 'V' && circuit.devices[i]->kind() != 'I') {
            Diagnostic d = run_diag(
                ErrorKind::Semantic, "spice.semantic.dc_target",
                "'" + sweep.source.text + "' is not a V or I source (only sources and"
                " 'temp' are sweepable in v1)");
            d.loc = sweep.source.loc;
            return spice_fail(std::move(d));
        }
        plan.unit = circuit.devices[i]->kind() == 'V' ? 'V' : 'A';
        return plan;
    }
    Diagnostic d = run_diag(ErrorKind::Semantic, "spice.semantic.dc_target",
                            "unknown source '" + sweep.source.text + "' in .dc");
    d.loc = sweep.source.loc;
    return spice_fail(std::move(d));
}

std::string sweep_context(const SweepPlan& inner, double inner_value,
                          const std::optional<SweepPlan>& outer, double outer_value) {
    std::string ctx = ".dc " + inner.source.text + " at " + fmt_value(inner_value) +
                      " " + inner.unit;
    if (outer) {
        ctx += ", " + outer->source.text + " at " + fmt_value(outer_value) + " " +
               outer->unit;
    }
    return ctx;
}

ws::core::Result<Table> run_dc(const DeckAst& ast, const Circuit& base_circuit,
                               const DcCard& card, const RunSettings& settings,
                               std::vector<Warning>& warnings, AnalysisReport& report,
                               const std::vector<NodesetCard>& nodeset_cards) {
    // Warnings arrive via the caller's single elaboration; temp
    // re-elaborations inside this driver are identical by construction and
    // report to scratch (the §7.7 flow).
    (void)warnings;
    // §7.2/M5: the .nodeset hints apply to the sweep's FIRST point only
    // (ngspice: later points warm-start in INITFLOAT).
    std::vector<std::pair<std::size_t, double>> nodesets;
    if (!nodeset_cards.empty()) {
        WS_TRY_ASSIGN(nodesets, detail::resolve_nodesets(base_circuit, nodeset_cards));
    }
    // Global .param scope for the sweep expressions. ParamTable::define()
    // is infallible by design (a later definition replaces an earlier one),
    // so there is no error to drop here.
    ParamTable global;
    for (const ParamDef& def : ast.params) {
        global.define(def);
    }

    if (base_circuit.devices.empty()) {
        return empty_circuit_error(".dc");
    }

    WS_TRY_ASSIGN(SweepPlan inner, plan_sweep(card.first, global, base_circuit));
    std::optional<SweepPlan> outer;
    if (card.second) {
        WS_TRY_ASSIGN(outer, plan_sweep(*card.second, global, base_circuit));
    }

    // Two temp sweeps would share one temperature unknown: the innermost
    // value wins, so the outer temperature silently never changes. That is
    // not a meaningful nested sweep - reject it instead of guessing.
    if (outer && inner.is_temp && outer->is_temp) {
        Diagnostic d = run_diag(
            ErrorKind::Semantic, "spice.semantic.dc_nested_temp",
            "both .dc sweeps target 'temp'; a temperature sweep cannot nest"
            " another temperature sweep");
        d.loc = outer->source.loc;
        return spice_fail(std::move(d));
    }
    // Sweeping the same source twice is equally meaningless: the outer
    // assignment overwrites the inner one, but the table would still show
    // two sweep columns for the same value.
    if (outer && to_lower(inner.source.text) == to_lower(outer->source.text)) {
        Diagnostic d = run_diag(
            ErrorKind::Semantic, "spice.semantic.dc_duplicate_source",
            "both .dc sweeps target '" + inner.source.text +
                "'; each sweep needs a distinct source");
        d.loc = outer->source.loc;
        return spice_fail(std::move(d));
    }

    Table t;
    t.analysis = AnalysisKind::Dc;
    t.sweep = SweepKind::Swept;
    t.sweep_names.push_back(inner.source.text);
    if (outer) {
        t.sweep_names.push_back(outer->source.text);
    }
    t.sweep_axes.assign(t.sweep_names.size(), {});

    // Per-point state. A temp sweep re-elaborates when its value changes
    // (§7.7); everything else mutates only source parameter slots over
    // the shared pattern - the §7.6-rev reuse guarantee: a value write
    // can never move the stamp. Warnings surface from the FIRST
    // elaboration only - re-elaborations are identical by construction.
    std::size_t total_iterations = 0;
    std::size_t total_factorizations = 0;
    std::size_t kernel_factorizations = 0;  // last read from the LIVE kernel
    SaveList save = default_save_list(base_circuit);
    t.signals = signal_skeleton(save);
    std::unique_ptr<DcKernel> kernel;
    std::vector<double> x;  // warm start across points (§7.3)
    bool first_point = true;
    double last_temp = 0.0;
    bool have_temp = false;
    std::string last_stage = "newton";

    // The live circuit: the caller's (immutable) elaboration, or a local
    // re-elaboration when a temp point demands one. A Circuit is not
    // copyable - and never needs to be: value changes ride RunState, so
    // only temperature (an elaboration input, §7.7) swaps the circuit.
    std::optional<Circuit> temp_circuit;
    const Circuit* live = &base_circuit;
    std::optional<RunState> state;

    // Builds (or rebuilds) the kernel at `temp`. A temp change
    // re-elaborates at the NEW temperature - including the FIRST point of
    // a temp sweep: the caller's circuit was elaborated at the §7.7
    // default (27 C), not the sweep start, so it is not reusable there.
    // Warnings were already collected by that first elaboration
    // (re-elaborations are identical modulo temperature), so theirs go to
    // scratch. A new kernel's factorization counter starts at zero, so the
    // accumulator baseline resets with it.
    auto ensure_kernel = [&](bool temp_changed, double temp) -> ws::core::Status {
        if (kernel && !temp_changed) {
            return {};
        }
        kernel.reset();  // release the old circuit reference before a swap
        if (temp_changed) {
            // §7.7: re-elaborate at the point's temperature. Identical
            // modulo temperature by construction, so warnings go to
            // scratch (the caller already saw the first elaboration's).
            std::vector<Warning> scratch;
            WS_TRY_ASSIGN(Circuit re, elaborate_deck(ast, temp, scratch));
            temp_circuit.emplace(std::move(re));
            WS_TRY(finalize_circuit(*temp_circuit));
            live = &*temp_circuit;
        }
        const Circuit& circuit = *live;
        if (circuit.devices.empty()) {
            return empty_circuit_error(".dc");
        }
        // A temp re-elaboration yields the same node/device layout by
        // construction, so the columns (and the samples already collected)
        // survive; a genuinely different save list rebuilds the skeleton.
        SaveList fresh = default_save_list(circuit);
        if (fresh.columns != save.columns) {
            save = std::move(fresh);
            t.signals = signal_skeleton(save);
        }
        kernel_factorizations = 0;
        WS_TRY_ASSIGN(RunState rs, RunState::bind(circuit));
        state.emplace(std::move(rs));
        kernel = std::make_unique<DcKernel>(circuit, *state, settings);
        if (const ws::core::Status st = kernel->prepare(); !st) {
            return wrap_solver_error(st, ".dc");
        }
        return {};
    };

    const std::size_t outer_count = outer ? outer->count : 1;
    for (std::size_t o = 0; o < outer_count; ++o) {
        const double outer_value = outer ? outer->start + static_cast<double>(o) * outer->step
                                         : 0.0;
        for (std::size_t i = 0; i < inner.count; ++i) {
            const double inner_value =
                inner.start + static_cast<double>(i) * inner.step;

            // Apply the point: temp re-elaborates on change, sources
            // patch their dc parameter slot.
            double point_temp = settings.temp;
            if (outer && outer->is_temp) {
                point_temp = outer_value;
            }
            if (inner.is_temp) {
                point_temp = inner_value;  // innermost wins if both are temp
            }
            bool temp_changed = false;
            if (inner.is_temp) {
                temp_changed = !have_temp || inner_value != last_temp;
            }
            if (outer && outer->is_temp) {
                temp_changed = temp_changed || !have_temp || outer_value != last_temp;
            }
            if (inner.is_temp || (outer && outer->is_temp)) {
                last_temp = point_temp;
                have_temp = true;
            }
            WS_TRY(ensure_kernel(temp_changed, point_temp));
            const Circuit& circuit = *live;

            for (const SweepPlan* plan : {&inner, outer ? &*outer : nullptr}) {
                if (plan == nullptr || plan->is_temp) {
                    continue;
                }
                const std::string lower = to_lower(plan->source.text);
                bool patched = false;
                for (std::size_t di = 0; di < circuit.devices.size(); ++di) {
                    if (to_lower(circuit.devices[di]->name()) == lower &&
                        circuit.devices[di]->kind() != 'X' &&
                        circuit.param_span[di].count > 0) {
                        // Source parameter slot 0 is 'dc' (§3.5a).
                        state->params_[circuit.param_span[di].begin] =
                            plan == &inner ? inner_value : outer_value;
                        patched = true;
                        break;
                    }
                }
                if (!patched) {
                    Diagnostic d = run_diag(
                        ErrorKind::Semantic, "spice.semantic.dc_target",
                        "cannot sweep '" + plan->source.text + "' (not a source)");
                    d.analysis = sweep_context(inner, inner_value, outer, outer_value);
                    return spice_fail(std::move(d));
                }
            }

            const std::string ctx =
                sweep_context(inner, inner_value, outer, outer_value);
            const int cap = first_point ? settings.itl1 : settings.itl2;
            std::size_t iterations = 0;
            if (const ws::core::Status st = kernel->solve(
                    x, cap, ctx, iterations, nullptr,
                    first_point && !nodesets.empty() ? &nodesets : nullptr);
                !st) {
                return wrap_solver_error(st, ctx);
            }
            total_iterations += iterations;
            // Accumulate the DELTA since the last read: a temp change
            // replaces the kernel, whose counter restarts at zero - reading
            // the raw count here would drop every factorization before the
            // last re-elaboration.
            total_factorizations += kernel->factorizations() - kernel_factorizations;
            kernel_factorizations = kernel->factorizations();
            first_point = false;
            last_stage = kernel->stage();

            // Sweep values in sweep_names order: inner first, then outer.
            t.sweep_axes[0].push_back(inner_value);
            if (outer) {
                t.sweep_axes[1].push_back(outer_value);
            }
            append_row_columns(circuit, save, t, x, &*state);
        }
    }

    report.analysis = ".dc";
    report.newton_iterations = total_iterations;
    report.lu_factorizations = total_factorizations;
    report.stage = last_stage;  // §5.2: the worst point's ladder stage
    return t;
}

// --- .tran (§6) ----------------------------------------------------------------------

ws::core::Result<Table> run_tran(const Circuit& circuit, RunState& state,
                                 const TranCard& card, const RunSettings& settings,
                                 const ParamTable& scope,
                                 const std::vector<IcCard>& ics,
                                 AnalysisReport& report,
                                 const std::vector<NodesetCard>& nodesets) {
    auto march = std::make_unique<drivers::TranMarch>(circuit, state, settings, card,
                                                      scope, ics, nodesets);
    WS_TRY(march->prepare());
    drivers::TranMarch::Hooks hooks{};
    if (settings.should_stop || settings.on_tran_progress) {
        // A false return from on_accept stops the march (stopped() turns
        // true); progress observes, should_stop decides.
        hooks.on_accept = [&settings](double now, double tstop) {
            if (settings.on_tran_progress) {
                settings.on_tran_progress(now, tstop);
            }
            return !(settings.should_stop && settings.should_stop());
        };
    }
    while (!march->done() && !march->stopped()) {
        if (settings.should_stop && settings.should_stop()) {
            return cancelled_run_error();
        }
        WS_TRY(march->step(hooks));
    }
    if (march->stopped()) {
        // Only a hook can stop the march: a half-marched table must never
        // be handed back as the analysis's answer.
        return cancelled_run_error();
    }
    report = march->report();
    return march->take_table();
}

// --- .ac (§7.4) ----------------------------------------------------------------------

ws::core::Result<std::vector<double>> ac_frequency_list(const AcCard& card,
                                                        const ParamTable& params) {
    WS_TRY_ASSIGN(const double n, eval_sweep_expr(card.n, params));
    WS_TRY_ASSIGN(const double fstart, eval_sweep_expr(card.fstart, params));
    WS_TRY_ASSIGN(const double fstop, eval_sweep_expr(card.fstop, params));

    auto ac_fail = [&](std::string message) -> ws::core::unexpected<ws::core::Error> {
        Diagnostic d = run_diag(ErrorKind::Semantic, "spice.semantic.ac",
                                std::move(message));
        d.loc = card.loc;
        return spice_fail(std::move(d));
    };
    if (!std::isfinite(n) || n < 1.0 || std::floor(n) != n) {
        return ac_fail(".ac N must be a positive integer");
    }
    if (!std::isfinite(fstart) || fstart <= 0.0 || !std::isfinite(fstop) || fstop < fstart) {
        return ac_fail(".ac needs 0 < fstart <= fstop");
    }

    std::vector<double> freqs;
    if (card.sweep == AcCard::Sweep::Lin) {
        const std::size_t count = static_cast<std::size_t>(n);
        if (count > kMaxSweepPoints) {
            return ac_fail(".ac produces too many points");
        }
        freqs.reserve(count);
        if (count == 1) {
            freqs.push_back(fstart);
        } else {
            for (std::size_t k = 0; k < count; ++k) {
                // Direct computation, never repeated multiplication (§7.4).
                freqs.push_back(fstart + (fstop - fstart) *
                                             static_cast<double>(k) /
                                             static_cast<double>(count - 1));
            }
        }
        return freqs;
    }
    // dec/oct: f_k = fstart * base^(k/N), k = 0..floor(N*log_base(fstop/fstart)+1e-9)
    const double base = (card.sweep == AcCard::Sweep::Dec) ? 10.0 : 2.0;
    const double log_ratio =
        (card.sweep == AcCard::Sweep::Dec) ? std::log10(fstop / fstart)
                                           : std::log2(fstop / fstart);
    const double kd = std::floor(n * log_ratio + 1e-9) + 1.0;
    if (!std::isfinite(kd) || kd < 1.0 || kd > static_cast<double>(kMaxSweepPoints)) {
        return ac_fail(".ac produces too many points");
    }
    const std::size_t count = static_cast<std::size_t>(kd);
    freqs.reserve(count);
    for (std::size_t k = 0; k < count; ++k) {
        freqs.push_back(fstart * std::pow(base, static_cast<double>(k) / n));
    }
    // Grid roundoff may leave the last point a hair above fstop; the
    // endpoint is IN when it lands on the grid (§7.4), never above it.
    if (!freqs.empty() && freqs.back() > fstop) {
        freqs.back() = fstop;
    }
    return freqs;
}

ws::core::Result<Table> run_ac(const Circuit& circuit, RunState& state,
                               const AcCard& card, const RunSettings& settings,
                               const ParamTable& scope, AnalysisReport& report,
                               const std::vector<NodesetCard>& nodeset_cards) {
    if (circuit.devices.empty()) {
        return empty_circuit_error(".ac");
    }

    WS_TRY_ASSIGN(const std::vector<double> freqs, ac_frequency_list(card, scope));
    // §7.2/M5: the .nodeset hints for the OP solve.
    std::vector<std::pair<std::size_t, double>> nodesets;
    if (!nodeset_cards.empty()) {
        WS_TRY_ASSIGN(nodesets, detail::resolve_nodesets(circuit, nodeset_cards));
    }

    DcKernel kernel(circuit, state, settings);
    if (const ws::core::Status st = kernel.prepare(); !st) {
        return wrap_solver_error(st, ".ac");
    }

    // §7.1: the OP is this analysis's own (never borrowed), sources at
    // their DC values; switch states freeze wherever it settles.
    {
        std::vector<double> x_op;
        std::size_t iterations = 0;
        if (const ws::core::Status st = kernel.solve(
                x_op, settings.itl1, ".ac op", iterations, nullptr,
                nodesets.empty() ? nullptr : &nodesets);
            !st) {
            return wrap_solver_error(st, ".ac op");
        }
        report.newton_iterations = iterations;
    }

    // §7.4: a deck with no AC source is an error, never a table of zeros.
    bool any_ac = false;
    for (const auto& dev : circuit.devices) {
        if (dev->has_ac()) {
            any_ac = true;
            break;
        }
    }
    if (!any_ac) {
        Diagnostic d = run_diag(ErrorKind::Semantic, "spice.semantic.ac_stimulus",
                                "no AC stimulus: no source carries an 'AC magnitude'"
                                " spec");
        d.loc = card.loc;
        d.hint = "write e.g. 'V1 in 0 DC 0 AC 1' and re-run";
        return spice_fail(std::move(d));
    }

    if (const ws::core::Status st = kernel.prepare_ac(); !st) {
        return wrap_solver_error(st, ".ac");
    }

    // Fold the bound parameters into the state slices once: the K-coupled
    // inductors' mutual M recomputes from the CURRENT L values (§3.5b),
    // and the switches' settled positions ride their state slots.
    fold_all(circuit, state);

    // Signals: frequency axis, then re()/im() pairs for the default
    // save-list (the locked CSV decision: re()/im(), never mag/phase).
    // The terminal-current probes opt out: they answer a DC solution,
    // not the small-signal system.
    const SaveList save = default_save_list(circuit, false);
    Table t;
    t.analysis = AnalysisKind::Ac;
    t.sweep = SweepKind::Frequency;
    t.sweep_names.push_back("frequency");
    t.sweep_axes.assign(1, {});
    for (const std::string& col : save.columns) {
        Signal re;
        re.name = "re(" + col + ")";
        t.signals.push_back(std::move(re));
        Signal im;
        im.name = "im(" + col + ")";
        t.signals.push_back(std::move(im));
    }

    for (const double f : freqs) {
        std::vector<std::complex<double>> xc;
        {
            char ctx[64];
            std::snprintf(ctx, sizeof(ctx), ".ac at %.6g Hz", f);
            if (const ws::core::Status st =
                     kernel.solve_ac(xc, 2.0 * 3.14159265358979323846 * f, ctx);
                !st) {
                return wrap_solver_error(st, ctx);
            }
        }
        t.sweep_axes[0].push_back(f);
        std::size_t k = 0;
        for (const std::size_t n : save.nodes) {
            t.signals[k++].data.push_back(xc[n].real());
            t.signals[k++].data.push_back(xc[n].imag());
        }
        for (const std::size_t b : save.branches) {
            t.signals[k++].data.push_back(xc[circuit.node_count() + b].real());
            t.signals[k++].data.push_back(xc[circuit.node_count() + b].imag());
        }
    }

    report.analysis = ".ac";
    report.lu_factorizations = kernel.factorizations();
    report.stage = "ac";
    return t;
}

// --- .noise (§7.5, M5) -------------------------------------------------------------

namespace {

// The driver-side NoiseContext: collects one device's sources with their
// adjoint gains folded in (§7.5: one adjoint solve serves every source).
class DriverNoiseContext final : public NoiseContext {
public:
    explicit DriverNoiseContext(
        const std::vector<std::complex<double>>& adjoint)
        : adjoint_(adjoint) {}

    // The owning device's name for this batch of sources (set by the
    // driver between devices): the summary tables read
    // "R1_thermal", "D1_id", "Q1_ib" - ngspice's naming.
    std::string device_name;

    void add_source(const char* name, NodeId p, NodeId n, double psd) override {
        const std::complex<double> xa_p =
            (p == kGround) ? std::complex<double>{0.0, 0.0} : adjoint_[p];
        const std::complex<double> xa_n =
            (n == kGround) ? std::complex<double>{0.0, 0.0} : adjoint_[n];
        const std::complex<double> d = xa_p - xa_n;
        const double gain = d.real() * d.real() + d.imag() * d.imag();
        const std::string full = device_name + "_" + name;
        sources.emplace_back(std::move(full), gain * psd);
    }

    struct Contribution {
        std::string name;      // "R1_thermal", "D1_id", ...
        double out_psd_sq;     // gain * psd, V^2/Hz at the output
    };
    std::vector<Contribution> sources;

private:
    const std::vector<std::complex<double>>& adjoint_;
};

// §7.5: the log-log (power-law) segment integral (ngspice ninteg.c) -
// exact for white and 1/f^k pieces. `ln_*` are pre-logged endpoints.
[[nodiscard]] double noise_integrate(double dens, double ln_dens, double ln_dens_last,
                                     double del_freq, double ln_freq,
                                     double ln_freq_last) {
    const double del_ln_freq = ln_freq - ln_freq_last;
    if (std::abs(del_ln_freq) < 1e-300) {
        return 0.0;
    }
    const double exponent = (ln_dens - ln_dens_last) / del_ln_freq;
    if (std::abs(exponent) < phys::kIntFlatThresh) {
        return dens * del_freq;
    }
    // D = a * f^exponent on this segment; integrate a*f^e df.
    const double a = std::exp(std::min(ln_dens - exponent * ln_freq, 700.0));
    const double exp1 = exponent + 1.0;
    if (std::abs(exp1) < phys::kIntUseLog) {
        return a * (ln_freq - ln_freq_last);
    }
    // limexp guards f^(e+1) against overflow (ninteg.c's limexp).
    auto limexp = [](double x) {
        return x > 700.0 ? std::exp(700.0) * (1.0 + x - 700.0) : std::exp(x);
    };
    return a * (limexp(exp1 * ln_freq) - limexp(exp1 * ln_freq_last)) / exp1;
}

}  // namespace

ws::core::Result<Table> run_noise(const Circuit& circuit, RunState& state,
                                  const NoiseCard& card, const RunSettings& settings,
                                  const ParamTable& scope, AnalysisReport& report,
                                  const std::vector<NodesetCard>& nodeset_cards) {
    if (circuit.devices.empty()) {
        return empty_circuit_error(".noise");
    }

    // The frequency grid: the same generator as .ac (§7.4).
    AcCard grid_card;
    grid_card.loc = card.loc;
    grid_card.sweep = static_cast<AcCard::Sweep>(card.sweep);
    grid_card.n = card.n;
    grid_card.fstart = card.fstart;
    grid_card.fstop = card.fstop;
    WS_TRY_ASSIGN(const std::vector<double> freqs, ac_frequency_list(grid_card, scope));

    // §7.5: the output pair "v(out)" / "v(out,ref)".
    auto noise_fail = [&](std::string message) -> ws::core::unexpected<ws::core::Error> {
        Diagnostic d = run_diag(ErrorKind::Semantic, "spice.semantic.noise",
                                std::move(message));
        d.loc = card.loc;
        return spice_fail(std::move(d));
    };
    const std::string out_text = to_lower(card.output.text);
    NodeId out_node = kGround;
    NodeId ref_node = kGround;
    {
        const std::size_t eq = out_text.find('=');
        const bool ok_form = out_text.rfind("v(", 0) == 0 && out_text.back() == ')' &&
                             eq == std::string::npos;
        const std::size_t close = out_text.rfind(')');
        const std::string inner =
            ok_form ? out_text.substr(2, close - 2) : std::string();
        const std::size_t comma = inner.find(',');
        if (!ok_form || inner.empty()) {
            return noise_fail(".noise output looks like v(out) or v(out,ref), got '" +
                              card.output.text + "'");
        }
        const std::string out_name =
            to_lower(comma == std::string::npos ? inner : inner.substr(0, comma));
        const auto it_out = circuit.node_ids.find(out_name);
        if (it_out == circuit.node_ids.end()) {
            return noise_fail(".noise names unknown output node '" +
                              inner.substr(0, comma == std::string::npos ? inner.size()
                                                                          : comma) +
                              "'");
        }
        out_node = it_out->second;
        if (comma != std::string::npos) {
            const std::string ref_name = to_lower(inner.substr(comma + 1));
            if (ref_name == "0" || ref_name == "gnd") {
                ref_node = kGround;
            } else {
                const auto it_ref = circuit.node_ids.find(ref_name);
                if (it_ref == circuit.node_ids.end()) {
                    return noise_fail(".noise names unknown reference node '" +
                                      inner.substr(comma + 1) + "'");
                }
                ref_node = it_ref->second;
            }
        }
        if (out_node == kGround) {
            return noise_fail(".noise cannot measure the ground node");
        }
    }

    // §7.5: the input source must be an existing V or I device.
    const Device* input_dev = nullptr;
    {
        const std::string lower = to_lower(card.input.text);
        for (const auto& dev : circuit.devices) {
            if (to_lower(dev->name()) == lower) {
                input_dev = dev.get();
                break;
            }
        }
        if (input_dev == nullptr) {
            return noise_fail(".noise names unknown input source '" + card.input.text +
                              "'");
        }
        if (input_dev->kind() != 'V' && input_dev->kind() != 'I') {
            return noise_fail(".noise input '" + card.input.text +
                              "' is not a V or I source");
        }
    }

    // §7.2/M5: the .nodeset hints for the OP solve.
    std::vector<std::pair<std::size_t, double>> nodesets;
    if (!nodeset_cards.empty()) {
        WS_TRY_ASSIGN(nodesets, detail::resolve_nodesets(circuit, nodeset_cards));
    }

    DcKernel kernel(circuit, state, settings);
    if (const ws::core::Status st = kernel.prepare(); !st) {
        return wrap_solver_error(st, ".noise");
    }

    // §7.1: this analysis's own OP, sources at their DC values.
    std::vector<double> x_op;
    {
        std::size_t iterations = 0;
        if (const ws::core::Status st = kernel.solve(
                x_op, settings.itl1, ".noise op", iterations, nullptr,
                nodesets.empty() ? nullptr : &nodesets);
            !st) {
            return wrap_solver_error(st, ".noise op");
        }
        report.newton_iterations = iterations;
    }

    if (const ws::core::Status st = kernel.prepare_ac(); !st) {
        return wrap_solver_error(st, ".noise");
    }
    // The companion mirrors (switch positions, K-coupled M) freeze at the
    // settled OP - the same fold the .ac path runs.
    fold_all(circuit, state);

    Table t;
    t.analysis = AnalysisKind::Noise;
    t.sweep = SweepKind::Frequency;
    t.sweep_names.push_back("frequency");
    t.sweep_axes.assign(1, {});
    Signal onoise;
    onoise.name = "onoise_spectrum";
    Signal inoise;
    inoise.name = "inoise_spectrum";
    t.signals.push_back(std::move(onoise));
    t.signals.push_back(std::move(inoise));

    // The integration state (§7.5): totals over power-law segments, the
    // per-source densities for the summary tables.
    double out_total_sq = 0.0;   // V^2
    double in_total_sq = 0.0;    // V^2 (A^2 for current inputs)
    double ln_f_last = 0.0;
    double ln_on_last = 0.0;
    double ln_in_last = 0.0;
    bool have_last = false;

    for (std::size_t k = 0; k < freqs.size(); ++k) {
        const double f = freqs[k];
        const double omega = 2.0 * 3.14159265358979323846 * f;

        // (a) The forward solve: the AC system with ONLY the input source
        // stamped (1+0j, its declared spec ignored - MODEACNOISE).
        std::vector<std::complex<double>> xc;
        {
            char ctx[64];
            std::snprintf(ctx, sizeof(ctx), ".noise at %.6g Hz", f);
            WS_TRY(kernel.noise_point(omega, input_dev, xc, ctx));
        }

        // (b) The gain H from the input to the output (V per V, or V per
        // A - the input source's own units).
        const std::complex<double> h_out =
            xc[out_node] - (ref_node == kGround ? std::complex<double>{0.0, 0.0}
                                                : xc[ref_node]);
        const double h_sq = h_out.real() * h_out.real() + h_out.imag() * h_out.imag();
        const double gain_sq_inv = 1.0 / std::max(h_sq, phys::kNoiseMinGain);

        // (c) The adjoint solve: A^T x_a = e_out (+1 at out, -1 at ref).
        std::vector<std::complex<double>> x_a;
        {
            std::vector<std::complex<double>> e_out(
                circuit.node_count() + circuit.branch_count,
                std::complex<double>{0.0, 0.0});
            e_out[out_node] = {1.0, 0.0};
            if (ref_node != kGround) {
                e_out[ref_node] = {-1.0, 0.0};
            }
            char ctx[64];
            std::snprintf(ctx, sizeof(ctx), ".noise adjoint at %.6g Hz", f);
            if (const ws::core::Status st = kernel.solve_ac_transpose(e_out, x_a, ctx);
                !st) {
                return wrap_solver_error(st, ctx);
            }
        }

        // (d) Every device's noise sources, folded with the adjoint gain.
        double on_sq = 0.0;  // V^2/Hz at the output
        DriverNoiseContext nctx(x_a);
        nctx.op = &x_op;
        // (The device name is set per device inside the loop below.)
        nctx.freq = f;
        nctx.temp_k = phys::c_to_k(circuit.temp);
        for (std::size_t di = 0; di < circuit.devices.size(); ++di) {
            nctx.params_ = state.params_.data() + circuit.param_span[di].begin;
            nctx.state_ = state.state_.data() + circuit.state_span[di].begin;
            nctx.device_name = circuit.devices[di]->name();
            circuit.devices[di]->load_noise(nctx);
        }
        for (const auto& c : nctx.sources) {
            on_sq += c.out_psd_sq;
        }
        const double in_sq = on_sq * gain_sq_inv;

        // (e) The spectra rows (V/sqrt(Hz); internally V^2/Hz).
        t.sweep_axes[0].push_back(f);
        t.signals[0].data.push_back(std::sqrt(std::max(on_sq, 0.0)));
        t.signals[1].data.push_back(std::sqrt(std::max(in_sq, 0.0)));

        // (f) The totals: power-law segments (exact for white and 1/f^k).
        const double ln_f = std::log(std::max(f, phys::kNoiseMinLog));
        if (have_last) {
            const double ln_on = std::log(std::max(on_sq, phys::kNoiseMinLog));
            const double ln_in = std::log(std::max(in_sq, phys::kNoiseMinLog));
            out_total_sq +=
                noise_integrate(on_sq, ln_on, ln_on_last, f - freqs[k - 1], ln_f, ln_f_last);
            in_total_sq +=
                noise_integrate(in_sq, ln_in, ln_in_last, f - freqs[k - 1], ln_f, ln_f_last);
            ln_on_last = ln_on;
            ln_in_last = ln_in;
        } else {
            ln_on_last = std::log(std::max(on_sq, phys::kNoiseMinLog));
            ln_in_last = std::log(std::max(in_sq, phys::kNoiseMinLog));
            have_last = true;
        }
        ln_f_last = ln_f;

        // (g) The summary table (every pts_per_summary points, the first
        // included - ngspice's step % NStpsSm == 0).
        if (card.pts_per_summary > 0 && k % static_cast<std::size_t>(card.pts_per_summary) == 0) {
            AnalysisReport::NoiseSummary sum;
            sum.freq = f;
            for (const auto& c : nctx.sources) {
                sum.names.push_back(c.name);
                sum.out_density.push_back(std::sqrt(std::max(c.out_psd_sq, 0.0)));
            }
            report.noise_summaries.push_back(std::move(sum));
        }
    }

    report.analysis = ".noise";
    report.lu_factorizations = kernel.factorizations();
    report.stage = "noise";
    report.noise_out_total = std::sqrt(std::max(out_total_sq, 0.0));
    report.noise_in_total = std::sqrt(std::max(in_total_sq, 0.0));
    return t;
}

}  // namespace

// --- compat=strict (§8.3 rev) -------------------------------------------------------

// Rejects the LTspice-only forms the default dialect quietly accepts:
// '{expr}' device values, 'Rser=' on inductors, and 'params:' sections on
// subckt definitions or X cards. Everything the two simulators share -
// plain cards, .param, ic=, .model - is dialect-neutral and stays legal.
ws::core::Status check_compat_strict(const DeckAst& ast) {
    auto reject = [&](SourceLoc loc, const std::string& what,
                      const std::string& instead) {
        Diagnostic d = run_diag(
            ErrorKind::Parse, "spice.parse.compat_strict",
            "rejected by compat=strict: " + what +
                " is an LTspice form; the ngspice spelling is " + instead);
        d.loc = std::move(loc);
        d.hint = ".options compat=ltspice (or ngspice) accepts it";
        return spice_fail(std::move(d));
    };
    for (const DeviceCard& card : ast.devices) {
        const char letter = static_cast<char>(std::toupper(static_cast<unsigned char>(
            card.name.text.empty() ? ' ' : card.name.text[0])));
        for (const Token& tok : card.rest) {
            if (!tok.text.empty() && tok.text.front() == '{') {
                return reject(tok.loc, "'{" + tok.text.substr(1, tok.text.size() > 1 ? tok.text.size() - 1 : 0) +
                                    "...}' values", "a .param name or a plain number");
            }
            if (letter == 'L' && to_lower(tok.text).rfind("rser=", 0) == 0) {
                return reject(tok.loc, "'" + tok.text + "'",
                              "an explicit series resistor device");
            }
            if (letter == 'X' &&
                (to_lower(tok.text) == "params:" || tok.text.find('=') != std::string::npos)) {
                return reject(tok.loc, "subcircuit 'params:' sections",
                              ".subckt pins plus .param definitions");
            }
        }
    }
    for (const auto& [name, def] : ast.subckts) {
        if (!def.defaults.empty()) {
            return reject(def.loc, "params: defaults on .subckt '" + def.name.text + "'",
                          "explicit .param definitions");
        }
    }
    return {};
}

// --- the public entry (run.hpp) --------------------------------------------------------

namespace drivers {

ws::core::Result<Table> run_op(const Circuit& circuit, RunState& state,
                               const RunSettings& settings, AnalysisReport& report,
                               const std::vector<NodesetCard>& nodesets) {
    return ::ws::spice::run_op(circuit, state, settings, report, nodesets);
}

ws::core::Result<Table> run_dc(const DeckAst* ast, const Circuit& base_circuit,
                               const DcCard& card, const RunSettings& settings,
                               std::vector<Warning>& warnings, AnalysisReport& report) {
    // No deck behind this circuit: value sweeps run fine (they only patch
    // parameter slots), but a temperature sweep re-elaborates from the AST
    // (§7.7) - name the limitation instead of guessing.
    if (ast == nullptr) {
        const auto is_temp = [](const DcSweep& sw) {
            return to_lower(sw.source.text) == "temp";
        };
        if (is_temp(card.first) || (card.second && is_temp(*card.second))) {
            Diagnostic d;
            d.kind = ErrorKind::Usage;
            d.code = "spice.usage.dc_temp_no_deck";
            d.message = "a '.dc temp' sweep re-elaborates the deck per point; a"
                        " Simulator-created circuit carries no deck - sweep a"
                        " source value instead";
            d.analysis = ".dc";
            return spice_fail(std::move(d));
        }
        static const DeckAst empty;  // never consulted beyond temp paths
        return ::ws::spice::run_dc(empty, base_circuit, card, settings, warnings, report,
                                   {});
    }
    return ::ws::spice::run_dc(*ast, base_circuit, card, settings, warnings, report, {});
}

ws::core::Result<Table> run_tran(const Circuit& circuit, RunState& state,
                                  const TranCard& card, const RunSettings& settings,
                                  const ParamTable& scope, const std::vector<IcCard>& ics,
                                  AnalysisReport& report,
                                  const std::vector<NodesetCard>& nodesets) {
    return ::ws::spice::run_tran(circuit, state, card, settings, scope, ics, report,
                                 nodesets);
}

ws::core::Result<Table> run_ac(const Circuit& circuit, RunState& state,
                               const AcCard& card, const RunSettings& settings,
                               const ParamTable& scope, AnalysisReport& report,
                               const std::vector<NodesetCard>& nodesets) {
    return ::ws::spice::run_ac(circuit, state, card, settings, scope, report, nodesets);
}

ws::core::Result<Table> run_noise(const Circuit& circuit, RunState& state,
                                  const NoiseCard& card, const RunSettings& settings,
                                  const ParamTable& scope, AnalysisReport& report,
                                  const std::vector<NodesetCard>& nodesets) {
    return ::ws::spice::run_noise(circuit, state, card, settings, scope, report,
                                  nodesets);
}

}  // namespace drivers

// --- .step point enumeration (§7.6) ---------------------------------------------

// One point of the (nested) step family: the overridden param values, the
// elaboration temperature (temp steps), the swept source values, and the
// 1-based point number.
struct StepPoint {
    std::vector<std::pair<std::string, double>> params;  // (lowercased name, value)
    std::vector<std::pair<std::string, double>> sources;  // swept source dc values
    double temp = kDefaultTemp;
    bool temp_from_step = false;  // a temp step card set it
    std::size_t number = 1;
    std::string spell;  // "rload=2k, run=3" - error context
};

// Materializes one StepCard's values (lin/list/dec/oct grids, the §7.3
// guards: finite, nonzero step, direction, count cap).
ws::core::Result<std::vector<double>> step_values(const StepCard& card,
                                                  const ParamTable& scope) {
    auto eval = [&](const ExprProgram& p) -> ws::core::Result<double> {
        WS_TRY_ASSIGN(const std::vector<std::optional<double>> b, scope.bind(p));
        WS_TRY_ASSIGN(const double v, p.evaluate(b));
        return v;
    };
    auto fail = [&](std::string m) -> ws::core::unexpected<ws::core::Error> {
        Diagnostic d = run_diag(ErrorKind::Semantic, "spice.semantic.step", std::move(m));
        d.loc = card.loc;
        return spice_fail(std::move(d));
    };
    std::vector<double> out;
    switch (card.kind) {
        case StepCard::Kind::List: {
            for (const ExprProgram& p : card.list) {
                WS_TRY_ASSIGN(const double v, eval(p));
                out.push_back(v);
            }
            return out;
        }
        case StepCard::Kind::Dec:
        case StepCard::Kind::Oct: {
            WS_TRY_ASSIGN(const double start, eval(card.start));
            WS_TRY_ASSIGN(const double stop, eval(card.stop));
            WS_TRY_ASSIGN(const double n, eval(card.inc));  // N in this form
            if (!std::isfinite(start) || !std::isfinite(stop) || !std::isfinite(n) ||
                n < 1.0 || std::floor(n) != n) {
                return fail(".step dec/oct needs a positive integer N");
            }
            if (!(start > 0.0) || !(stop >= start)) {
                return fail(".step dec/oct needs 0 < start <= stop");
            }
            const double base = (card.kind == StepCard::Kind::Dec) ? 10.0 : 2.0;
            const double log_ratio = (card.kind == StepCard::Kind::Dec)
                                         ? std::log10(stop / start)
                                         : std::log2(stop / start);
            const double kd = std::floor(n * log_ratio + 1e-9) + 1.0;
            if (!std::isfinite(kd) || kd < 1.0 ||
                kd > static_cast<double>(kMaxSweepPoints)) {
                return fail(".step produces too many points");
            }
            for (std::size_t k = 0; k < static_cast<std::size_t>(kd); ++k) {
                out.push_back(start * std::pow(base, static_cast<double>(k) / n));
            }
            if (!out.empty() && out.back() > stop) {
                out.back() = stop;
            }
            return out;
        }
        case StepCard::Kind::Lin: {
            WS_TRY_ASSIGN(const double start, eval(card.start));
            WS_TRY_ASSIGN(const double stop, eval(card.stop));
            WS_TRY_ASSIGN(const double inc, eval(card.inc));
            if (!std::isfinite(start) || !std::isfinite(stop) || !std::isfinite(inc)) {
                return fail(".step values must be finite");
            }
            if (inc == 0.0) {
                return fail(".step increment is zero");
            }
            if ((stop > start && inc < 0.0) || (stop < start && inc > 0.0)) {
                return fail(".step increment must point toward stop");
            }
            const double span = stop - start;
            const double intervals = std::floor(span / inc + 1e-9);
            if (!std::isfinite(span) || !std::isfinite(intervals) || intervals < 0.0) {
                return fail(".step range is out of range");
            }
            const double points = intervals + 1.0;
            if (points > static_cast<double>(kMaxSweepPoints)) {
                return fail(".step produces too many points");
            }
            for (std::size_t k = 0; k < static_cast<std::size_t>(points); ++k) {
                out.push_back(start + static_cast<double>(k) * inc);
            }
            return out;
        }
    }
    return fail("internal: unhandled .step kind");
}

// The cartesian product, first card outermost (§7.6).
ws::core::Result<std::vector<StepPoint>> enumerate_steps(
    const std::vector<StepCard>& cards, const ParamTable& scope, double base_temp) {
    std::vector<StepPoint> points(1);  // the empty product
    points[0].temp = base_temp;
    for (const StepCard& card : cards) {
        WS_TRY_ASSIGN(const std::vector<double> values, step_values(card, scope));
        // Cap the cartesian product, not just each axis. Two cards each at
        // kMaxSweepPoints would otherwise try to reserve ~10^12 entries here
        // and abort with std::bad_alloc before any analysis runs (the
        // per-card cap above only guards a single axis). The product cap
        // matches the per-card cap: anything past 1M total points is a typo,
        // not a real sweep. Use double arithmetic so the check is robust on
        // 32-bit size_t as well (1M * 1M overflows uint32_t).
        const double product_d =
            static_cast<double>(points.size()) * static_cast<double>(values.size());
        if (!std::isfinite(product_d) ||
            product_d > static_cast<double>(kMaxSweepPoints)) {
            Diagnostic d = run_diag(
                ErrorKind::Semantic, "spice.semantic.step_product",
                ".step cartesian product exceeds " +
                    std::to_string(kMaxSweepPoints) + " points (" +
                    std::to_string(points.size()) + " x " +
                    std::to_string(values.size()) +
                    " on .step " + card.name.text +
                    ") - narrow the ranges or split into separate runs");
            d.loc = card.loc;
            return spice_fail(std::move(d));
        }
        const std::size_t product = static_cast<std::size_t>(product_d);
        std::vector<StepPoint> next;
        next.reserve(product);
        for (const StepPoint& p : points) {
            for (const double v : values) {
                StepPoint q = p;
                if (card.is_temp) {
                    q.temp = v;
                    q.temp_from_step = true;
                } else if (card.is_source) {
                    q.sources.emplace_back(to_lower(card.name.text), v);
                } else {
                    q.params.emplace_back(to_lower(card.name.text), v);
                }
                next.push_back(std::move(q));
            }
        }
        points = std::move(next);
    }
    for (std::size_t i = 0; i < points.size(); ++i) {
        points[i].number = i + 1;
        for (const auto& [name, v] : points[i].params) {
            points[i].spell +=
                (points[i].spell.empty() ? std::string() : std::string(", ")) +
                name + "=" + fmt_value(v);
        }
        for (const auto& [name, v] : points[i].sources) {
            points[i].spell +=
                (points[i].spell.empty() ? std::string() : std::string(", ")) +
                name + "=" + fmt_value(v);
        }
        if (points[i].temp_from_step) {
            points[i].spell +=
                (points[i].spell.empty() ? std::string() : std::string(", ")) +
                "temp=" + fmt_value(points[i].temp);
        }
    }
    return points;
}

// Merges one point's analysis table into the family table: the step axes
// prepend (step number, then each stepped quantity), the analysis's own
// axes and signals append.
void merge_into_family(Table& family, const Table& point, const StepPoint& sp,
                        const std::vector<std::string>& step_names) {
    if (family.signals.empty()) {
        family.analysis = point.analysis;
        family.sweep = point.sweep;
        family.sweep_names.push_back("step");
        for (const std::string& n : step_names) {
            family.sweep_names.push_back(n);
        }
        for (const std::string& n : point.sweep_names) {
            family.sweep_names.push_back(n);
        }
        family.sweep_axes.assign(family.sweep_names.size(), {});
        family.signals = point.signals;  // names
        for (Signal& sig : family.signals) {
            sig.data.clear();
        }
        // The leading family axes: "step" + one per stepped quantity.
        family.step_axes = 1 + step_names.size();
    }
    const std::size_t n = point.row_count();
    for (std::size_t i = 0; i < n; ++i) {
        family.sweep_axes[0].push_back(static_cast<double>(sp.number));
        std::size_t ax = 1;
        for (const auto& [name, v] : sp.params) {
            (void)name;
            family.sweep_axes[ax++].push_back(v);
        }
        for (const auto& [name, v] : sp.sources) {
            (void)name;
            family.sweep_axes[ax++].push_back(v);
        }
        if (sp.temp_from_step) {
            family.sweep_axes[ax++].push_back(sp.temp);
        }
        for (const auto& a : point.sweep_axes) {
            family.sweep_axes[ax++].push_back(i < a.size() ? a[i] : 0.0);
        }
        std::size_t k = 0;
        for (const Signal& sig : point.signals) {
            family.signals[k++].data.push_back(i < sig.data.size() ? sig.data[i] : 0.0);
        }
    }
}


// --- the public entry (run.hpp) --------------------------------------------------------



// --- .save/.print expression columns (§0.5 rev) ------------------------------------

// Rewrites a completed table's signals to the deck's REQUESTED save-list
// expressions, evaluated POST-HOC over the stored default columns (every
// node voltage and branch current is already there, §0.5) plus the bound
// @dev[param] values - no hidden B sources, no re-solve. AC tables
// reject expressions (their columns are re()/im() pairs; vm()/vp() land
// with the AC derived forms, §7.4).
ws::core::Status apply_save_expressions(Table& t, const Circuit& c,
                                         const RunState& state,
                                         const std::vector<SaveCard>& saves) {
    // Collect this analysis's requested expressions (.save applies to
    // every analysis; .print names one).
    const auto kind_of = [](MeasCard::Analysis a) {
        switch (a) {
            case MeasCard::Analysis::Tran: return AnalysisKind::Tran;
            case MeasCard::Analysis::Dc: return AnalysisKind::Dc;
            case MeasCard::Analysis::Ac: return AnalysisKind::Ac;
            case MeasCard::Analysis::Op: return AnalysisKind::Op;
        }
        return AnalysisKind::Op;
    };
    std::vector<std::pair<Token, ExprProgram>> wanted;
    for (const SaveCard& sv : saves) {
        if (!sv.all_analyses && kind_of(sv.which) != t.analysis) {
            continue;
        }
        for (const Token& e : sv.exprs) {
            const ws::core::Result<ExprProgram> prog = parse_expression(e.text);
            if (!prog) {
                Diagnostic d = run_diag(ErrorKind::Parse, "spice.parse.save_expr",
                                        prog.error().message);
                d.loc = e.loc;
                return spice_fail(std::move(d));
            }
            wanted.emplace_back(e, *prog);
        }
    }
    // An expression that merely names a sweep axis ('time', 'frequency')
    // is the axis itself - already in the output; drop it instead of
    // duplicating the column.
    wanted.erase(std::remove_if(wanted.begin(), wanted.end(),
                                [&](const std::pair<Token, ExprProgram>& w) {
                                    return std::any_of(
                                        t.sweep_names.begin(), t.sweep_names.end(),
                                        [&](const std::string& ax) {
                                            return to_lower(w.first.text) ==
                                                   to_lower(ax);
                                        });
                                }),
                 wanted.end());
    if (wanted.empty()) {
        return {};
    }
    if (t.analysis == AnalysisKind::Ac) {
        Diagnostic d = run_diag(
            ErrorKind::Semantic, "spice.semantic.save_ac",
            "expression save-lists over .ac land with the vm()/vp() derived"
            " forms (§7.4); .print ac re(v(out)) im(v(out)) works today");
        d.analysis = ".ac";
        return spice_fail(std::move(d));
    }

    // Column lookup, case-insensitive (expressions lowercase their
    // references; display spellings name the columns). The sweep axes are
    // pseudo-columns ('time', 'frequency', a swept source's name).
    std::map<std::string, const std::vector<double>*> columns;
    for (const Signal& sig : t.signals) {
        columns[to_lower(sig.name)] = &sig.data;
    }
    for (std::size_t k = 0; k < t.sweep_names.size(); ++k) {
        const std::string lower = to_lower(t.sweep_names[k]);
        if (k < t.sweep_axes.size()) {
            columns.emplace(lower, &t.sweep_axes[k]);
        }
    }
    auto column = [&](const std::string& lower) -> const std::vector<double>* {
        const auto it = columns.find(lower);
        return (it == columns.end()) ? nullptr : it->second;
    };

    const std::size_t n = t.row_count();
    std::vector<Signal> out_signals;
    out_signals.reserve(wanted.size());

    for (auto& [tok, prog] : wanted) {
        Signal sig;
        sig.name = tok.text;
        sig.data.reserve(n);
        // Bind each variable once per sample; v(a,b) unfolds to the two
        // columns' difference, @dev[param] to the bound value.
        const std::vector<std::string>& vars = prog.vars();
        std::vector<std::optional<double>> binds(vars.size());
        std::vector<const std::vector<double>*> var_col(vars.size(), nullptr);
        std::vector<std::pair<const std::vector<double>*, const std::vector<double>*>>
            var_diff(vars.size(), {nullptr, nullptr});
        std::vector<double> var_const(vars.size(), 0.0);
        for (std::size_t vi = 0; vi < vars.size(); ++vi) {
            const std::string& v = vars[vi];
            if (v.rfind("v(", 0) == 0 && v.back() == ')' &&
                v.find(',') != std::string::npos) {
                // v(a,b): differential.
                const std::size_t comma = v.find(',');
                const std::string pa = "v(" + v.substr(2, comma - 2) + ")";
                const std::string pb = "v(" + v.substr(comma + 1, v.size() - comma - 2) +
                                       ")";
                var_diff[vi] = {column(pa), column(pb)};
                if (var_diff[vi].first == nullptr || var_diff[vi].second == nullptr) {
                    Diagnostic d = run_diag(
                        ErrorKind::Semantic, "spice.semantic.save_unknown",
                        "expression '" + tok.text + "' references unknown node '" +
                            (var_diff[vi].first == nullptr ? pa : pb) + "'");
                    d.loc = tok.loc;
                    return spice_fail(std::move(d));
                }
            } else if (v.rfind("@", 0) == 0) {
                // @dev[param].
                const std::size_t lb = v.find('[');
                const std::size_t rb = v.rfind(']');
                const std::string dev = v.substr(1, lb - 1);
                const std::string param = v.substr(lb + 1, rb - lb - 1);
                const auto slot = RunState::param_slot(c, dev, param);
                if (!slot) {
                    Diagnostic d = run_diag(
                        ErrorKind::Semantic, "spice.semantic.save_unknown",
                        "expression '" + tok.text + "' references @" + dev + "[" +
                            param + "], which no device carries (model quantities"
                            " like gm land with the semiconductor models, M4)");
                    d.loc = tok.loc;
                    return spice_fail(std::move(d));
                }
                var_const[vi] =
                    state.params()[c.param_span[slot->first].begin + slot->second];
                var_col[vi] = nullptr;
            } else {
                var_col[vi] = column(v);
                if (var_col[vi] == nullptr) {
                    Diagnostic d = run_diag(
                        ErrorKind::Semantic, "spice.semantic.save_unknown",
                        "expression '" + tok.text + "' references unknown signal '" +
                            v + "'");
                    d.loc = tok.loc;
                    return spice_fail(std::move(d));
                }
            }
        }
        for (std::size_t i = 0; i < n; ++i) {
            for (std::size_t vi = 0; vi < vars.size(); ++vi) {
                if (var_diff[vi].first != nullptr) {
                    binds[vi] = (*var_diff[vi].first)[i] - (*var_diff[vi].second)[i];
                } else if (var_col[vi] != nullptr) {
                    binds[vi] = (*var_col[vi])[i];
                } else {
                    binds[vi] = var_const[vi];
                }
            }
            const ws::core::Result<double> r = prog.evaluate(binds);
            if (!r) {
                Diagnostic d = run_diag(ErrorKind::Semantic, "spice.semantic.save_eval",
                                        "expression '" + tok.text + "': " +
                                            r.error().message);
                d.loc = tok.loc;
                return spice_fail(std::move(d));
            }
            sig.data.push_back(*r);
        }
        out_signals.push_back(std::move(sig));
    }
    t.signals = std::move(out_signals);
    return {};
}

// --- .meas evaluation (§0.4) -------------------------------------------------------

// Evaluates one MeasCard against a completed table. The modes map 1:1
// onto the measure:: library (measure.hpp) - this function is the thin
// parser half: names resolve to columns, levels to numbers, then the
// library does the work.
ws::core::Result<Measurement> evaluate_meas(const MeasCard& m, const Table& t,
                                            const ParamTable& scope) {
    auto note_fail = [&](std::string note) {
        Measurement out;
        out.name = m.result.text;
        switch (m.analysis) {
            case MeasCard::Analysis::Tran: out.analysis = ".tran"; break;
            case MeasCard::Analysis::Dc: out.analysis = ".dc"; break;
            case MeasCard::Analysis::Ac: out.analysis = ".ac"; break;
            case MeasCard::Analysis::Op: out.analysis = ".op"; break;
        }
        out.note = std::move(note);
        return out;
    };
    auto eval_level = [&](const ExprProgram& p) -> ws::core::Result<double> {
        WS_TRY_ASSIGN(const std::vector<std::optional<double>> b, scope.bind(p));
        WS_TRY_ASSIGN(const double v, p.evaluate(b));
        return v;
    };
    auto sig_of = [&](const Token& name) -> std::optional<std::span<const double>> {
        const std::span<const double> s = t.signal(name.text);
        if (s.empty()) {
            return std::nullopt;
        }
        return s;
    };
    const auto win = [&]() -> measure::Window {
        if (!m.has_from && !m.has_to) {
            return measure::Window::all();
        }
        double a = t.axis().empty() ? 0.0 : t.axis().front();
        double b = t.axis().empty() ? 0.0 : t.axis().back();
        if (m.has_from) {
            if (const auto v = eval_level(m.from)) {
                a = *v;
            }
        }
        if (m.has_to) {
            if (const auto v = eval_level(m.to)) {
                b = *v;
            }
        }
        return measure::Window::between(a, b);
    };
    auto dir_of = [](bool fall) {
        return fall ? measure::Dir::Fall : measure::Dir::Rise;
    };

    // .op tables carry a single sample and no axis: only the point-wise
    // modes make sense there.
    if (m.analysis == MeasCard::Analysis::Op &&
        (m.mode == MeasCard::Mode::TrigTarg || m.mode == MeasCard::Mode::When ||
         m.mode == MeasCard::Mode::FindWhen || m.mode == MeasCard::Mode::FindAt ||
         m.mode == MeasCard::Mode::Deriv)) {
        return note_fail("this measurement needs a swept axis; .op has none");
    }

    std::optional<double> v;
    std::string why;
    switch (m.mode) {
        case MeasCard::Mode::TrigTarg: {
            const auto trig = sig_of(m.trig_sig);
            const auto targ = sig_of(m.targ_sig);
            if (!trig || !targ) {
                return note_fail("unknown signal '" +
                                 (!trig ? m.trig_sig.text : m.targ_sig.text) + "'");
            }
            WS_TRY_ASSIGN(const double lv, eval_level(m.level));
            WS_TRY_ASSIGN(const double tv, eval_level(m.targ_level));
            v = measure::trig_targ(t.axis(), *trig, lv, dir_of(m.trig_fall), m.rise,
                                   t.axis(), *targ, tv, dir_of(m.targ_fall),
                                   m.targ_rise);
            why = "the TRIG/TARG crossings never happened in the window";
            break;
        }
        case MeasCard::Mode::When: {
            const auto sig = sig_of(m.when_sig);
            if (!sig) {
                return note_fail("unknown signal '" + m.when_sig.text + "'");
            }
            WS_TRY_ASSIGN(const double lv, eval_level(m.level));
            v = measure::cross_time_n(t.axis(), *sig, lv, dir_of(m.when_fall), m.rise,
                                      win());
            why = "the level was never crossed in the window";
            break;
        }
        case MeasCard::Mode::FindWhen: {
            const auto sig = sig_of(m.find_sig);
            const auto when = sig_of(m.when_sig);
            if (!sig) {
                return note_fail("unknown signal '" + m.find_sig.text + "'");
            }
            if (!when) {
                return note_fail("unknown signal '" + m.when_sig.text + "'");
            }
            WS_TRY_ASSIGN(const double lv, eval_level(m.level));
            v = measure::find_when(t.axis(), *sig, *when, lv, dir_of(m.when_fall), win());
            why = "the WHEN level was never crossed in the window";
            break;
        }
        case MeasCard::Mode::FindAt:
        case MeasCard::Mode::Deriv: {
            const auto sig = sig_of(m.sig.text.empty() ? m.find_sig : m.sig);
            if (!sig) {
                return note_fail("unknown signal '" +
                                 (m.sig.text.empty() ? m.find_sig.text : m.sig.text) +
                                 "'");
            }
            WS_TRY_ASSIGN(const double at, eval_level(m.at));
            v = (m.mode == MeasCard::Mode::Deriv)
                    ? measure::derivative_at(t.axis(), *sig, at)
                    : measure::find_at(t.axis(), *sig, at);
            why = "AT= lies outside the axis range";
            break;
        }
        case MeasCard::Mode::Avg:
        case MeasCard::Mode::Rms:
        case MeasCard::Mode::Integ: {
            const auto sig = sig_of(m.sig);
            if (!sig) {
                return note_fail("unknown signal '" + m.sig.text + "'");
            }
            if (t.row_count() < 2) {
                // .op: the single sample is its own average/extreme.
                v = sig->front();
                break;
            }
            v = (m.mode == MeasCard::Mode::Avg) ? measure::average(t.axis(), *sig, win())
                : (m.mode == MeasCard::Mode::Rms) ? measure::rms(t.axis(), *sig, win())
                                                  : measure::integral(t.axis(), *sig, win());
            why = "the window holds no samples";
            break;
        }
        case MeasCard::Mode::Max:
        case MeasCard::Mode::Min:
        case MeasCard::Mode::Pp: {
            const auto sig = sig_of(m.sig);
            if (!sig) {
                return note_fail("unknown signal '" + m.sig.text + "'");
            }
            v = (m.mode == MeasCard::Mode::Max) ? measure::maximum(*sig, win())
                : (m.mode == MeasCard::Mode::Min) ? measure::minimum(*sig, win())
                                                  : measure::peak_to_peak(*sig, win());
            why = "the signal is empty";
            break;
        }
    }

    Measurement out;
    out.name = m.result.text;
    switch (m.analysis) {
        case MeasCard::Analysis::Tran: out.analysis = ".tran"; break;
        case MeasCard::Analysis::Dc: out.analysis = ".dc"; break;
        case MeasCard::Analysis::Ac: out.analysis = ".ac"; break;
        case MeasCard::Analysis::Op: out.analysis = ".op"; break;
    }
    if (v.has_value()) {
        out.value = *v;
    } else {
        out.note = why.empty() ? "measurement could not be made" : why;
    }
    return out;
}

// Splits a .step family table into its per-point tables - a plain
// table is its own single slice. .meas/.four must see the analysis's
// own axis, never the step column (§7.6's classic family-table
// mistake), so the leading step axes drop out of every part.
[[nodiscard]] std::vector<Table> family_parts(const Table& f) {
    std::vector<Table> parts;
    if (f.step_axes == 0 || f.row_count() == 0) {
        parts.push_back(f);
        return parts;
    }
    const std::vector<double>& steps = f.sweep_axes[0];
    std::size_t i = 0;
    while (i < steps.size()) {
        const double k = steps[i];
        std::size_t j = i;
        while (j < steps.size() && steps[j] == k) {
            ++j;
        }
        Table t;
        t.analysis = f.analysis;
        t.sweep = f.sweep;
        for (std::size_t a = f.step_axes; a < f.sweep_names.size(); ++a) {
            t.sweep_names.push_back(f.sweep_names[a]);
            t.sweep_axes.emplace_back(f.sweep_axes[a].begin() +
                                          static_cast<std::ptrdiff_t>(i),
                                      f.sweep_axes[a].begin() +
                                          static_cast<std::ptrdiff_t>(j));
        }
        for (const Signal& sig : f.signals) {
            Signal c;
            c.name = sig.name;
            c.data.assign(sig.data.begin() + static_cast<std::ptrdiff_t>(i),
                          sig.data.begin() + static_cast<std::ptrdiff_t>(j));
            t.signals.push_back(std::move(c));
        }
        parts.push_back(std::move(t));
        i = j;
    }
    return parts;
}

// Evaluates one .four signal against a completed (per-point) table:
// the fourier:: library does the series, this half resolves the card's
// numbers and the signal column. A .op table (or a degenerate one-row
// .tran) answers the DC component alone - harmonics need a time axis.
Fourier evaluate_four(const FourCard& f, const Token& sig_tok, const Table& t,
                      const ParamTable& scope) {
    Fourier out;
    out.signal = sig_tok.text;
    out.analysis = t.analysis == AnalysisKind::Tran ? ".tran" : ".op";
    auto eval_num = [&](const ExprProgram& p) -> ws::core::Result<double> {
        WS_TRY_ASSIGN(const std::vector<std::optional<double>> b, scope.bind(p));
        WS_TRY_ASSIGN(const double v, p.evaluate(b));
        return v;
    };
    const auto freq = eval_num(f.freq);
    if (!freq) {
        out.note = "fundamental: " + freq.error().message;
        return out;
    }
    out.fundamental = *freq;
    const auto count = eval_num(f.nharms);
    if (!count) {
        out.note = "harmonics: " + count.error().message;
        return out;
    }
    if (*count < 1.0 || *count > 10000.0 || *count != std::floor(*count)) {
        out.note = "the harmonic count must be a whole number between 1 and 10000";
        return out;
    }
    const std::span<const double> sig = t.signal(sig_tok.text);
    if (sig.empty()) {
        out.note = "unknown signal '" + sig_tok.text + "'";
        return out;
    }
    if (t.analysis != AnalysisKind::Tran || t.row_count() < 2) {
        // .op: one sample, no time axis - the DC component is the answer.
        out.dc = sig.front();
        return out;
    }
    const fourier::Series s =
        fourier::series(t.axis(), sig, *freq, static_cast<int>(*count));
    out.periods = s.periods;
    out.dc = s.dc;
    out.thd_percent = s.thd_percent;
    out.note = std::move(s.note);
    out.harmonics.reserve(s.harmonics.size());
    for (const fourier::Harmonic& h : s.harmonics) {
        FourierHarmonic r;
        r.n = h.n;
        r.freq = h.freq;
        r.magnitude = h.magnitude;
        r.phase_deg = h.phase_deg;
        r.normalized = h.normalized;
        out.harmonics.push_back(r);
    }
    return out;
}

ws::core::Result<RunOutput> run_deck(const DeckAst& ast, RunSettings settings,
                                     std::vector<Warning>& warnings) {
    // .options override the caller's defaults, later cards win (§5.1).
    WS_TRY(apply_options(ast.options, settings));

    // §8.3 rev: strict rejects the LTspice-only accommodations instead of
    // silently accepting everything (the deck says what it wants to be).
    if (settings.compat == "strict") {
        WS_TRY(check_compat_strict(ast));
    }

    // The parser can only build exactly one analysis kind per card, but
    // DeckAst is a public type: a hand-built AST could carry none or
    // several. Reject those up front instead of silently skipping the
    // card (working-rule 5).
    for (const AnalysisCard& card : ast.analyses) {
        const int kinds = (card.op ? 1 : 0) + (card.dc ? 1 : 0) + (card.tran ? 1 : 0) +
                          (card.ac ? 1 : 0) + (card.noise ? 1 : 0);
        if (kinds != 1) {
            Diagnostic d = run_diag(
                ErrorKind::Semantic, "spice.semantic.analysis_card",
                kinds == 0
                    ? "analysis card carries neither .op nor .dc"
                    : "analysis card carries more than one analysis"
                      " (both .op and .dc, say)");
            d.loc = card.loc;
            return spice_fail(std::move(d));
        }
    }

    ParamTable global;
    for (const ParamDef& def : ast.params) {
        global.define(def);
    }
    if (ast.steps.empty()) {
        // Cycle check (§8.4) on the plain scope. A stepped run checks per
        // point (the elaborator's own eager pass, with the point's
        // overrides in scope); here a gauss()/flat() definition defers to
        // run time (§8.5 rev).
        for (const ParamDef& def : ast.params) {
            const ws::core::Result<double> v = global.value(to_lower(def.name.text));
            if (!v && v.error().category == std::string("spice") &&
                v.error().message.find("needs a random context") != std::string::npos) {
                continue;
            }
            WS_TRY(v);
        }
    }

    // The step family (§7.6): the cartesian product of the .step cards,
    // first card outermost. Without .step cards this is the single empty
    // point - the plain run.
    WS_TRY_ASSIGN(const std::vector<StepPoint> points,
                  enumerate_steps(ast.steps, global, settings.temp));

    // Step names for the family axes: the stepped params (then sources,
    // then temp) in card order.
    std::vector<std::string> step_names;
    for (const StepCard& card : ast.steps) {
        step_names.push_back(card.name.text);
    }

    // Elaboration: a stepped run elaborates per point (the stepped params
    // are elaboration-scope values - devices referencing them bake in at
    // the point's number, and a temp step re-elaborates at ITS value,
    // §7.7); a plain run elaborates once.
    std::optional<Circuit> base;
    if (ast.steps.empty()) {
        WS_TRY_ASSIGN(base, elaborate_deck(ast, settings.temp, warnings));
    }

    // The Monte-Carlo source (§8.5 rev): one stream per run, advanced
    // point by point - the recorded seed reproduces the whole family.
    Rand rng(settings.seed);

    RunOutput out;
    out.seed = settings.seed;
    std::vector<Table> family(ast.analyses.size());
    std::vector<std::string> failure_list;
    bool elaborated_any_devices = false;

    for (const StepPoint& sp : points) {
        if (run_stop_requested(settings)) {
            return cancelled_run_error();
        }
        // The point's scope: global defs + the stepped constants. A
        // re-definition clears that name's resolve cache, so devices and
        // .params referencing the stepped name re-draw correctly.
        ParamTable scope(global);
        for (const auto& [name, v] : sp.params) {
            ParamDef def;
            def.name.text = name;
            def.expr = ExprProgram::constant(v);
            scope.define(std::move(def));
        }

        // The circuit for this point: the plain run's single elaboration,
        // or a per-point elaboration carrying the stepped values.
        Circuit point_circuit;
        if (base.has_value()) {
            point_circuit = std::move(*base);
            base.reset();  // the single plain point consumed it
        } else {
            std::vector<Warning> scratch;  // identical modulo the step values
            ws::core::Result<Circuit> re =
                elaborate_deck(ast, sp.temp, scratch, &sp.params);
            if (!re) {
                Diagnostic d = run_diag(ErrorKind::Semantic,
                                        "spice.semantic.step_elaborate",
                                        "step point {" + sp.spell +
                                            "}: " + re.error().message);
                return spice_fail(std::move(d));
            }
            point_circuit = std::move(*re);
        }
        const Circuit* live = &point_circuit;
        if (live->devices.empty()) {
            return empty_circuit_error("");
        }
        elaborated_any_devices = true;

        // Each analysis binds a FRESH RunState against the point's scope
        // (the §3.5 rev reset) and appends into its family table. A bind
        // failure (a Monte-Carlo draw outside a device's domain, a
        // check_params rejection) carries the step context.
        for (std::size_t ai = 0; ai < ast.analyses.size(); ++ai) {
            if (run_stop_requested(settings)) {
                return cancelled_run_error();
            }
            const AnalysisCard& card = ast.analyses[ai];
            ws::core::Result<RunState> bound = RunState::bind(*live, &scope, &rng);
            if (!bound) {
                if (ast.steps.empty()) {
                    return ws::core::unexpected<ws::core::Error>(bound.error());
                }
                Diagnostic d = run_diag(
                    ErrorKind::Semantic, "spice.semantic.step_failed",
                    "step point {" + sp.spell + "}: " + bound.error().message);
                if (!settings.keep_going) {
                    return spice_fail(std::move(d));
                }
                failure_list.push_back("step " + std::to_string(sp.number) + " {" +
                                       sp.spell + "}: " + bound.error().message);
                continue;
            }
            RunState state = std::move(*bound);
            // Swept sources patch their dc slot (values only, §3.5 rev).
            for (const auto& [name, v] : sp.sources) {
                if (const auto di = RunState::device_index(*live, name)) {
                    if (live->param_span[*di].count > 0) {
                        state.params_[live->param_span[*di].begin] = v;
                    }
                }
            }
            AnalysisReport report;
            ws::core::Result<Table> t = ws::core::unexpected<ws::core::Error>(
                ws::core::make_error(1, "spice", "internal: no analysis"));
            if (card.op) {
                t = run_op(*live, state, settings, report, ast.nodesets);
            } else if (card.dc) {
                t = run_dc(ast, *live, *card.dc, settings, warnings, report,
                           ast.nodesets);
            } else if (card.tran) {
                t = run_tran(*live, state, *card.tran, settings, scope, ast.ics, report,
                             ast.nodesets);
            } else if (card.noise) {
                t = run_noise(*live, state, *card.noise, settings, scope, report,
                              ast.nodesets);
            } else {
                t = run_ac(*live, state, *card.ac, settings, scope, report,
                           ast.nodesets);
            }
            if (!t) {
                if (t.error().category == std::string("spice") &&
                    t.error().code == static_cast<std::int32_t>(ErrorKind::Cancelled)) {
                    // A stop is not a step failure: never wrapped as
                    // "step point {..} failed", never absorbed by keep_going.
                    return ws::core::unexpected<ws::core::Error>(t.error());
                }
                if (ast.steps.empty()) {
                    // A plain run: the driver's own diagnostic reaches the
                    // caller untouched (the §9 taxonomy, never re-branded).
                    return ws::core::unexpected<ws::core::Error>(t.error());
                }
                // §7.6: abort naming the step point; --keep-going runs the
                // rest and reports the list at the end.
                Diagnostic d = run_diag(ErrorKind::Semantic, "spice.semantic.step_failed",
                                        "step point {" + sp.spell +
                                            "} failed: " + t.error().message);
                if (!settings.keep_going) {
                    return spice_fail(std::move(d));
                }
                failure_list.push_back("step " + std::to_string(sp.number) + " {" +
                                       sp.spell + "}: " + t.error().message);
                continue;
            }
            // §0.5 rev: the deck's requested save-list expressions,
            // evaluated post-hoc while this point's state is live (the
            // @dev[param] values are per point in a family).
            if (!ast.saves.empty()) {
                WS_TRY(apply_save_expressions(*t, *live, state, ast.saves));
            }
            if (ast.steps.empty()) {
                // No .step cards: the point's table IS the result (no
                // leading step column - the plain §0.5 shape).
                out.results.tables.push_back(std::move(*t));
            } else {
                merge_into_family(family[ai], *t, sp, step_names);
            }
            out.reports.push_back(std::move(report));
        }
    }

    // A stepped run's family tables replace the per-point ones (§7.6: one
    // file holds the whole family, a leading step axis per §7.6).
    if (!ast.steps.empty()) {
        for (std::size_t ai = 0; ai < ast.analyses.size(); ++ai) {
            if (!family[ai].signals.empty()) {
                out.results.tables.push_back(std::move(family[ai]));
            }
        }
    }

    // .meas (§0.4): evaluate every card against its analysis's completed
    // table - per step point for a family (ngspice measures each run;
    // the results carry @2, @3, ... suffixes), once for a plain table.
    // Failures are notes, never run failures (§9.5).
    for (const MeasCard& m : ast.meas) {
        const AnalysisKind want = (m.analysis == MeasCard::Analysis::Tran)
                                      ? AnalysisKind::Tran
                                  : (m.analysis == MeasCard::Analysis::Dc)
                                      ? AnalysisKind::Dc
                                  : (m.analysis == MeasCard::Analysis::Ac)
                                      ? AnalysisKind::Ac
                                      : AnalysisKind::Op;
        const Table* target = nullptr;
        for (const Table& t : out.results.tables) {
            if (t.analysis == want) {
                target = &t;
                break;
            }
        }
        if (target == nullptr) {
            Measurement failed;
            failed.name = m.result.text;
            failed.note = "the deck has no " +
                          (m.analysis == MeasCard::Analysis::Tran
                               ? std::string(".tran")
                               : m.analysis == MeasCard::Analysis::Dc
                                     ? std::string(".dc")
                                     : m.analysis == MeasCard::Analysis::Ac
                                           ? std::string(".ac")
                                           : std::string(".op")) +
                          " table to measure";
            out.measurements.push_back(std::move(failed));
            continue;
        }
        // Split the family into per-point tables (a plain table is its
        // own single slice): .meas must see the analysis's own axis, not
        // the step column.
        const std::vector<Table> parts = family_parts(*target);
        for (std::size_t pi = 0; pi < parts.size(); ++pi) {
            WS_TRY_ASSIGN(Measurement r, evaluate_meas(m, parts[pi], global));
            if (pi != 0) {
                r.name += "@" + std::to_string(pi + 1);  // per-point suffix
            }
            out.measurements.push_back(std::move(r));
        }
    }

    // .four (§7.9): every card against the run's .tran table - the .op
    // table when no .tran ran (its DC component alone), no table at all
    // a failure note per signal. Per step point for a family, @2/@3
    // suffixes like .meas; failures are notes, never run failures (§9.5).
    for (const FourCard& f : ast.fours) {
        const Table* target = nullptr;
        for (const Table& t : out.results.tables) {
            if (t.analysis == AnalysisKind::Tran) {
                target = &t;
                break;
            }
        }
        if (target == nullptr) {
            for (const Table& t : out.results.tables) {
                if (t.analysis == AnalysisKind::Op) {
                    target = &t;
                    break;
                }
            }
        }
        if (target == nullptr) {
            for (const Token& sig_tok : f.signals) {
                Fourier failed;
                failed.signal = sig_tok.text;
                failed.note =
                    "the deck has no .tran or .op table to analyse";
                out.fouriers.push_back(std::move(failed));
            }
            continue;
        }
        const std::vector<Table> parts = family_parts(*target);
        for (std::size_t pi = 0; pi < parts.size(); ++pi) {
            for (const Token& sig_tok : f.signals) {
                Fourier r = evaluate_four(f, sig_tok, parts[pi], global);
                if (pi != 0) {
                    r.signal += "@" + std::to_string(pi + 1);  // per-point suffix
                }
                out.fouriers.push_back(std::move(r));
            }
        }
    }

    if (!failure_list.empty()) {
        std::string msg = "step run completed with failures:\n";
        for (const std::string& f : failure_list) {
            msg += "  " + f + "\n";
        }
        Diagnostic d = run_diag(ErrorKind::Semantic, "spice.semantic.step_failures",
                                std::move(msg));
        return spice_fail(std::move(d));
    }

    if (ast.analyses.empty()) {
        // No analysis cards: nothing to simulate, but the deck still
        // elaborates once - device values and topology are validated, so
        // an invalid deck never passes silently (§1, working-rule 5).
        // (The step loop above already elaborated every point.)
        if (!elaborated_any_devices) {
            return empty_circuit_error("");
        }
    }
    return out;
}

}  // namespace ws::spice
