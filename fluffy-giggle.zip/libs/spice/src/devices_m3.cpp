// M3 devices (DESIGN.md §3.6, §5, §11): the diode - the first nonlinear
// device. Shockley I = Is*(exp(Vd/(n*Vt)) - 1) + gmin*Vd, hand-differentiated
// (Gd = Is/(n*Vt)*exp(Vd/(n*Vt)) + gmin), linearized as a Norton equivalent
// (Gd in parallel with Ieq = I - Gd*Vd) stamped at the CURRENT iterate
// (§3.6, threaded through DcLoadContext::node_v). pnjlim (SPICE3 devlim,
// §5.3) clamps the per-iteration junction-voltage jump to 2*Vt scale past
// vcrit, preventing exp() overflow when the first Newton iterate wildly
// overshoots. The convergence ladder (gmin / source / PTC homotopies,
// §5.2) is already in the kernel; the diode is what makes the ladder
// load-bearing, exactly as §11 planned.
//
// State layout (state_slots == 3):
//   [0] Vd_prev  - the previous load's Vd (the vnew pnjlim compares to)
//   [1] I_cur    - I at the current load's Vd (for nonlinear_residual)
//   [2] I_prev   - I at the previous load's Vd
// All three zeroed at bind; advanced by update_state once per Newton
// iteration. The diode is NOT dynamic (no companion, no Cjo in M3) -
// is_dynamic() stays false; load_tran defaults to load_dc.
//
// The make_diode factory has external linkage: the builtin table in
// devices.cpp names it alongside the M1/M2 set.

#include "cards.hpp"

#include <algorithm>
#include <cmath>
#include <limits>
#include <memory>
#include <string>
#include <utility>
#include <vector>

#include <ws/spice/circuit.hpp>
#include <ws/spice/deck.hpp>
#include <ws/spice/device.hpp>
#include <ws/spice/state.hpp>

#include "physconst.hpp"

namespace ws::spice {

namespace {

Diagnostic dev_diag(ErrorKind kind, std::string code, std::string message, SourceLoc loc) {
    Diagnostic d;
    d.kind = kind;
    d.code = std::move(code);
    d.message = std::move(message);
    d.loc = std::move(loc);
    return d;
}

// Voltage across a two-terminal device from the solution vector (ground → 0).
[[nodiscard]] double v_across(const std::vector<double>& x, NodeId p, NodeId n) {
    const double vp = (p == kGround) ? 0.0 : x[p];
    const double vn = (n == kGround) ? 0.0 : x[n];
    return vp - vn;
}

// Boltzmann's constant / electron charge (V/K) - the thermal voltage scale.
constexpr double kVtPerK = phys::kKoverQ;

// §7.7: the SPICE3 saturation-current temperature factor (diotemp.c,
// tlev=0): Is(T) = Is·exp[(T/Tnom − 1)·Eg/(N·Vt_T) + (XTI/N)·ln(T/Tnom)]
// with EG the model's energy gap (default 1.11 eV) and XTI=3. Returns
// exactly 0.0 at T == Tnom, so the default-temperature stamp is
// bit-identical to the frozen-Tnom form.
[[nodiscard]] double diode_is_temp_factor(double temp_k, double tnom_k, double eg,
                                          double xti, double n, double vte) {
    const double ratio = temp_k / tnom_k;
    if (ratio == 1.0) {
        return 0.0;
    }
    return (ratio - 1.0) * eg / vte + (xti / n) * std::log(ratio);
}

// §5.3 pnjlim (SPICE3 dev.c, simplified - the icheck first-time flag is
// folded into the always-directional form; the difference only matters on
// the first clamping iteration of a sequence, and there vold is typically
// 0 so both forms step up by 2*Vt anyway). Clamps the per-iteration ΔVd
// to 2*Vt when vnew crosses vcrit, preventing exp(Vd/nVt) overflow.
[[nodiscard]] double pnjlim(double vnew, double vold, double vt, double vcrit) {
    if (vnew > vcrit && std::abs(vnew - vold) > 2.0 * vt) {
        return vold + ((vnew > vold) ? 2.0 * vt : -2.0 * vt);
    }
    return vnew;
}

// The BREAKDOWN mirror of pnjlim (active only when Bv > 0): the same
// SPICE3 clamp applied to the reflected coordinate w = -(vd + xbv), the
// "forward voltage past the knee". Without it a zener's first Newton
// iterate lands at vd = -15 V, the reverse exponential (arg ~ 400)
// saturates the safe_exp clamp, and the linearization crawls back to
// the knee at one vte per iteration - hundreds of iterations of false
// ladder marching. The mirror lands the FIRST deep excursion where the
// reverse current is vte-scale (w = vte*ln(w/vte), SPICE3's vold <= 0
// landing), then steps w by vte*(2 + ln(arg - 2)) - the overshoot-
// adaptive step SPICE3's forward branch uses. A no-op at every
// non-breakdown bias, so decks without Bv keep the exact M3 sequence.
[[nodiscard]] double bd_pnjlim(double vd, double vold, double vte, double vcrit,
                               double xbv) {
    const double w_new = -(vd + xbv);   // breakdown "forward" coordinate
    const double w_old = -(vold + xbv);
    if (w_new > vcrit && std::abs(w_new - w_old) > 2.0 * vte) {
        double w_lim;
        if (w_old > 0.0) {
            const double arg = (w_new - w_old) / vte;
            w_lim = (arg > 2.0)
                        ? w_old + vte * (2.0 + std::log(arg - 2.0))
                        : w_new;  // degenerate overshoot: leave it
        } else {
            // First entry into breakdown: land at the vte-scale current.
            w_lim = vte * std::log(w_new / vte);
        }
        return -(w_lim + xbv);
    }
    return vd;
}

// Safe exp argument: clamp to ≤ 80 so exp() stays finite (exp(80) ≈ 5.5e34;
// Is*exp(80) ≈ 5e20 A for Is=1e-14 - absurd but finite, won't NaN the
// solve). pnjlim should keep us well below this in normal operation; the
// clamp is defense against ill-conditioned warm starts.
[[nodiscard]] double safe_exp_arg(double arg) {
    if (arg > 80.0) {
        return 80.0;
    }
    if (arg < -80.0) {
        return -80.0;
    }
    return arg;
}

// --- D (diode, §3.6/§5.3/§11 M3, §6.2 M4b: Cjo charge companion) ------------------

class Diode final : public Device {
public:
    // M3 state slots (always present):
    static constexpr std::size_t kVdPrev = 0;
    static constexpr std::size_t kICur = 1;
    static constexpr std::size_t kIPrev = 2;
    // M4b companion state slots (present when cjo_ > 0):
    static constexpr std::size_t kVComp = 3;   // V at last committed step
    static constexpr std::size_t kQComp = 4;   // Q at last committed step
    static constexpr std::size_t kIComp = 5;   // companion I at last step
    static constexpr std::size_t kGeq = 6;     // companion conductance (per attempt)
    static constexpr std::size_t kJeq = 7;     // companion current source
    static constexpr std::size_t kHistN = 8;   // LTE history length (0..3)
    static constexpr std::size_t kHist = 9;    // first (t, q) pair, 6 slots
    static constexpr std::size_t kCjoEff = 15; // folded Cjo*area
    static constexpr std::size_t kIsEff = 16;  // folded Is(T)*area (TT hooks)
    static constexpr std::size_t kNVtEff = 17; // folded n*Vt(T) (TT hooks)

    Diode(std::string display, NodeId anode, NodeId cathode, ExprProgram area,
          bool has_ic, double ic, bool has_temp_inst, double temp_inst_c)
        : name_(std::move(display)), anode_(anode), cathode_(cathode),
          area_(std::move(area)), has_ic_(has_ic), ic_(ic),
          has_temp_inst_(has_temp_inst), temp_inst_c_(temp_inst_c) {}

    [[nodiscard]] const std::string& name() const override { return name_; }
    [[nodiscard]] char kind() const override { return 'D'; }
    [[nodiscard]] std::vector<NodeId> terminals() const override {
        return {anode_, cathode_};
    }
    // The diode is a conductance path between its terminals (Gd is always
    // finite and nonzero - at Vd=0, Gd = Is/(n*Vt) + gmin, ~4e-13 S for
    // defaults; tiny but a real DC path, matching ngspice's graph check).
    // With Rs > 0 the path is the two-edge chain anode --[Rs]-- mid --
    // [junction]-- cathode (the internal node is NOT a terminal, the
    // L#mid precedent).
    [[nodiscard]] std::vector<std::pair<NodeId, NodeId>> conductance_edges()
        const override {
        if (mid_ != kGround) {
            return {{anode_, mid_}, {mid_, cathode_}};
        }
        return {{anode_, cathode_}};
    }

    // --- the stamp (§3.6: linearize at the current iterate) --------------
    // With Rs > 0 the junction sits at the internal mid node: the device
    // is anode --[Rs/area]-- mid --[Shockley (+Cjo companion)]-- cathode,
    // SPICE3's topology. Rs = 0 (the default) keeps the M3 two-terminal
    // stamp byte-identical - no mid node exists at all.
    [[nodiscard]] NodeId jnode() const { return (mid_ != kGround) ? mid_ : anode_; }

    // §7.7 (M5): the effective temperature for this load - the instance
    // temp= override when given, else the run's (elaboration) temperature.
    [[nodiscard]] double load_temp_k(double ctx_temp_k) const {
        return has_temp_inst_ ? phys::c_to_k(temp_inst_c_) : ctx_temp_k;
    }

    // The temp-dependent model quantities at one (area, temperature):
    // Vt, N·Vt, the effective saturation current Is(T)·area, the
    // pnjlim knee vcrit(T) and - with Bv > 0 - the breakdown knee xbv
    // (the SPICE3 diotemp.c fixed point: the shifted voltage where the
    // reverse exponential passes exactly -IBV·area at -Bv, so the
    // deck's Bv/Ibv pair is honored by construction). At T == Tnom
    // every field equals the frozen Tnom values (the factor is exactly
    // 0), so default decks keep the M3/M4b answers bit-for-bit.
    struct TempOp {
        double vt = 0.0;
        double vte = 0.0;
        double is_eff = 0.0;
        double vcrit = 0.0;
        double xbv = 0.0;  // > 0: the breakdown knee; 0: no breakdown
    };
    [[nodiscard]] TempOp temp_op(double area, double temp_k) const {
        TempOp op;
        op.vt = temp_k * kVtPerK;
        op.vte = n_ * op.vt;
        const double tf =
            diode_is_temp_factor(temp_k, tnom_k_, eg_, xti_, n_, op.vte);
        const double is_t = is_ * std::exp(tf);
        op.is_eff = is_t * area;
        const double arg = op.vte / (std::sqrt(2.0) * is_t);
        op.vcrit = (arg > 1.0) ? op.vte * std::log(arg) : op.vte;
        // The breakdown knee (diotemp.c): solve xbv so that
        //   Is·exp((Bv - xbv)/vte) = IBV·area + Is·(1 - xbv/vt)
        // whose fixed point is xbv = Bv - vte·ln(IBV·area/Is + 1 -
        // xbv/vt) - the exponential that passes -IBV·area at exactly
        // -Bv while joining the -Is reverse saturation at -xbv (the
        // current at the knee itself is -Is, continuous with the
        // reverse branch). The compat fallback (knee AT Bv, the
        // current at -Bv exceeding IBV) covers an IBV below the
        // forward-saturation scale; a fixed point landing at xbv <= 0
        // (a Bv so low the shift would swallow it) is the same
        // fallback - SPICE3 iterates into that nonsense silently.
        if (bv_ > 0.0) {
            const double cbv = ibv_ * area;
            if (cbv < op.is_eff * bv_ / op.vt) {
                op.xbv = bv_;
            } else {
                double xbv = bv_ - op.vte * std::log(1.0 + cbv / op.is_eff);
                for (int it = 0; it < 25; ++it) {
                    xbv = bv_ -
                          op.vte * std::log(cbv / op.is_eff + 1.0 - xbv / op.vt);
                }
                op.xbv = (xbv > 0.0) ? xbv : bv_;
            }
        }
        return op;
    }

    void load_dc(DcLoadContext& cx) const override {
        const double area = cx.par(kAreaParam);
        const TempOp op = temp_op(area, load_temp_k(cx.temp_k()));
        const NodeId j = jnode();
        const double vd = cx.node_v(j) - cx.node_v(cathode_);
        double vd_lim = pnjlim(vd, cx.st(kVdPrev), op.vte, op.vcrit);
        if (op.xbv > 0.0) {
            vd_lim = bd_pnjlim(vd_lim, cx.st(kVdPrev), op.vte, op.vcrit, op.xbv);
        }
        const double gm = cx.gmin();
        double gd;
        double i;
        if (op.xbv > 0.0 && vd_lim < -op.xbv) {
            // Reverse breakdown (SPICE3 dioload.c): past the knee the
            // current is -Is·exp(-(xbv+vd)/vte) + gmin·vd - the mirror
            // of the forward Shockley branch on the far side of the
            // axis, evaluated at the SAME internal junction node when
            // Rs > 0 (the Rs-precedent topology: the knee sees vj, not
            // the terminal voltage). Continuous with the reverse
            // branch at the knee (both -Is there); the conductance
            // jumps by Is/vte (~4e-13 S at the defaults) - the same
            // jump SPICE3 takes.
            const double evrev =
                std::exp(safe_exp_arg(-(op.xbv + vd_lim) / op.vte));
            gd = op.is_eff / op.vte * evrev + gm;
            i = -op.is_eff * evrev + gm * vd_lim;
        } else {
            const double arg = safe_exp_arg(vd_lim / op.vte);
            const double ex = std::exp(arg);
            gd = op.is_eff / op.vte * ex + gm;
            i = op.is_eff * (ex - 1.0) + gm * vd_lim;
        }
        const double ieq = i - gd * vd_lim;  // Norton offset
        // Series resistance (every mode; Rs scales as Rs/area, SPICE3).
        if (mid_ != kGround) {
            cx.add_conductance(anode_, mid_, area / rs_);
        }
        // Conductance gd between the junction nodes; current source ieq
        // flowing anode→cathode (the diode's forward-current direction).
        cx.add_conductance(j, cathode_, gd);
        cx.add_current(cathode_, j, ieq);
    }

    // M4b: when Cjo > 0, load_tran stamps the DC Shockley part PLUS the
    // charge companion (geq, jeq from begin_step). The companion uses
    // the same Norton form as the linear C: geq in parallel with jeq.
    void load_tran(DcLoadContext& cx, const TranStep&) const override {
        load_dc(cx);  // DC Shockley stamp (+ Rs when present)
        if (!has_cap()) return;
        // Charge companion (trap/BE, same as the linear C in devices_m2.cpp).
        const NodeId j = jnode();
        cx.add_conductance(j, cathode_, cx.st(kGeq));
        cx.add_current(cathode_, j, cx.st(kJeq));
    }

    // §7.5 (M5, dionoise.c): _rs thermal (area/Rs, between anode and the
    // internal mid node), _id shot 2q·|Id| (between the junction nodes),
    // _1overf flicker KF·|Id/area|^AF/f·area (KF=0, the default, is
    // silent). The OP junction voltage rides state[kVdPrev].
    void load_noise(NoiseContext& cx) const override {
        const double area = cx.par(kAreaParam);
        const TempOp op = temp_op(area, load_temp_k(cx.temp_k));
        const double vd = cx.st(kVdPrev);
        double id;
        if (op.xbv > 0.0 && vd < -op.xbv) {
            // The shot noise rides the FULL conduction current - in
            // breakdown that is the reverse exponential (the mirror of
            // the forward branch; ngspice's dionoise likewise evaluates
            // the DC current through the load's branch structure).
            id = -op.is_eff *
                 std::exp(safe_exp_arg(-(op.xbv + vd) / op.vte));
        } else {
            const double ex = std::exp(safe_exp_arg(vd / op.vte));
            id = op.is_eff * (ex - 1.0);
        }
        if (mid_ != kGround) {
            cx.add_source("rs", anode_, mid_, 4.0 * phys::kBoltz *
                                                  load_temp_k(cx.temp_k) * area / rs_);
        }
        cx.add_source("id", jnode(), cathode_, 2.0 * phys::kQ * std::abs(id));
        if (kf_ != 0.0 && cx.freq > 0.0 && id != 0.0) {
            cx.add_source(
                "1overf", jnode(), cathode_,
                kf_ * std::pow(std::abs(id / area), af_) / cx.freq * area);
        }
    }

    // The small-signal conductance at the OP (frozen Vd from state[kVdPrev]).
    // M4b: adds j*omega*Cj(Vd) — the junction capacitance at the OP.
    // Bv: in breakdown the conductance is the reverse exponential's
    // slope Is/vte·exp(-(xbv+vd)/vte).
    void load_ac(AcLoadContext& cx) const override {
        const double area = cx.par(kAreaParam);
        const TempOp op = temp_op(area, load_temp_k(cx.temp_k()));
        const double vd = cx.st(kVdPrev);
        double gd_op;
        if (op.xbv > 0.0 && vd < -op.xbv) {
            gd_op = op.is_eff / op.vte *
                    std::exp(safe_exp_arg(-(op.xbv + vd) / op.vte));
        } else {
            const double arg = safe_exp_arg(vd / op.vte);
            gd_op = op.is_eff / op.vte * std::exp(arg);
        }
        if (mid_ != kGround) {
            cx.add_conductance(anode_, mid_, area / rs_);
        }
        const NodeId j = jnode();
        cx.add_conductance(j, cathode_, {gd_op, 0.0});
        if (has_cap()) {
            const double cj = c_dep(vd, cjo_ * area) + c_tt(vd, op.is_eff, op.vte);
            cx.add_conductance(j, cathode_, {0.0, cx.omega * cj});
        }
    }

    // --- parameter model (§3.5a) -----------------------------------------
    [[nodiscard]] std::vector<ParamSpec> param_specs() const override {
        return {ParamSpec{"area", area_}};
    }
    [[nodiscard]] ws::core::Status check_params(const double* p) const override {
        if (!(p[kAreaParam] > 0.0) || !std::isfinite(p[kAreaParam])) {
            return spice_fail(dev_diag(
                ErrorKind::Semantic, "spice.semantic.d_area",
                "diode " + name_ + " needs a positive finite area", loc));
        }
        return {};
    }

    // --- state model (§3.5b) ---------------------------------------------
    // M3: 3 slots (Vd_prev, I_cur, I_prev). M4b: 16 slots when Cjo > 0
    // (adds companion state + LTE history + folded Cjo*area).
    [[nodiscard]] std::size_t state_slots() const override {
        return has_cap() ? 18 : 3;
    }
    [[nodiscard]] bool is_dynamic() const override { return has_cap(); }

    // Folds Cjo*area into state[kCjoEff] once per step attempt (same
    // pattern as the Capacitor's kCParam fold). link_dynamic sets self_index_.
    void fold_state(double* st, const RunState& rs, const Circuit& c) const override {
        if (has_cap()) {
            const double area = rs.params()[c.param_span[self_index_].begin];
            st[kCjoEff] = cjo_ * area;
            // The TT charge evaluates at the instance's effective
            // temperature (load_temp_k: the per-instance temp= override,
            // else the circuit's elaboration temperature) - the same
            // value every load-context path uses, so the companion and
            // the loads can never disagree. Every temp change
            // re-elaborates (§7.7), so the fold stays current.
            const TempOp op = temp_op(area, load_temp_k(phys::c_to_k(c.temp)));
            st[kIsEff] = op.is_eff;
            st[kNVtEff] = op.vte;
        }
    }
    [[nodiscard]] ws::core::Status link_dynamic(const Circuit& /*c*/,
                                                 std::size_t self) override {
        self_index_ = self;
        return {};
    }
    // init_state defaults to zero, which is correct: Vd_prev=0 (cold start),
    // I_cur=I_prev=0 (no previous load).

    // Advances the pnjlim reference and the residual trackers. §5.3: the
    // vold stored for the NEXT iteration's pnjlim must be the CLAMPED Vd
    // (Vd_lim), not the raw iterate - otherwise pnjlim compares the new
    // iterate to the previous overshoot and never clamps (the diode gets
    // stuck at Vd=100V from the first Newton step). Both load_dc and
    // update_state compute Vd_lim = pnjlim(Vd(x_prev), vold, ...) against
    // the same vold, so they agree; update_state stores Vd_lim as vold for
    // the next iteration. Returns false: the diode has no discrete state.
    [[nodiscard]] bool update_state(const std::vector<double>& x,
                                    std::size_t /*node_count*/, double* st,
                                    const std::vector<double>* x_prev = nullptr,
                                    const double* params = nullptr,
                                    double temp_k = 300.15) override {
        const std::vector<double>& x_load =
            (x_prev != nullptr && !x_prev->empty()) ? *x_prev : x;
        double area = 1.0;
        if (params != nullptr) {
            area = params[kAreaParam];
        }
        const TempOp op = temp_op(area, load_temp_k(temp_k));
        const double vd_load = v_across(x_load, jnode(), cathode_);
        double vd_lim = pnjlim(vd_load, st[kVdPrev], op.vte, op.vcrit);
        if (op.xbv > 0.0) {
            vd_lim = bd_pnjlim(vd_lim, st[kVdPrev], op.vte, op.vcrit, op.xbv);
        }
        // §5.3: return true (force another iteration) when pnjlim is
        // actively clamping — the linearization point differs from the
        // iterate, so convergence would be premature. Without this, a
        // stiff cold start (e.g. Vd=12V) falsely converges at Vd_lim=0.05
        // because I(Vd_lim) is below abstol and the residual check passes.
        const bool clamped = vd_lim != vd_load;
        // Track I at the clamped linearization point (the "current
        // predicted by the linearization", §5.1). §7.7 (M5): Is(T) and Vt(T)
        // re-evaluate per load through the temp op, and the area folds in
        // exactly (the old area=1 approximation is gone - the residual
        // gate is area-exact now). Bv: the breakdown branch's current
        // (the forward Shockley form would report -Is for every
        // breakdown bias and blind the residual gate).
        double i_lim;
        if (op.xbv > 0.0 && vd_lim < -op.xbv) {
            i_lim = -op.is_eff *
                    std::exp(safe_exp_arg(-(op.xbv + vd_lim) / op.vte));
        } else {
            const double arg = safe_exp_arg(vd_lim / op.vte);
            i_lim = op.is_eff * (std::exp(arg) - 1.0);
        }
        st[kIPrev] = st[kICur];
        st[kICur] = i_lim;
        st[kVdPrev] = vd_lim;  // CLAMPED, for the NEXT iteration's pnjlim vold
        return clamped;
    }

    // §5.1: |ΔI| since the previous load, normalized by max(|I_cur|,|I_prev|).
    [[nodiscard]] NonlinResid nonlinear_residual(const double* st) const override {
        const double i_cur = st[kICur];
        const double i_prev = st[kIPrev];
        return {std::abs(i_cur - i_prev), std::max(std::abs(i_cur), std::abs(i_prev))};
    }

    // --- terminal-current probe (§7.8): the i(<name>) column ----------------
    // The diode's current at the ACCEPTED solution, anode -> cathode. With
    // Rs > 0 the honest reading is the series resistor's own current
    // (v(a)-v(mid)) * area/Rs - it never exponentiates, so a wild forward
    // bias saturates gracefully instead of overflowing. Without Rs it is
    // the Shockley current at the raw terminal voltage (the gmin term is
    // deliberately excluded: it is the solver's crutch, not the device -
    // at the defaults it is ~1e-12 A and invisible next to any conduction
    // the glow would care about).
    [[nodiscard]] bool probes_current() const override { return true; }
    [[nodiscard]] double terminal_current(const std::vector<double>& x,
                                          std::size_t /*node_count*/,
                                          const double* params,
                                          double temp_k = 300.15) const override {
        const double area =
            params != nullptr ? params[kAreaParam] : 1.0;
        if (mid_ != kGround) {
            return v_across(x, anode_, mid_) * area / rs_;
        }
        const TempOp op = temp_op(area, load_temp_k(temp_k));
        const double vd = v_across(x, anode_, cathode_);
        if (op.xbv > 0.0 && vd < -op.xbv) {
            return -op.is_eff *
                   std::exp(safe_exp_arg(-(op.xbv + vd) / op.vte));
        }
        return op.is_eff * (std::exp(safe_exp_arg(vd / op.vte)) - 1.0);
    }

    // --- M4b dynamic hooks (charge companion, only when Cjo > 0) ----------
    // Same pattern as the linear C in devices_m2.cpp: begin_step computes
    // geq/jeq from the last committed step's V/Q/I; load_tran stamps them;
    // commit stores the new V/Q/I and pushes LTE history; lte_ok uses the
    // divided-difference LTE on the charge history.

    void begin_step(const TranStep& step, double* st) override {
        if (!has_cap()) return;
        const double cjo_eff = st[kCjoEff];
        // The diffusion-charge cutoff (phys::kChargeFloor): once the stored
        // TT charge drops below the SPICE3 chgtol floor it is numerically
        // dead - C_tt = Q_tt/Vt collapses with it while the terminal
        // current stays whatever the circuit pushes, so the remaining
        // dynamics are a genuine discontinuity (the reverse-recovery
        // snap; with Cjo=0 nothing softens it). With no depletion cap
        // either, the honest handoff is a fully silent companion: the
        // circuit pins the node algebraically, and carrying the trap
        // memory of a dead charge is exactly the ringing poison (a
        // current source with no conductance to damp it).
        const double q_tt_comp = q_tt(st[kVComp], st[kIsEff], st[kNVtEff]);
        const bool tt_dead = q_tt_comp <= phys::kChargeFloor;
        if (tt_dead && cjo_eff <= 0.0) {
            st[kGeq] = 0.0;
            st[kJeq] = 0.0;
            return;
        }
        // Capacitance at the last committed V (begin_step runs once per
        // step attempt, before the Newton loop - it can't see the current
        // iterate, so it uses V_comp from the last commit).
        const double c = c_dep(st[kVComp], cjo_eff) +
                         (tt_dead ? 0.0 : q_tt_comp / st[kNVtEff]);
        if (step.be) {
            st[kGeq] = c / step.dt;
            // The consistent BE linearization of i = (q(v) - Q_prev)/dt
            // frozen at the committed point: the tangent of q at V_comp
            // carries q(V_comp) - c*V_comp, and q(V_comp) == Q_prev when
            // the tangent sits ON the committed point (begin_step runs
            // after commit), so the two Q's cancel EXACTLY and only
            // -geq*V_comp survives: i = geq*(v - V_comp).
            // The -Q/dt-only form the linear C uses is the same thing for
            // q = C*v (Q == c*V bit-for-bit), but for a nonlinear charge
            // it is a charge-referenced error term (c*V - Q)/dt per step:
            // invisible for depletion (Q ~ c*V to a factor ~2), but the
            // TT diffusion charge has Q = vte*C - a factor 1/27 off at
            // 0.7 V - so the origin form dumps amperes into the first BE
            // restart after a LTE rejection (22 pC through a 0.2 ns dt
            // is 110 A). The trap branch below was already the
            // consistent tangent form; this makes BE match it (and
            // quietly removes the depletion-offset error too).
            st[kJeq] = -st[kGeq] * st[kVComp];
        } else {
            st[kGeq] = 2.0 * c / step.dt;
            st[kJeq] = -(st[kGeq] * st[kVComp] + st[kIComp]);
        }
    }

    void commit(const std::vector<double>& x, std::size_t /*nc*/,
                const TranStep& step, double* st) override {
        if (!has_cap()) return;
        const double cjo_eff = st[kCjoEff];
        const double vd = v_across(x, jnode(), cathode_);
        const double q = q_dep(vd, cjo_eff) + q_tt(vd, st[kIsEff], st[kNVtEff]);
        // The snap guard: the committed trap memory must be the charge's
        // true rate, not the frozen tangent's current, whenever the step
        // left the tangent's domain. The TT tangent-implied charge
        // q_hat = Q_tt(V_comp) + C_tt*(v - V_comp) crosses zero exactly
        // when the step drains more than the stored diffusion charge
        // (|dv| > Vt off a live charge - the snap); the companion current
        // geq*v+jeq is then a fiction (amperes through a charge that no
        // longer exists), and committing it rings forever: the next
        // step's jeq = -(geq*V_comp + I_comp) becomes a current source
        // with no conductance left to damp it - the observed 2-cycle
        // pinned to rail +- I*R. The honest memory is the implied rate
        // (q_new - Q_comp)/dt - what the step ACTUALLY did to the charge.
        double i_comp = st[kGeq] * vd + st[kJeq];
        const double q_tt_comp = q_tt(st[kVComp], st[kIsEff], st[kNVtEff]);
        if (tt_ > 0.0 && q_tt_comp > phys::kChargeFloor) {
            const double q_hat_tt =
                q_tt_comp + (q_tt_comp / st[kNVtEff]) * (vd - st[kVComp]);
            if (q_hat_tt <= 0.0) {
                i_comp = (q - st[kQComp]) / step.dt;
            }
        }
        st[kVComp] = vd;
        st[kQComp] = q;
        st[kIComp] = i_comp;
        // LTE history (3 (t, q) pairs, oldest first).
        if (step.be) {
            st[kHistN] = 0.0;  // BE restart invalidates trap LTE history
        } else {
            const double n = st[kHistN];
            if (n < 3.0) {
                const std::size_t idx = static_cast<std::size_t>(n);
                st[kHist + idx * 2] = step.time;
                st[kHist + idx * 2 + 1] = q;
                st[kHistN] = n + 1.0;
            } else {
                // Shift: drop oldest, append newest.
                for (std::size_t i = 0; i < 2; ++i) {
                    st[kHist + i * 2] = st[kHist + (i + 1) * 2];
                    st[kHist + i * 2 + 1] = st[kHist + (i + 1) * 2 + 1];
                }
                st[kHist + 4] = step.time;
                st[kHist + 5] = q;
            }
        }
    }

    [[nodiscard]] bool lte_ok(const TranStep& step, const std::vector<double>& x,
                              std::size_t /*nc*/, double reltol, double chgtol,
                              double trtol, const double* st, double* ratio) const override {
        if (!has_cap()) {
            if (ratio) *ratio = 0.0;
            return true;
        }
        const double cjo_eff = st[kCjoEff];
        const double vd = v_across(x, jnode(), cathode_);
        const double q_new = q_dep(vd, cjo_eff) + q_tt(vd, st[kIsEff], st[kNVtEff]);
        // Reuse the dd3_lte logic from devices_m2.cpp (inline here since
        // it's in a different TU's anonymous namespace).
        const double n = st[kHistN];
        if (n < 3.0) {
            if (ratio) *ratio = 0.0;
            return true;  // not enough history
        }
        const double t0 = st[kHist], q0 = st[kHist + 1];
        const double t1 = st[kHist + 2], q1 = st[kHist + 3];
        const double t2 = st[kHist + 4], q2 = st[kHist + 5];
        const double t3 = step.time, q3 = q_new;
        if (!(t1 > t0) || !(t2 > t1) || !(t3 > t2) || !(step.dt > 0)) {
            if (ratio) *ratio = 0.0;
            return true;
        }
        const double d1a = (q1 - q0) / (t1 - t0);
        const double d1b = (q2 - q1) / (t2 - t1);
        const double d1c = (q3 - q2) / (t3 - t2);
        const double d2a = (d1b - d1a) / (t2 - t0);
        const double d2b = (d1c - d1b) / (t3 - t1);
        const double dd3 = (d2b - d2a) / (t3 - t0);
        const double eps = step.dt * step.dt * step.dt * std::abs(dd3) / 2.0;
        const double tolq = trtol * (reltol * std::max(std::abs(q3), std::abs(st[kQComp])) + chgtol);
        if (ratio) *ratio = (tolq > 0) ? (eps / tolq) : std::numeric_limits<double>::infinity();
        return tolq > 0 && eps <= tolq;
    }

    void seed_state(const std::vector<double>& x, std::size_t /*nc*/,
                    double* st) override {
        if (!has_cap()) return;
        const double vd = v_across(x, jnode(), cathode_);
        st[kVComp] = vd;
        st[kQComp] = q_dep(vd, st[kCjoEff]) + q_tt(vd, st[kIsEff], st[kNVtEff]);
        st[kIComp] = 0.0;
        st[kHistN] = 0.0;
    }

    // .model name D(Is=... N=... Rs=... Cjo=... ...). Implements Is, N,
    // Tnom, Xti, Eg (the §7.7 temperature model), Cjo/M/Vj/Fc (M4b
    // junction charge), TT (the transit-time diffusion charge), Rs
    // (series resistance — the internal-node form) and Bv/Ibv (reverse
    // breakdown — the diotemp.c knee solve + the dioload.c reverse
    // exponential, riding the same internal junction node Rs uses).
    ws::core::Status apply_model(const ModelDef& model,
                                 NodeResolver& nodes) override {
        if (model.type != "d") {
            return spice_fail(dev_diag(
                ErrorKind::Semantic, "spice.semantic.model_type",
                "diode " + name_ + " needs a D model, got type '" + model.type + "'",
                model.loc));
        }
        model_name_ = model.name.text;
        // ngspice defaults: Is=1e-14 A, N=1, Tnom=27°C, Cjo=0 (no cap),
        // M=0.5, Vj=1V, Fc=0.5, Eg=1.11 eV, Xti=3 (diosetup.c).
        double is_val = 1e-14;
        double n_val = 1.0;
        double tnom = 27.0;
        double cjo_val = 0.0, m_val = 0.5, vj_val = 1.0, fc_val = 0.5;
        double tt_val = 0.0;
        double rs_val = 0.0;
        double eg_val = 1.11, xti_val = 3.0;
        double kf_val = 0.0, af_val = 1.0;
        double bv_val = 0.0, ibv_val = 1e-3;
        const auto& toks = model.params;
        for (std::size_t i = 0; i < toks.size(); ++i) {
            std::string text = toks[i].text;
            // Paren glue (same as switches): "(Is=1e-14" / "N=1)".
            while (!text.empty() && text.front() == '(') {
                text.erase(text.begin());
            }
            while (!text.empty() && text.back() == ')') {
                text.pop_back();
            }
            if (text.empty()) {
                continue;
            }
            std::string key;
            std::string value;
            const std::size_t eq = text.find('=');
            if (eq != std::string::npos && eq > 0) {
                key = to_lower(text.substr(0, eq));
                value = text.substr(eq + 1);
            } else {
                key = to_lower(text);
                std::size_t next = i + 1;
                if (next < toks.size() && toks[next].text == "=") {
                    ++next;
                }
                if (next >= toks.size()) {
                    return spice_fail(dev_diag(
                        ErrorKind::Semantic, "spice.semantic.model_param",
                        "model '" + model.name.text + "': '" + text + "' needs a value",
                        toks[i].loc));
                }
                value = toks[next].text;
                i = next;
            }
            while (!value.empty() && value.back() == ')') {
                value.pop_back();
            }
            double v = 0.0;
            if (const ws::core::Result<double> r = parse_number(value)) {
                v = *r;
            } else {
                return spice_fail(dev_diag(
                    ErrorKind::Semantic, "spice.semantic.model_param",
                    "model '" + model.name.text + "': bad value '" + value + "'",
                    toks[i].loc));
            }
            if (key == "is") {
                is_val = v;
            } else if (key == "n") {
                n_val = v;
            } else if (key == "tnom") {
                tnom = v;
            } else if (key == "rs") {
                rs_val = v;
            } else if (key == "cjo") {
                cjo_val = v;
            } else if (key == "m") {
                m_val = v;
            } else if (key == "vj") {
                vj_val = v;
            } else if (key == "fc") {
                fc_val = v;
            } else if (key == "xti") {
                xti_val = v;
            } else if (key == "eg") {
                eg_val = v;
            } else if (key == "kf") {
                kf_val = v;
            } else if (key == "af") {
                af_val = v;
            } else if (key == "tt") {
                tt_val = v;
            } else if (key == "bv") {
                bv_val = v;
            } else if (key == "ibv") {
                ibv_val = v;
            } else {
                return spice_fail(dev_diag(
                    ErrorKind::Semantic, "spice.semantic.model_param",
                    "model '" + model.name.text + "': unknown parameter '" + key +
                        "' (Is, N, Tnom, Rs, Cjo, M, Vj, TT, Bv, Ibv, Xti, Eg, Kf, Af, Fc)",
                    toks[i].loc));
            }
        }
        if (!(is_val > 0.0) || !std::isfinite(is_val)) {
            return spice_fail(dev_diag(
                ErrorKind::Semantic, "spice.semantic.d_is",
                "model '" + model.name.text + "' needs Is > 0", model.loc));
        }
        if (!(n_val > 0.0) || !std::isfinite(n_val)) {
            return spice_fail(dev_diag(
                ErrorKind::Semantic, "spice.semantic.d_n",
                "model '" + model.name.text + "' needs N > 0", model.loc));
        }
        // Series resistance: 0 (the default) disables the internal node;
        // negative values are meaningless - reject loudly.
        if (!(rs_val >= 0.0) || !std::isfinite(rs_val)) {
            return spice_fail(dev_diag(
                ErrorKind::Semantic, "spice.semantic.d_rs",
                "model '" + model.name.text + "' needs Rs >= 0"
                " (0 disables the series resistance)",
                model.loc));
        }
        // Transit time: 0 (the default) disables the diffusion charge;
        // negative values flip the stored charge's sign - reject loudly
        // (the Rs precedent; ngspice rejects TT < 0 too).
        if (!(tt_val >= 0.0) || !std::isfinite(tt_val)) {
            return spice_fail(dev_diag(
                ErrorKind::Semantic, "spice.semantic.d_tt",
                "model '" + model.name.text + "' needs TT >= 0"
                " (0 disables the transit-time diffusion charge)",
                model.loc));
        }
        // Reverse breakdown: Bv = 0 (the default) disables the branch;
        // a negative breakdown voltage is meaningless - reject loudly.
        // IBV defaults to 1 mA (ngspice's diode default) and must be
        // positive when Bv is given - the knee solve needs a current
        // scale.
        if (!(bv_val >= 0.0) || !std::isfinite(bv_val)) {
            return spice_fail(dev_diag(
                ErrorKind::Semantic, "spice.semantic.d_bv",
                "model '" + model.name.text + "' needs Bv >= 0"
                " (0 disables reverse breakdown)",
                model.loc));
        }
        if (bv_val > 0.0 && (!(ibv_val > 0.0) || !std::isfinite(ibv_val))) {
            return spice_fail(dev_diag(
                ErrorKind::Semantic, "spice.semantic.d_ibv",
                "model '" + model.name.text + "' needs Ibv > 0 when Bv is given"
                " (the current at the breakdown voltage; default 1mA)",
                model.loc));
        }
        is_ = is_val;
        n_ = n_val;
        rs_ = rs_val;
        tnom_k_ = phys::c_to_k(tnom);
        eg_ = eg_val;
        xti_ = xti_val;
        kf_ = kf_val;
        af_ = af_val;
        // The series node exists only when Rs > 0 (the L Rser precedent:
        // an always-present internal node would flood every deck's save
        // list). apply_model runs BEFORE the §6.6 graph checks, so the
        // claimed node joins them like any other.
        mid_ = kGround;
        if (rs_ > 0.0) {
            Token mid_tok;
            mid_tok.text = name_ + "#mid";
            mid_tok.loc = model.loc;
            mid_ = nodes.node(mid_tok);
        }
        // Vt/vcrit are now PER-LOAD quantities (§7.7, M5): they evaluate at
        // the run temperature through temp_op(), so a `.options temp` /
        // `.dc temp` deck sees the true thermal voltage and Is(T). At
        // T == Tnom the values equal the frozen-Tnom form bit-for-bit.
        // M4b: junction capacitance params.
        cjo_ = cjo_val;
        tt_ = tt_val;
        m_ = m_val;
        vj_ = vj_val;
        fc_ = fc_val;
        // Reverse breakdown (the knee itself is per-load: it depends on
        // Is(T)·area and Vt(T), so it evaluates inside temp_op()).
        bv_ = bv_val;
        ibv_ = ibv_val;
        return {};
    }

    [[nodiscard]] bool has_ic() const override { return has_ic_; }
    [[nodiscard]] double ic_value() const override { return ic_; }

    [[nodiscard]] bool write_card(std::string& out,
                                  const CardWriter& w) const override {
        out += name_ + " " + w.node(anode_) + " " + w.node(cathode_) + " " + model_name_;
        const double area = w.params(*this)[kAreaParam];
        // Omit area when it's exactly 1 (the ngspice default) - keeps the
        // netlist canonical.
        if (area != 1.0) {
            out += " " + Device::CardWriter::num(area);
        }
        if (has_ic_) {
            out += " ic=" + Device::CardWriter::num(ic_);
        }
        out += "\n";
        return true;
    }

private:
    static constexpr std::size_t kAreaParam = 0;

    // --- M4b: junction capacitance (Cjo) charge model -------------------
    // True when the diode has a junction cap (Cjo > 0) - gates is_dynamic,
    // state_slots, and all the companion hooks.
    [[nodiscard]] bool has_cap() const { return cjo_ > 0.0 || tt_ > 0.0; }

    // The transit-time diffusion charge (the stored minority charge of a
    // diode carrying the forward conduction current): Q_tt = TT*(Id_cond +
    // Is) = TT*Is*e^(Vd/vte) - the generation component (-Is) is not
    // stored. C_tt = TT*gd_ideal. The .ac consequence is elegant: the
    // small-signal pole sits at 1/(2*pi*TT) regardless of bias (both gd
    // and C_tt scale with gd).
    [[nodiscard]] double q_tt(double vd, double is_eff, double vte) const {
        if (tt_ <= 0.0) return 0.0;
        return tt_ * is_eff * std::exp(safe_exp_arg(vd / vte));
    }
    [[nodiscard]] double c_tt(double vd, double is_eff, double vte) const {
        if (tt_ <= 0.0) return 0.0;
        return tt_ * is_eff / vte * std::exp(safe_exp_arg(vd / vte));
    }

    // Depletion charge Q_dep(Vd) and capacitance C_dep(Vd), using the
    // SPICE3/ngspice depletion model with the Fc linear extension past
    // Fc*Vj. cjo_eff = Cjo*area (folded into state[kCjoEff]).
    [[nodiscard]] double q_dep(double vd, double cjo_eff) const {
        if (cjo_eff <= 0.0) return 0.0;
        const double fc_vj = fc_ * vj_;
        if (vd < fc_vj) {
            double arg = 1.0 - vd / vj_;
            if (arg < 1e-12) arg = 1e-12;  // avoid singularity at Vd=Vj
            return cjo_eff * vj_ / (1.0 - m_) * (1.0 - std::pow(arg, 1.0 - m_));
        }
        // Linear extension past Fc*Vj (SPICE3 formula).
        const double f1 = vj_ * (1.0 - std::pow(1.0 - fc_, 1.0 - m_)) / (1.0 - m_);
        const double f2 = std::pow(1.0 - fc_, -m_);
        const double q_fcvj = cjo_eff * f1;
        const double c_fcvj = cjo_eff * f2;
        const double dv = vd - fc_vj;
        return q_fcvj + c_fcvj * dv * (1.0 + m_ * dv / (2.0 * vj_ * (1.0 - fc_)));
    }
    [[nodiscard]] double c_dep(double vd, double cjo_eff) const {
        if (cjo_eff <= 0.0) return 0.0;
        const double fc_vj = fc_ * vj_;
        if (vd < fc_vj) {
            double arg = 1.0 - vd / vj_;
            if (arg < 1e-12) arg = 1e-12;
            return cjo_eff / std::pow(arg, m_);
        }
        const double f2 = std::pow(1.0 - fc_, -m_);
        const double dv = vd - fc_vj;
        return cjo_eff * f2 * (1.0 + m_ * dv / (vj_ * (1.0 - fc_)));
    }

    std::string name_;
    NodeId anode_, cathode_;
    // The Rs series node (kGround when Rs == 0 - no node exists at all,
    // the stamp is byte-identical M3).
    NodeId mid_ = kGround;
    ExprProgram area_;
    bool has_ic_;
    double ic_;
    // §7.7: per-instance temp= override (°C; ngspice's diode TEMP).
    bool has_temp_inst_ = false;
    double temp_inst_c_ = 27.0;
    // Model fields (set by apply_model):
    double is_ = 1e-14;     // saturation current (per area=1)
    double n_ = 1.0;        // emission coefficient
    double tnom_k_ = 300.15;  // model nominal temperature, K (§7.7)
    double eg_ = 1.11;      // energy gap, eV (§7.7 Is(T))
    double xti_ = 3.0;      // Is temperature exponent (§7.7)
    double kf_ = 0.0;       // flicker coefficient (§7.5; 0 = silent)
    double af_ = 1.0;       // flicker current exponent (§7.5)
    double rs_ = 0.0;       // series resistance (ohms; 0 = no mid node)
    // M4b: junction capacitance model params (Cjo > 0 enables the companion)
    double cjo_ = 0.0;      // zero-bias junction capacitance (F)
    double m_ = 0.5;        // grading coefficient
    double vj_ = 1.0;       // junction potential (V)
    double fc_ = 0.5;       // forward-bias depletion cap coefficient
    double tt_ = 0.0;       // transit time (s; the diffusion charge)
    double bv_ = 0.0;      // reverse breakdown voltage (V; 0 = off)
    double ibv_ = 1e-3;    // current at Bv (A; the knee solve's scale)
    std::size_t self_index_ = 0;  // filled by link_dynamic (for fold_state)
    std::string model_name_;
};

}  // namespace

ws::core::Result<std::unique_ptr<Device>> make_diode(const DeviceCard& card,
                                                     FactoryServices& s) {
    // D name anode cathode model [area] [off] [ic=Vd] [temp=...]
    WS_TRY_ASSIGN(const std::vector<NodeId> n, take_nodes(card, s.nodes, 2, 0));
    if (card.rest.size() < 3) {
        return spice_fail(dev_diag(ErrorKind::Semantic, "spice.semantic.arity",
                                   "diode " + card.name.text +
                                       " takes two nodes and a model name",
                                   card.loc));
    }
    ExprProgram area_prog;
    bool has_area = false;
    bool has_ic = false;
    double ic_val = 0.0;
    bool has_temp_inst = false;
    double temp_inst = 27.0;
    for (std::size_t i = 3; i < card.rest.size(); ++i) {
        const std::string lower = to_lower(card.rest[i].text);
        if (lower.rfind("ic=", 0) == 0) {
            has_ic = true;
            if (const ws::core::Result<double> r =
                    parse_number(card.rest[i].text.substr(3))) {
                ic_val = *r;
            }
            continue;
        }
        if (lower == "off") {
            // ngspice: start the diode in cutoff (Vd=0 init). With a cold
            // start (x=0) this is already the default; accept and ignore.
            continue;
        }
        if (lower.rfind("temp=", 0) == 0) {
            // §7.7 (M5): per-instance temperature override (°C).
            if (const ws::core::Result<double> r =
                    parse_number(card.rest[i].text.substr(5))) {
                has_temp_inst = true;
                temp_inst = *r;
            }
            continue;
        }
        if (!has_area) {
            // The first non-keyword token after the model name is `area`.
            WS_TRY_ASSIGN(area_prog, resolve_value_program(card.rest[i], s.params));
            WS_TRY(eval_param_for_validation(area_prog, s.params));
            has_area = true;
            continue;
        }
        return spice_fail(dev_diag(
            ErrorKind::Semantic, "spice.semantic.d_extra",
            "diode " + card.name.text +
                " takes nodes, a model, an optional area, ic=Vd, off, temp=",
            card.loc));
    }
    if (!has_area) {
        // Default area = 1.0.
        Token one;
        one.text = "1.0";
        WS_TRY_ASSIGN(area_prog, resolve_value_program(one, s.params));
    }
    auto dev = std::make_unique<Diode>(card.name.text, n[0], n[1], std::move(area_prog),
                                       has_ic, ic_val, has_temp_inst, temp_inst);
    dev->loc = card.loc;
    s.models.push_back(ModelRequest{dev.get(), card.rest[2]});
    return dev;
}

}  // namespace ws::spice
