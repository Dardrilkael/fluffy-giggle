#pragma once

#include <cstddef>
#include <complex>
#include <limits>
#include <memory>
#include <string>
#include <vector>

#include <ws/core/result.hpp>
#include <ws/spice/error.hpp>
#include <ws/spice/expr.hpp>
#include <ws/spice/parse.hpp>

// The device interface (DESIGN.md §3, revised 2026-10-29). A Circuit holds
// IMMUTABLE devices: everything a run can change lives outside it, in two
// per-run arenas (state.hpp):
//
//   * PARAMETERS (§3.5a) - the numeric values that feed stamps: a resistor's
//     ohms, a source's DC value, a gain. Each slot carries the expression
//     it is computed from, evaluated against the run's .param scope. A
//     parameter write can NEVER change the stamp pattern (positions depend
//     only on topology), so reuse of the symbolic analysis after a value
//     change is guaranteed by construction - the §7.6 pattern-hash check
//     is retired in favor of that argument.
//   * STATE (§3.5b) - the dynamic evolution a run owns: companion
//     coefficients, charge/flux histories, switch positions, source
//     overrides. Zeroed (re-seeded) when a run starts; copyable for
//     snapshot/restore; never read by another run.
//
// Staging is unchanged from the original design: load_dc / load_tran /
// load_ac stamp the MNA system; the load context carries THIS device's
// parameter and state slices, re-pointed by the system between devices.
// The dynamic hooks (begin_step / lte_ok / commit / seed_state /
// update_state) receive the device's state slice explicitly.
//
// Index conventions (§3.3): a NodeId IS the MNA voltage-unknown index
// (ground is kGround and every stamp touching it is skipped); branch rows
// (V/L/E/H sources) number after the nodes. Devices never see a lookup
// table.

namespace ws::spice {

using NodeId = std::size_t;
using BranchId = std::size_t;

// Ground: '0' and 'gnd' (case-insensitive) both map here; stamps skip it.
inline constexpr NodeId kGround = static_cast<NodeId>(-1);

class DcLoadContext;
class AcLoadContext;
class NoiseContext;
struct ModelDef;
class ParamTable;
struct Circuit;
class RunState;

// --- elaboration-time services (handed to device factories) -------------------

// A value token from a device card: a SPICE number, an '{expression}', or
// a bare .param name (the ngspice form). Resolved to its double for
// validation, or captured as a program for the parameter arena.
[[nodiscard]] ws::core::Result<double> resolve_value_token(const Token& tok,
                                                           const class ParamTable& params);
// The same token captured as a parameter source: a constant program, the
// parsed expression, or a lone variable reference. Evaluated per run
// against the (possibly .step-overridden, possibly Monte-Carlo-seeded)
// scope - this is what makes value sweeps and tolerances re-elaboration-
// free.
[[nodiscard]] ws::core::Result<ExprProgram> resolve_value_program(const Token& tok,
                                                                  const ParamTable& params);

class NodeResolver {
public:
    virtual ~NodeResolver() = default;

    // Resolves (creating if new) a node by its token; ground spellings map
    // to kGround. Scope-name mapping (X1:7 style) is the caller's - the
    // flattener rewrites tokens before they get here.
    [[nodiscard]] virtual NodeId node(const Token& name) = 0;

    // Claims the next branch row (V/L/E/H sources).
    [[nodiscard]] virtual BranchId claim_branch() = 0;
};

// A device under construction still needing a named branch (F/H name a
// controlling V source; resolved in a second pass once every source has
// its branch).
struct ControlRequest {
    class Device* device = nullptr;  // F/H instance, filled by its factory
    Token control;                   // the V source token it names
    std::size_t which = 0;           // index among the device's control
                                     //   references (a behavioral B may name
                                     //   several i(Vname) sources; F/H/W
                                     //   have exactly one)
};

// K coupling (§6.2): two inductor names + k, resolved after every device
// exists (pairwise only in M2 - the inductor rejects a second partner;
// multi-winding transformers are backlog).
struct CouplingRequest {
    class Device* device = nullptr;  // the K instance (a no-op stamp itself)
    Token a;                         // first inductor name
    Token b;                         // second inductor name
    double k = 0.0;                  // coupling factor, 0 < |k| < 1
};

// S/W switches name a .model card; resolved against the deck's model table
// after every device exists.
struct ModelRequest {
    class Device* device = nullptr;
    Token name;                      // the .model card name
};

// Everything a device factory may ask of the elaborator (§3.4). Node
// resolution and branch claiming happen inline; control/coupling/model
// references defer to a post-pass because the named device may not exist
// yet (deck order).
struct FactoryServices {
    NodeResolver& nodes;
    const ParamTable& params;
    std::vector<ControlRequest>& controls;
    std::vector<CouplingRequest>& couplings;
    std::vector<ModelRequest>& models;
};

// --- the device ----------------------------------------------------------------

// One transient step's parameters (§6.1/§6.2), handed to load_tran and the
// dynamic-device state machine. `time` is the time at the END of the step
// (the new time point); sources evaluate their waveforms there. `tstep` /
// `tstop` are the .tran card's own values - waveform parameters that
// ngspice defaults from them (PULSE TR/TF/PW/PER, SIN FREQ, EXP TAUs)
// resolve against these at evaluation time, so a Circuit's waveform data
// stays immutable across runs with different .tran cards.
struct TranStep {
    double time = 0.0;
    double dt = 0.0;
    bool be = false;  // this step integrates with backward Euler (§6.1)
    double tstep = 0.0;
    double tstop = 0.0;
};

// A per-device parameter descriptor (§3.5a): the slot's name ("value",
// "dc", ...) and the expression it is computed from. Circuit finalization
// flattens these into one table; RunState::bind evaluates them.
struct ParamSpec {
    std::string name;
    ExprProgram source;
};

// §3.6/§5.1 (M3): a nonlinear device's terminal-current convergence
// metric, complementing the kernel's voltage-delta check. `delta` is the
// worst |ΔI| since the previous load; `ref` is the normalization
// magnitude (max(|I_new|, |I_old|)). The kernel accepts when
// `delta ≤ reltol*ref + abstol`. Linear devices return {0, 0}.
struct NonlinResid {
    double delta = 0.0;
    double ref = 0.0;
};

class Device {
public:
    virtual ~Device() = default;

    // "R1" / "X1:R3" - the flattened display name.
    [[nodiscard]] virtual const std::string& name() const = 0;
    // Uppercased kind letter ('R', 'V', 'E', ...).
    [[nodiscard]] virtual char kind() const = 0;
    // Construction provenance (the card's location; the builder fills a
    // synthetic one) - check_params diagnostics render from it.
    SourceLoc loc;
    // True when this device owns a branch row (V/L/E/H) - branch() is valid.
    [[nodiscard]] virtual bool has_branch() const { return false; }
    [[nodiscard]] virtual BranchId branch() const { return 0; }

    // Terminal node ids (for the topological graph checks); ground
    // terminals included as kGround.
    [[nodiscard]] virtual std::vector<NodeId> terminals() const = 0;

    // Nodes this device connects through a CONDUCTANCE path (the DC-path
    // graph check, §6.6): resistors and switches connect their two
    // terminals. Devices that only source current (I, F/G outputs, E/G
    // control inputs) do not. Voltage-constraint devices (V, E/H outputs)
    // connect through, but as constraints - see constraint_edges().
    [[nodiscard]] virtual std::vector<std::pair<NodeId, NodeId>> conductance_edges()
        const {
        return {};
    }

    // Voltage-constraint edges (V sources, inductors - a short at DC - and
    // E/H output pairs): nodes these devices pin relative to each other.
    // Cycles among these are voltage-source/inductor loops (§6.6).
    [[nodiscard]] virtual std::vector<std::pair<NodeId, NodeId>> constraint_edges()
        const {
        return {};
    }

    // --- the parameter model (§3.5a) ------------------------------------------
    //
    // param_specs() is called ONCE, at Circuit finalization; the returned
    // descriptors (name + expression per slot) are frozen into the
    // Circuit's flat table. Values live in each RunState.
    [[nodiscard]] virtual std::vector<ParamSpec> param_specs() const { return {}; }

    // Validates bound values (positive, finite, ...). Called by
    // RunState::bind for every rebind - a Monte-Carlo draw is subject to
    // the same rules as a hand-written card value.
    [[nodiscard]] virtual ws::core::Status check_params(const double* /*p*/) const {
        return {};
    }

    // --- the state model (§3.5b) -----------------------------------------------

    // Fixed double slots this device needs in the run's state arena.
    // Variable-size history is expressed as a fixed cap (the LTE window is
    // 3 (t, q) pairs), so a whole run's state is one flat vector<double>
    // - trivially copyable for snapshot/restore, zeroable for reset.
    [[nodiscard]] virtual std::size_t state_slots() const { return 0; }

    // Seeds the state slice from construction-time data (a switch's ic=
    // position). RunState::bind calls it after zeroing; the transient's
    // t=0 OP then overwrites it through seed_state().
    virtual void init_state(double* st) const {
        for (std::size_t i = 0; i < state_slots(); ++i) {
            st[i] = 0.0;
        }
    }

    // --- stamping ---------------------------------------------------------------
    //
    // The context's par()/st() access this device's parameter and state
    // slices (re-pointed by the system between devices). Pattern mode
    // points them at zeroed scratch: stamp POSITIONS must never depend on
    // values (§3.2), only coefficients do.

    // Stamps the DC/OP system. Called once in pattern mode (values
    // ignored, entries recorded) and then per Newton iteration in numeric
    // mode. A numeric write outside the recorded pattern is a programmer
    // error (WS_CORE_ASSERT inside the MNA layer).
    virtual void load_dc(DcLoadContext& cx) const = 0;

    // Transient companion stamp (§6.2). Default: this device is static,
    // its companion IS its DC stamp (R, E/F/G/H). Dynamic devices (C, L)
    // and time-dependent sources override. Coefficients come from
    // begin_step; positions never change with dt.
    virtual void load_tran(DcLoadContext& cx, const TranStep& step) const {
        (void)step;
        load_dc(cx);
    }

    // Small-signal stamp at cx.omega (§7.4). Default: no AC contribution
    // (an I source without an AC spec is open to the small-signal system;
    // a V source without one still pins v(p)-v(n)=0 through its override).
    virtual void load_ac(AcLoadContext& cx) const { (void)cx; }

    // Small-signal noise densities at the OP (§7.5, M5). Called per
    // frequency point by the .noise driver with the OP frozen in the
    // state slice; the device reports each of its uncorrelated noise
    // generators through cx.add_source(name, p, n, psd) - a current PSD
    // in A^2/Hz between nodes p and n. The driver folds each source with
    // the adjoint gain |x_a[p]-x_a[n]|^2; linear devices (the default)
    // report none.
    virtual void load_noise(NoiseContext& cx) const { (void)cx; }

    // --- dynamic-device state machine (§3.5b, §6.2/§6.3) ----------------------

    // True for devices with per-step companion state (C, L). The driver
    // only runs begin_step/LTE/commit on these.
    [[nodiscard]] virtual bool is_dynamic() const { return false; }

    // Folds this device's bound parameters (and any cross-device data it
    // needs - a K-coupled inductor folds its partner's L) into its state
    // slice. The driver calls it once per step attempt, before
    // begin_step: parameters never change mid-solve, so the fold is safe
    // to keep out of the Newton loop.
    virtual void fold_state(double* /*st*/, const class RunState& /*rs*/,
                            const Circuit& /*c*/) const {}

    // Resolves cross-device links once the arena layout exists (called
    // by finalize_circuit with the device's own index). K-coupled
    // inductors record their partner's parameter slot here so a rebind
    // of either L re-computes the mutual M exactly.
    [[nodiscard]] virtual ws::core::Status link_dynamic(const Circuit& /*c*/,
                                                        std::size_t /*self*/) {
        return {};
    }

    // Computes this step's companion coefficients from the stored state
    // (v/i/flux/charge history). Runs once per STEP ATTEMPT - a rejected
    // step simply calls it again with the smaller dt; state is untouched
    // until commit.
    virtual void begin_step(const TranStep& step, double* st) { (void)step; (void)st; }

    // Accepts the step: pulls the new v/i from the solution into the
    // device's state slice and appends to its LTE history.
    virtual void commit(const std::vector<double>& x, std::size_t node_count,
                        const TranStep& step, double* st) {
        (void)x;
        (void)node_count;
        (void)step;
        (void)st;
    }

    // The §6.3 LTE test for this device against the candidate solution.
    // `ratio` (out, may be null) is eps/tolq for the timestep update; a
    // device without enough LTE history accepts with ratio 0.
    [[nodiscard]] virtual bool lte_ok(const TranStep& step,
                                      const std::vector<double>& x,
                                      std::size_t node_count, double reltol,
                                      double chgtol, double trtol,
                                      const double* st, double* ratio) const {
        (void)step;
        (void)x;
        (void)node_count;
        (void)reltol;
        (void)chgtol;
        (void)trtol;
        (void)st;
        if (ratio != nullptr) {
            *ratio = 0.0;
        }
        return true;
    }

    // Seeds the dynamic state at t=0 from the OP solution (or the UIC
    // vector: .ic node values, device ic= overrides, zeros elsewhere).
    virtual void seed_state(const std::vector<double>& x, std::size_t node_count,
                            double* st) {
        (void)x;
        (void)node_count;
        (void)st;
    }

    // Re-evaluates a solution-dependent device state (a switch control,
    // a diode's per-iterate Vd/I trackers for pnjlim + nonlinear_residual)
    // against the candidate x; true when the state changed in a way that
    // demands another solve (a switch flipping). Called by the Newton loop
    // after every solve.
    //
    // §3.6 (M3): `x_prev` (when not null) is the PRE-solve iterate - the x
    // the load just linearized against. Nonlinear devices use it to
    // advance their pnjlim/reference slots: at iteration k the load sees
    // x = x_prev = x[k-1], and the diode stores Vd(x[k-1]) as next
    // iteration's vold. May be null in non-Newton contexts (initial seed
    // passes); devices must tolerate that. `params` (M4d) is this device's
    // bound parameter slice - behavioral sources need it to evaluate their
    // residual against the true gains; null in contexts that have none.
    // `temp_k` (M5, §7.7) is the run temperature in KELVIN (the circuit's
    // elaboration temperature) - the same value the load contexts expose,
    // for the temp-dependent model equations (Vt(T), Is(T)) this hook
    // evaluates.
    [[nodiscard]] virtual bool update_state(
        const std::vector<double>& x, std::size_t node_count, double* st,
        const std::vector<double>* x_prev = nullptr,
        const double* params = nullptr, double temp_k = 300.15) {
        (void)x;
        (void)node_count;
        (void)st;
        (void)x_prev;
        (void)params;
        (void)temp_k;
        return false;
    }

    // §3.6/§5.1 (M3): the worst normalized terminal-current change since
    // the previous load, complementing the kernel's voltage-delta
    // convergence check. Linear devices (the default) report {0, 0} and
    // never gate convergence. Read from the device's state slice (the
    // diode stores I_cur and I_prev there through update_state).
    [[nodiscard]] virtual NonlinResid nonlinear_residual(const double* /*st*/) const {
        return {0.0, 0.0};
    }

    // --- terminal-current probes (§7.8: the i(name) columns a device can
    // answer that MNA does not carry as an unknown) --------------------------
    //
    // A device WITHOUT a branch row can still know its terminal current at
    // a solution: the diode evaluates Shockley directly from its terminal
    // voltages. probes_current() says the save list should carry an
    // "i(<name>)" column for this device; terminal_current() evaluates it
    // against the ACCEPTED solution `x` (node voltages then branch
    // unknowns; ground is kGround). `params` is this device's bound
    // parameter slice (the update_state convention), null when the caller
    // has none bound. `temp_k` (M5) is the run temperature in KELVIN (the
    // update_state convention) for the temp-dependent current equations.
    // Sign convention: positive current flows from the first terminal to
    // the second (the diode: anode -> cathode).
    [[nodiscard]] virtual bool probes_current() const { return false; }
    [[nodiscard]] virtual double terminal_current(
        const std::vector<double>& /*x*/, std::size_t /*node_count*/,
        const double* /*params*/, double /*temp_k*/ = 300.15) const {
        return 0.0;
    }

    // A load-path failure channel (§8.5, M4d): loads are const and void,
    // so a nonlinear device whose evaluation left its domain (a behavioral
    // expression at sqrt(-1), a division by zero) cannot report it inline.
    // The kernel calls this right after every numeric load pass with the
    // SAME iterate the load used; a non-empty Status aborts the pass (and
    // the ladder - no homotopy rescues an out-of-domain expression).
    // `step` (when not null) is the transient step being loaded. `params`
    // is this device's bound parameter slice, `node_count` the MNA node
    // count (branch unknowns index past it). The default (every linear
    // device) never fails.
    [[nodiscard]] virtual ws::core::Status load_error(
        const std::vector<double>& /*x*/, const TranStep* /*step*/,
        const double* /*params*/, std::size_t /*node_count*/) const {
        return {};
    }

    // The next source-schedule event strictly after `t` (§6.4), or +inf
    // when the device publishes none. tstep/tstop resolve the deferred
    // waveform defaults (see TranStep). `st` (M4e) is this device's
    // state slice - the §3.5 explicit-slice convention the other dynamic
    // hooks already follow - so a state-scheduled device (the T-line's
    // delay-crossing breakpoints over its history ring) can publish
    // events without reaching into a RunState. Null in contexts that
    // have no state bound (default-implementations must tolerate it).
    [[nodiscard]] virtual double next_event(double t, double tstep,
                                             double tstop,
                                             const double* st = nullptr) const {
        (void)t;
        (void)tstep;
        (void)tstop;
        (void)st;
        return std::numeric_limits<double>::infinity();
    }

    // True when this source carries an `AC mag [phase]` spec (§7.4's
    // no-AC-stimulus check).
    [[nodiscard]] virtual bool has_ac() const { return false; }

    // --- K coupling protocol (src-internal; resolved by the elaborator) -----

    // Offers this device a mutual-inductance partner; false when this is
    // not an inductor or it is already coupled (multi-winding is backlog).
    [[nodiscard]] virtual bool couple_to(Device& partner, double k) {
        (void)partner;
        (void)k;
        return false;
    }
    [[nodiscard]] virtual double inductance() const { return 0.0; }

    // Applies a resolved .model card (S/W switches; R models land M5).
    // `nodes` (post-M4e-diode-Rs) lets a model create INTERNAL nodes -
    // the diode's Rs needs a series node, and the model (hence Rs) is
    // only resolved after every factory has run. resolve_models sits
    // BEFORE the §6.6 graph checks, so a node claimed here joins them
    // like any other; the MNA pattern dry run runs later still.
    [[nodiscard]] virtual ws::core::Status apply_model(const ModelDef& model,
                                                        NodeResolver& nodes);

    // ic= initial conditions (§6.5): C carries volts, L carries amps.
    [[nodiscard]] virtual bool has_ic() const { return false; }
    [[nodiscard]] virtual double ic_value() const { return 0.0; }

    // Fills the controlling branch for F/H (second elaboration pass,
    // after every V source claimed its branch). No-op on others. `which`
    // selects among the device's control references (a behavioral B names
    // one slot per i(Vname) occurrence; F/H/W have a single slot and
    // ignore it).
    virtual void set_control_branch(BranchId /*branch*/, std::size_t /*which*/ = 0) {}

    // --- netlist round-trip (§10.2 rev) ---------------------------------------
    //
    // Writes this device as one netlist card. `w` names nodes and branch
    // owners and exposes the CURRENT bound parameter values (the writer
    // snapshots a RunState, so a flattened, fully-numeric deck comes out -
    // exactly what a reference simulator wants to consume). Returns false
    // when the device cannot be written: the writer then fails naming it -
    // a loud gap, never a silently truncated netlist.
    class CardWriter;
    [[nodiscard]] virtual bool write_card(std::string& /*out*/,
                                          const CardWriter& /*w*/) const {
        return false;
    }
};

// --- load contexts (§3.3) -------------------------------------------------------

// DC/OP/transient stamping surface. The pattern recorder is a private
// subclass inside the MNA layer, so pattern mode runs this same code path.
//
// §3.6 (M3): nonlinear devices need the CURRENT iterate to linearize
// against - `node_v()`/`branch_i()` expose it. The pattern recorder
// returns 0 for both (a linearization around V=0 still produces finite,
// well-defined stamp POSITIONS, which is all the pattern dry run needs).
// `gmin()` exposes the run's junction-parallel conductance (§5.2 ladder
// stage 2) so nonlinear devices can fold it into their stamp without
// reaching into RunSettings. §7.7 (M5): `temp_k()` is the run's
// temperature in KELVIN - the circuit's elaboration temperature (every
// temp change re-elaborates, §7.7), so a load never needs to ask
// anything else. Pattern mode returns the default 27 °C.
class DcLoadContext {
public:
    virtual ~DcLoadContext() = default;

    // Raw primitives. row/col index the MNA system (nodes first, then
    // branches); ground (kGround) entries are skipped. Matrix entries
    // ACCUMULATE (+=), rhs too.
    virtual void add_entry(std::size_t row, std::size_t col, double v) = 0;
    virtual void add_rhs(std::size_t row, double v) = 0;

    // The MNA row of a branch unknown: node_count + branch id (§3.3) -
    // branch rows number AFTER the nodes, and only the system knows how
    // many nodes there are, so devices never compute this themselves.
    [[nodiscard]] virtual std::size_t branch_row(BranchId br) const = 0;

    // True while the pattern dry run records (state-dependent devices
    // stamp the union of their states, §3.2).
    [[nodiscard]] virtual bool pattern_mode() const = 0;

    // §3.6: the current iterate's node voltage (V to ground; ground → 0)
    // and branch current. Pattern mode returns 0 - the linearization
    // around zero produces the right POSITIONS, which is all the dry run
    // records.
    [[nodiscard]] virtual double node_v(NodeId n) const = 0;
    [[nodiscard]] virtual double branch_i(BranchId br) const = 0;

    // §5.2: the run's gmin (junction-parallel conductance floor) so
    // nonlinear devices can fold it into their linearization without
    // reaching into RunSettings. Pattern mode returns the default.
    [[nodiscard]] virtual double gmin() const = 0;

    // §7.7 (M5): the run temperature in KELVIN (the circuit's elaboration
    // temperature - a `.dc temp` / `.step temp` point re-elaborates, so
    // this is always the temperature the devices must evaluate at).
    // Pattern mode returns the 27 °C default (values never matter there).
    [[nodiscard]] virtual double temp_k() const = 0;

    // --- this device's slices (set by the system before every call) ------
    //
    // params_ points at param_specs().size() doubles; state_ at
    // state_slots() doubles (zeroed scratch in pattern mode). Loads only
    // READ state - the dynamic hooks own mutation through their own
    // slices. par()/st() are the only sanctioned accessors.
    const double* params_ = nullptr;
    const double* state_ = nullptr;

    [[nodiscard]] double par(std::size_t i) const { return params_[i]; }
    [[nodiscard]] double st(std::size_t i) const { return state_[i]; }

    // --- helpers (inline, non-virtual; §3.3) --------------------------------

    // Conductance g between a and b (ground allowed on either side).
    void add_conductance(NodeId a, NodeId b, double g) {
        add_entry(a, a, g);
        add_entry(b, b, g);
        add_entry(a, b, -g);
        add_entry(b, a, -g);
    }

    // Current i injected INTO a, out of b (a current source arrow a <- b).
    void add_current(NodeId a, NodeId b, double i) {
        add_rhs(a, i);
        add_rhs(b, -i);
    }

    // A voltage-source-style branch row for (p, n) with equation
    // v(p) - v(n) = v: stamps the branch equation and the KCL coupling.
    void stamp_branch_voltage(BranchId br, NodeId p, NodeId n, double v) {
        const std::size_t row = branch_row(br);
        add_entry(row, p, 1.0);
        add_entry(row, n, -1.0);
        add_entry(p, row, 1.0);
        add_entry(n, row, -1.0);
        add_rhs(row, v);
    }
};

// The small-signal twin for .ac (§7.4): same shape, complex values.
// `omega` is the angular frequency being stamped; the device
// linearization is the one frozen at the OP. §3.6 (M3): the device's
// state slice IS exposed (read-only) so nonlinear devices can recover
// their OP linearization point (a diode's Gd_op from Vd_prev) without
// re-solving. §7.5 (M5): during a .noise forward solve `noise_input`
// names the analysis's input source - every source stamps zero EXCEPT
// it (and it stamps 1+0j, ignoring its declared AC spec, exactly
// ngspice's MODEACNOISE); null in a plain .ac run, where sources use
// their declared specs. §3.6 (M6, JFET): `gmin()` is the run's
// junction-parallel conductance floor - the SAME floor the OP stamp
// folded in. A reverse-biased junction's small-signal conductance
// underflows to ~1e-20 and below (a JFET's gate in normal operation,
// a diode past a few volts of reverse bias), leaving its matrix column
// numerically dead - the complex factorize fails as singular. The
// floor keeps the small-signal system as well-conditioned as the OP
// system it linearizes (ngspice's small-signal matrix carries the OP's
// gmin likewise). Default 1e-12 (SPICE's) for the pattern contexts,
// where values never matter.
class AcLoadContext {
public:
    virtual ~AcLoadContext() = default;

    virtual void add_entry(std::size_t row, std::size_t col, std::complex<double> v) = 0;
    virtual void add_rhs(std::size_t row, std::complex<double> v) = 0;
    [[nodiscard]] virtual std::size_t branch_row(BranchId br) const = 0;

    // §7.7 (M5): the run temperature in KELVIN (see DcLoadContext).
    [[nodiscard]] virtual double temp_k() const = 0;

    // §5.2: the run's gmin (see the class comment).
    [[nodiscard]] virtual double gmin() const { return 1e-12; }

    // §7.5 (M5): the .noise input source (see the class comment); null
    // in a plain .ac run.
    const Device* noise_input = nullptr;

    // This device's parameter slice + (M3) state slice: the OP
    // linearization is frozen at the .ac solve, and nonlinear devices
    // read their OP operating point (Vd, Vgs, ...) back through `st()`.
    const double* params_ = nullptr;
    const double* state_ = nullptr;
    [[nodiscard]] double par(std::size_t i) const { return params_[i]; }
    [[nodiscard]] double st(std::size_t i) const { return state_[i]; }

    double omega = 0.0;

    void add_conductance(NodeId a, NodeId b, std::complex<double> g) {
        add_entry(a, a, g);
        add_entry(b, b, g);
        add_entry(a, b, -g);
        add_entry(b, a, -g);
    }
    void add_current(NodeId a, NodeId b, std::complex<double> i) {
        add_rhs(a, i);
        add_rhs(b, -i);
    }
    void stamp_branch_voltage(BranchId br, NodeId p, NodeId n, std::complex<double> v) {
        const std::size_t row = branch_row(br);
        add_entry(row, p, 1.0);
        add_entry(row, n, -1.0);
        add_entry(p, row, 1.0);
        add_entry(n, row, -1.0);
        add_rhs(row, v);
    }
};

// The noise twin (§7.5, M5): per-frequency density contributions at the
// frozen OP. Devices report each uncorrelated noise generator as a
// CURRENT source PSD (A^2/Hz) between two nodes; the driver folds in the
// adjoint gain |x_a[p]-x_a[n]|^2 itself (one adjoint solve serves every
// source, §7.5). `freq` is the density's frequency (Hz) and `temp_k` the
// run temperature (K) - the R thermal 4kT/R and junction formulas read
// both. The parameter/state slices follow the load-context convention
// (the OP lives in the state slice, exactly like load_ac).
class NoiseContext {
public:
    virtual ~NoiseContext() = default;

    // Reports one uncorrelated noise current source: name is the
    // SPICE-style source tag ("rs", "id", "1overf", "thermal", "ib",
    // "ic", "fn" - ngspice's per-device naming); the PSD is in A^2/Hz
    // between p and n (either may be ground).
    virtual void add_source(const char* name, NodeId p, NodeId n,
                            double psd) = 0;

    const double* params_ = nullptr;
    const double* state_ = nullptr;
    [[nodiscard]] double par(std::size_t i) const { return params_[i]; }
    [[nodiscard]] double st(std::size_t i) const { return state_[i]; }

    double freq = 0.0;    // Hz (the density's frequency)
    double temp_k = 300.15;  // the run temperature, K

    // The OP solution (node voltages then branch currents; null when the
    // caller has none): linear devices without state slots (the resistor)
    // read their DC operating current back through it. Ground reads 0.
    const std::vector<double>* op = nullptr;
    [[nodiscard]] double node_v(NodeId n) const {
        if (op == nullptr || n == kGround) {
            return 0.0;
        }
        return (*op)[n];
    }
};

// The factory signature: card + services -> device. The factory table
// lives on the elaborator object, never a process-global (§3.4).
using DeviceFactory = ws::core::Result<std::unique_ptr<Device>> (*)(
    const struct DeviceCard& card, FactoryServices& services);

// The netlist-writing view a device's write_card() sees (§10.2 rev):
// node names (ground included), the owning device's name for a branch
// row (F/H/W control references), and this device's bound parameter
// values. One concrete implementation lives in src/netlist.cpp over a
// (Circuit, RunState) pair.
class Device::CardWriter {
public:
    virtual ~CardWriter() = default;
    // The node's display name; "0" for ground.
    [[nodiscard]] virtual const std::string& node(NodeId id) const = 0;
    // The name of the device owning branch `br` (a V/E/H/L source).
    [[nodiscard]] virtual const std::string& branch_owner(BranchId br) const = 0;
    // This device's bound parameter values (param_specs() order).
    [[nodiscard]] virtual const double* params(const Device& dev) const = 0;
    // The shortest exactly-round-tripping spelling of a double.
    [[nodiscard]] static std::string num(double v);
};

}  // namespace ws::spice
