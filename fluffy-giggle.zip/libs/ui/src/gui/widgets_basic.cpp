// ws::ui::gui widget functions, one family per file (src/gui/CLAUDE.md):
// the static chrome rows - collapsing_header, selectable, text,
// separator, progress - plus fit_text, the public label measure every
// family file fits its labels through. One definition for the archive:
// it lives here, beside the text widget that shows what it measures.

#include "widgets_detail.hpp"

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <string_view>
#include <vector>

namespace ws::ui::gui {
namespace {

// The busy indicators' persistent halves: the wrap-around phase each
// one advances on the frame clock, keyed by the widget's label - the
// one number a running indicator owns. Two structs, not one shared:
// persistent_state keys by type as well as id, and a caller laying a
// spinner and an indeterminate bar under one label would otherwise
// share (and fight over) one phase.
struct SpinnerPhase {
    float phase = 0.0f;  // [0, 1): the turn, one eighth per bright dot
};
struct IndeterminatePhase {
    float phase = 0.0f;  // [0, 1): the sweep, the band's trip across
};

// Capacity of the stack buffer each widget hands fit_text. A label that
// needs more than this truncates, whatever width it was given.
constexpr std::size_t kLabelScratchBytes = 128;

// Hard pixel metrics: literals on purpose (not theme metrics), named here
// so each is stated once and the draw code reads as intent.
constexpr float kSelectionBarWidth = 3.0f;   // selectable's left accent bar
constexpr float kSeparatorThickness = 2.0f;  // separator's rule
constexpr float kFillInset = 1.0f;           // progress fill / band, per side
constexpr float kStatusTextDim = 0.85f;      // status_bar text, vs. body text

// Busy-indicator timing and geometry.
constexpr float kSpinnerPeriodSeconds = 0.8f;  // one full turn
constexpr float kSweepPeriodSeconds = 1.2f;    // one band trip
constexpr int kSpinnerDots = 8;
constexpr float kSpinnerTwoPi = 6.2831853f;
constexpr float kSpinnerHalfPi = 1.5707963f;

// True for a UTF-8 continuation byte (10xxxxxx): never the start of a
// codepoint, so a cut must not land on it.
bool is_utf8_continuation(char c) {
    return (static_cast<unsigned char>(c) & 0xC0u) == 0x80u;
}

// Advance a wrap-around phase on the frame clock. A zero dt (headless),
// a negative one (clock stepped back) or a non-finite one holds the
// phase: a negative phase would index a negative dot / start the band
// off-screen, and NaN would poison the state for good.
float advance_phase(float phase, float dt_seconds, float period_seconds) {
    if (!(dt_seconds > 0.0f) || !std::isfinite(dt_seconds)) {
        return phase;
    }
    return std::fmod(phase + dt_seconds / period_seconds, 1.0f);
}

}  // namespace

// fit_text's body. The display cut first (label_display - "##" id
// suffixes never draw), then the width pass: the whole display when it
// fits, and only a miss truncates - longest fitting prefix + ASCII
// "..." - the cut backed up over UTF-8 continuation bytes so no
// codepoint splits (the fontless theme never draws the text, but the
// answer is a C string any caller could). Both measures ride one
// lambda: the theme font's honest glyph advance, or the per-byte
// estimate the v1 bars size from. The copy lands in the CALLER'S
// scratch - the only buffer fit_text ever writes - and only when
// something changed, so the mid-frame no-allocation rule holds on
// every path.
LabelFit fit_text(const char* label, float max_width,
                  const ChromeTheme& theme, char* scratch,
                  std::size_t scratch_bytes) {
    if (label == nullptr) {
        return {"", 0.0f};  // no label at all: nothing to draw
    }
    const std::string_view display = label_display(label);
    if (display.empty()) {
        return {"", 0.0f};  // nothing to say: nothing to draw
    }

    // A marker cut the display when the label continues past it: the
    // view over the label is not null-terminated at the cut, so the
    // display moves into scratch as draw-ready bytes. No scratch, no
    // cut - and nothing drawable.
    const char* text = label;
    if (label[display.size()] != '\0') {
        if (scratch == nullptr || scratch_bytes < display.size() + 1) {
            return {"", 0.0f};
        }
        std::memcpy(scratch, display.data(), display.size());
        scratch[display.size()] = '\0';
        text = scratch;
    }

    // The advance of the display as it stands: the font's measure, or
    // (fontless) the estimate - per byte, the v1 bar's arithmetic.
    const auto measure = [&](const char* s, std::size_t bytes) {
        if (theme.font != nullptr) {
            return theme.font->measure_text(s);
        }
        return static_cast<float>(bytes) * theme.label_char_width;
    };
    const float whole = measure(text, display.size());
    if (max_width < 0.0f || whole <= max_width) {
        return {text, whole};  // fits (or nobody asked for a width)
    }

    // Truncation: prefixes longest-first, each composed in scratch as
    // prefix + "..." and measured whole. The whole display already
    // missed, so the longest candidate cuts at least one byte; k = 0
    // is the bare "..." - the last resort, and past it nothing draws.
    if (scratch == nullptr || scratch_bytes < 4) {
        return {"", 0.0f};  // not even the bare "..." could be built
    }
    const std::size_t cap = scratch_bytes - 1;  // room for the terminator
    std::size_t k_max = display.size() - 1;  // cut at least one byte
    if (k_max > cap - 3) {
        k_max = cap - 3;  // the longest prefix that + "..." still fits
    }
    for (std::size_t k = k_max + 1; k-- > 0;) {
        // UTF-8: back up while the byte at the cut continues the
        // codepoint before it - the prefix keeps whole codepoints
        // (corrupt bytes stay corrupt; utf8_next forgives them).
        while (k > 0 && is_utf8_continuation(display[k])) {
            --k;
        }
        std::memcpy(scratch, display.data(), k);
        scratch[k] = '.';
        scratch[k + 1] = '.';
        scratch[k + 2] = '.';
        scratch[k + 3] = '\0';
        const float advance = measure(scratch, k + 3);
        if (advance > 0.0f && advance <= max_width) {
            return {scratch, advance};
        }
        if (k == 0) {
            break;  // the bare "..." was the last candidate
        }
    }
    return {"", 0.0f};  // not even "..." fits: nothing drawable
}

bool collapsing_header(GuiContext& gui, LayoutCursor& layout,
                       const ChromeTheme& theme, const char* label,
                       bool& open, float width, bool disabled) {
    // Fill-width: a header wants its container's line.
    const RowLayout row = begin_widget_row(gui, layout, theme, label, width);
    CollapsingHeaderResult result =
        collapsing_header_behavior(gui, row.id, row.rect, open, disabled);
    fold_hover_t(gui, row.id, result, theme);  // P4: the face traveler
    paint(theme, &WidgetPainters::collapsing_header,
          &collapsing_header_draw, row.rect, result, theme, label, open);
    // The answer is the state AFTER the flip: the caller's `if` places
    // this frame's children when the click just opened it.
    return open;
}

CollapsingHeaderResult collapsing_header_behavior(
    GuiContext& gui, WidgetId id, const Rect& rect, bool& open,
    bool disabled, const HitShape& hit_shape) {
    CollapsingHeaderResult result{
        begin_widget_paint(gui, id, rect, disabled, hit_shape)};
    result.toggled = result.hit.clicked || key_activated(gui, id);
    if (result.toggled) {
        open = !open;  // the caller's bool is the state; a click flips it
    }
    return result;
}

void collapsing_header_draw(const Rect& rect,
                            const CollapsingHeaderResult& result,
                            const ChromeTheme& theme, const char* label,
                            bool open) {
    // The focus ring: the on-accent as a 1px outline behind the row, so
    // Tab navigation is legible. Skipped for degenerate rows.
    ring_draw(result.focused, rect, theme);

    // The disabled look: the dead face for the row, the marker and the
    // label dimmed through the one helper.
    const float dim_by = dim_factor(result.state, theme);

    // The row: the faces a button wears, rounded by the theme - the
    // snapped rect (P6).
    const std::uint32_t face = control_face(result.state, theme);
    const Rect snapped = snap_rect(rect);
    r2d::draw_rounded_quad(snapped.x, snapped.y, snapped.width,
                           snapped.height, theme.corner_radius, face);

    // The marker (P6): the built-in chevrons through the icon mapping -
    // right closed, down open, the accent open and the faint border
    // closed exactly like the square's colors. The sentinel sprite
    // (no font, no set) keeps the pre-icon square: today's look.
    const float box = theme.control_height;
    const float inset = std::max(theme.check_inset, theme.corner_radius);
    const float marker = box - 2.0f * inset;
    if (marker > 0.0f) {
        const std::uint32_t mark_color =
            open ? dim(theme.control_on, dim_by) : dim(theme.border, dim_by);
        const r2d::Sprite mark = icon_sprite_of(
            theme, open ? Icon::chevron_down : Icon::chevron_right);
        if (mark.page != 0) {
            draw_icon(snapped.x + inset, snapped.y + inset, marker, mark,
                      mark_color);
        } else {
            r2d::draw_quad(snapped.x + inset, snapped.y + inset, marker,
                           marker, mark_color);
        }
    }

    // The label beside the marker, like a checkbox's - LEFT-aligned: a
    // header reads from the left. Fitted to the room the marker leaves
    // (minus a face inset each side).
    const float gap = theme.spacing;
    char scratch[kLabelScratchBytes];
    const LabelFit fit =
        fit_text(label, std::max(0.0f, rect.width - box - gap -
                                          2.0f * theme.label_inset),
                 theme, scratch, sizeof(scratch));
    draw_label(rect.x + box + gap, rect.y, rect.height, fit,
               dim(theme.text, dim_by), theme);
}

bool selectable(GuiContext& gui, LayoutCursor& layout,
                const ChromeTheme& theme, const char* label, bool selected,
                float width, bool disabled) {
    // Fill-width: list rows want their container's line.
    const RowLayout row = begin_widget_row(gui, layout, theme, label, width);
    SelectableResult result =
        selectable_behavior(gui, row.id, row.rect, disabled);
    fold_hover_t(gui, row.id, result, theme);  // P4: the face traveler
    paint(theme, &WidgetPainters::selectable, &selectable_draw,
          row.rect, result, theme, label, selected);
    return result.clicked;
}

SelectableResult selectable_behavior(GuiContext& gui, WidgetId id,
                                     const Rect& rect, bool disabled,
                                     const HitShape& hit_shape) {
    SelectableResult result{
        begin_widget_paint(gui, id, rect, disabled, hit_shape)};
    // Keyboard select: Enter or Space reports the focused row, edge-only
    // - a click with no pointer involved. The selection itself stays
    // the caller's to write.
    result.clicked = result.hit.clicked || key_activated(gui, id);
    return result;
}

void selectable_draw(const Rect& rect, const SelectableResult& result,
                     const ChromeTheme& theme, const char* label,
                     bool selected) {
    // The focus ring: the on-accent as a 1px outline behind the row.
    // Skipped for degenerate rows.
    ring_draw(result.focused, rect, theme);

    const float dim_by = dim_factor(result.state, theme);

    // The bare-list face: an unselected, unhovered row draws nothing at
    // all - hover, press and the disabled scope take the usual faces.
    if (const auto face = list_face_of(result, theme)) {
        r2d::draw_rounded_quad(rect.x, rect.y, rect.width, rect.height,
                               theme.corner_radius, *face);
    }

    // The selection marker: a 3-px accent bar down the row's left edge -
    // the v1 look, a hardcoded pixel like the separator's 2. It rides
    // every face (or the bare row), dimmed under the disabled scope.
    if (selected && rect.width > 0.0f && rect.height > 0.0f) {
        r2d::draw_quad(rect.x, rect.y, kSelectionBarWidth, rect.height,
                       dim(theme.control_on, dim_by));
    }

    // The label, left-aligned past the bar's room (selected and
    // unselected rows align).
    char scratch[kLabelScratchBytes];
    const LabelFit fit =
        fit_text(label, std::max(0.0f, rect.width - theme.check_inset -
                                          theme.label_inset),
                 theme, scratch, sizeof(scratch));
    draw_label(rect.x + theme.check_inset, rect.y, rect.height, fit,
               dim(theme.text, dim_by), theme);
}

void text(LayoutCursor& layout, const ChromeTheme& theme,
          const char* label, float width) {
    // Chrome: no id, no hit-test, no state - it lays out and draws, and
    // that is all. A caller wanting a faded label dims its own theme
    // copy; the gui does not invent a Disabled state for something that
    // cannot be disabled.
    char scratch[kLabelScratchBytes];
    const LabelFit fit = fit_text(label, width < 0.0f ? -1.0f : width, theme,
                                  scratch, sizeof(scratch));
    // A negative width sizes the row to the label's DISPLAY advance -
    // marker-cut, never truncated, like a checkbox's sizing fit (and a
    // "##" suffix neither ids nor sizes anything here: it just never
    // draws). A fixed width pins the row and truncates the label into
    // it instead. fit_text's own tests own the truncation ladder.
    const Rect rect =
        layout.next(width < 0.0f ? fit.advance : width, theme.control_height);
    draw_label(rect.x, rect.y, rect.height, fit, theme.text, theme);
}

int text_wrapped(LayoutCursor& layout, const ChromeTheme& theme,
                 const char* label, float width) {
    // The truncation-free face of text(): the word wrap. The breaks
    // are computed first (the flow needs the count before it reserves
    // anything), then one line-height row per line draws its slice
    // through the same draw_label every body row uses. Breaks land at
    // spaces only; a hard '\n' always breaks; a word wider than the
    // whole width rides its own line whole rather than splitting
    // mid-word - THE rule this widget exists to keep. Fontless: the
    // estimate's arithmetic (per byte, label_char_width) walks the
    // same ladder, so the flow reserves honest room either way.
    if (label == nullptr || *label == '\0') {
        return 0;
    }
    const float max_w = width < 0.0f
                            ? std::max(0.0f, layout.remaining_width())
                            : width;
    const float line_h = theme.font != nullptr &&
                                 theme.font->line_height() > 0.0f
                             ? theme.font->line_height() + 2.0f
                             : theme.control_height;
    // The measure the wrap walks: the font's honest advance, or the
    // fontless per-byte estimate (a view of bytes, no terminator
    // needed - measure_text takes a C string, so the font path
    // measures through a stack copy below).
    const auto measure_view = [&](std::string_view s) {
        if (s.empty()) {
            return 0.0f;
        }
        if (theme.font == nullptr) {
            return static_cast<float>(s.size()) * theme.label_char_width;
        }
        char buf[kLabelScratchBytes];
        const std::size_t n = std::min(s.size(), kLabelScratchBytes - 1);
        std::memcpy(buf, s.data(), n);
        buf[n] = '\0';
        return theme.font->measure_text(buf);
    };

    // The wrap, greedy: walk to the next WORD (spaces and newlines
    // never stall the walk - a space between words is consumed by the
    // next word's advance), keep the word when the joined run still
    // fits, flush at '\n' or when the next word would overflow. A word
    // that starts a line ALWAYS rides (`scan == line_begin`: a word
    // wider than the whole line stands alone, whole - never split
    // mid-word).
    std::vector<std::string_view> lines;
    std::string_view rest(label);
    std::size_t line_begin = 0;
    std::size_t scan = 0;  // the walk's position (a word start or a break)
    while (scan < rest.size()) {
        if (rest[scan] == '\n') {
            // A hard break: flush the standing line (maybe empty), the
            // next line starts past the newline.
            lines.push_back(rest.substr(line_begin, scan - line_begin));
            line_begin = ++scan;
            continue;
        }
        if (rest[scan] == ' ') {
            // A separator: advance (the space stays INSIDE the joined
            // run - substr spans it - and never begins a word's scan).
            ++scan;
            continue;
        }
        // A word at `scan`: its end (the next space or newline).
        std::size_t word_end = scan;
        while (word_end < rest.size() && rest[word_end] != ' ' &&
               rest[word_end] != '\n') {
            ++word_end;
        }
        const std::string_view joined =
            rest.substr(line_begin, word_end - line_begin);
        const bool fits = scan == line_begin ||
                          measure_view(joined) <= max_w;
        if (fits) {
            scan = word_end;  // keep the word
            continue;
        }
        // The next word would overflow: flush the standing line, the
        // new one starts at THIS word (the space it rode on stays out
        // of the flush - substr(line_begin, scan) cuts before it).
        lines.push_back(rest.substr(line_begin, scan - line_begin));
        line_begin = scan;
    }
    // The tail: whatever stands after the last break, even just a
    // lone word (an empty tail means the text ENDED on a '\n').
    if (line_begin < rest.size()) {
        lines.push_back(rest.substr(line_begin));
    }

    int drawn = 0;
    for (const std::string_view line : lines) {
        const Rect rect = layout.next(max_w, line_h);
        char buf[kLabelScratchBytes];
        const std::size_t n = std::min(line.size(), kLabelScratchBytes - 1);
        std::memcpy(buf, line.data(), n);
        buf[n] = '\0';
        // draw_label handles both faces: the font's glyphs at the
        // snapped line top, or the fontless bar at the fitted advance
        // (which a fontless theme answers per byte - the same
        // estimate the wrap itself walked, so bar width and reserved
        // row agree).
        const LabelFit fit = fit_text(buf, -1.0f, theme, buf, sizeof(buf));
        draw_label(rect.x, rect.y, rect.height, fit, theme.text, theme);
        ++drawn;
    }
    return drawn;
}

void heading(LayoutCursor& layout, const ChromeTheme& theme,
             const char* label, float width) {
    // The section break: the strong face at its own baked size, on a
    // row a step taller than a body row. The strong face is the
    // CALLER'S bake (circsim's 18 px semibold against the 16 px body),
    // so the hierarchy is two bakes and one pointer - the theme's
    // documented shape - and the heading just follows whatever size
    // that face carries. fit_text and draw_label read the font off the
    // theme, so the heading rides a swapped COPY (the palette-fade
    // idiom's own move: a local theme variant, never a mutation); a
    // null font_strong falls back to `font`, and fontless the taller
    // bar carries the hierarchy alone.
    const r2d::Font* face =
        theme.font_strong != nullptr ? theme.font_strong : theme.font;
    ChromeTheme strong = theme;
    strong.font = face;
    const float line_h = face != nullptr ? face->line_height()
                                         : theme.control_height * 0.55f;
    const float row_h =
        std::max(theme.control_height + 2.0f, line_h + 10.0f);
    char scratch[kLabelScratchBytes];
    const LabelFit fit = fit_text(label, width < 0.0f ? -1.0f : width, strong,
                                  scratch, sizeof(scratch));
    const Rect rect =
        layout.next(width < 0.0f ? fit.advance : width, row_h);
    draw_label(rect.x, rect.y, rect.height, fit, theme.text, strong);
}

void separator(LayoutCursor& layout, const ChromeTheme& theme, float width) {
    // Fill-width, like button: a negative width means "the rest of the
    // line", resolved against the cursor before the clamp.
    resolve_width(width, layout);
    // A 2-px rule - a hardcoded pixel like the focus ring's 1, not a
    // theme metric. theme.border is the faint line that never competes
    // with content, and the flow's own spacing gives it air on both
    // sides.
    const Rect rect = layout.next(width, kSeparatorThickness);
    r2d::draw_quad(rect.x, rect.y, rect.width, rect.height, theme.border);
}

void progress(LayoutCursor& layout, const ChromeTheme& theme,
              float fraction, float width) {
    // Fill-width, like button: a negative width means "the rest of the
    // line", resolved against the cursor before the clamp.
    resolve_width(width, layout);
    // Clamp to [0, 1], NaN-safe: the inverted comparisons catch a NaN
    // (it fails >= 0) and read it as empty rather than letting it
    // through to the draw.
    if (!(fraction >= 0.0f)) {
        fraction = 0.0f;
    }
    if (!(fraction <= 1.0f)) {
        fraction = 1.0f;
    }
    const Rect rect = layout.next(width, theme.control_height);
    r2d::draw_rounded_quad(rect.x, rect.y, rect.width, rect.height,
                           theme.corner_radius, theme.control_bg);
    // The fill: the accent over the track, rounded with the theme. It
    // insets a hard 1 px (a literal like the focus ring's 1) on every
    // side: the SDF shades a half-pixel antialiasing ramp past the ideal
    // edge, and a fill flush with the track paints that ramp on the
    // track's own outline - the accent reading as escaped. The draw also
    // clamps the radius to the fill's own half-height, so a thin sliver
    // reads as a dot rather than an over-rounded bar.
    const float fill = fraction * rect.width - 2.0f * kFillInset;
    if (fill > 0.0f) {
        r2d::draw_rounded_quad(rect.x + kFillInset, rect.y + kFillInset, fill,
                               rect.height - 2.0f * kFillInset,
                               theme.corner_radius, theme.control_on);
    }
}

void spinner(GuiContext& gui, LayoutCursor& layout, const ChromeTheme& theme,
             const char* label, float size) {
    // The busy indicator: a square of chasing dots that claims nothing
    // and ids only for its phase - `label` never draws (progress's own
    // label discipline: the caller composes the caption beside it).
    // A negative size takes the control height, like every default.
    if (size < 0.0f) {
        size = theme.control_height;
    }
    size = std::max(size, 0.0f);
    const Rect rect = layout.next(size, size);
    const SpinnerResult result = spinner_behavior(gui, gui.ids().id(label));
    paint(theme, &WidgetPainters::spinner, &spinner_draw, rect, result,
          theme);
}

SpinnerResult spinner_behavior(GuiContext& gui, WidgetId id) {
    SpinnerPhase& state = gui.persistent_state<SpinnerPhase>(id);
    // One turn per 0.8 s - the bright dot hands off every tenth of a
    // second, the pace the chase reads at any control size. Headless
    // the frame clock reads 0: the phase holds, the honest answer
    // without time.
    state.phase = advance_phase(state.phase, gui.input().dt_seconds,
                                kSpinnerPeriodSeconds);
    return {state.phase};
}

void spinner_draw(const Rect& rect, const SpinnerResult& result,
                  const ChromeTheme& theme) {
    if (rect.width <= 0.0f || rect.height <= 0.0f) {
        return;  // degenerate: nothing to orbit (the phase still banked)
    }

    // Eight dots on a circle, the bright one wearing the accent and
    // the rest the resting control face. The dot radius keeps a
    // floor (a 1-px dot still reads at tiny sizes), the ring clears
    // it, and a dot draws as a rounded quad at its own half-size - the
    // radius clamp makes each a circle.
    const float center_x = rect.x + rect.width * 0.5f;
    const float center_y = rect.y + rect.height * 0.5f;
    const float dot = std::max(1.0f, rect.width / 16.0f);
    const float ring = std::max(0.0f, rect.width * 0.5f - dot);
    const int bright =
        static_cast<int>(result.phase * static_cast<float>(kSpinnerDots)) %
        kSpinnerDots;
    for (int i = 0; i < kSpinnerDots; ++i) {
        const float angle =
            static_cast<float>(i) *
                (kSpinnerTwoPi / static_cast<float>(kSpinnerDots)) -
            kSpinnerHalfPi;
        const float x = center_x + ring * std::cos(angle);
        const float y = center_y + ring * std::sin(angle);
        r2d::draw_rounded_quad(x - dot, y - dot, 2.0f * dot, 2.0f * dot,
                               dot, i == bright ? theme.control_on
                                                : theme.control_bg);
    }
}

void progress_indeterminate(GuiContext& gui, LayoutCursor& layout,
                            const ChromeTheme& theme, const char* label,
                            float width) {
    // progress's track with nothing to show: a band a third of the
    // track's width sweeps it left to right, wrapping - the busy
    // answer when there is no fraction to draw. `label` ids the bar
    // for its phase and never draws, progress's own label discipline.
    resolve_width(width, layout);
    const Rect rect = layout.next(width, theme.control_height);
    const IndeterminateResult result =
        progress_indeterminate_behavior(gui, gui.ids().id(label));
    paint(theme, &WidgetPainters::progress_indeterminate,
          &progress_indeterminate_draw, rect, result, theme);
}

IndeterminateResult progress_indeterminate_behavior(GuiContext& gui,
                                                    WidgetId id) {
    IndeterminatePhase& state = gui.persistent_state<IndeterminatePhase>(id);
    // One sweep per 1.2 s: fast enough to read as alive, slow enough
    // not to strobe. Headless the band holds.
    state.phase = advance_phase(state.phase, gui.input().dt_seconds,
                                kSweepPeriodSeconds);
    return {state.phase};
}

void progress_indeterminate_draw(const Rect& rect,
                                 const IndeterminateResult& result,
                                 const ChromeTheme& theme) {
    r2d::draw_rounded_quad(rect.x, rect.y, rect.width, rect.height,
                           theme.corner_radius, theme.control_bg);
    if (rect.width <= 2.0f * kFillInset) {
        return;  // no room for a band (headless degenerate included)
    }

    // The band enters off the left edge and exits past the right one,
    // so the visible slice is the intersection with the track - inset
    // the hard 1 px on every side like progress's fill, so the SDF's
    // half-pixel ramp never paints on the track's own outline.
    const float band = rect.width / 3.0f;
    const float span = rect.width + band;  // off-left in to off-right out
    const float pos = -band + result.phase * span;  // the band's left edge
    const float lo = std::max(pos, kFillInset);
    const float hi = std::min(pos + band, rect.width - kFillInset);
    if (hi > lo) {
        r2d::draw_rounded_quad(rect.x + lo, rect.y + kFillInset, hi - lo,
                               rect.height - 2.0f * kFillInset,
                               theme.corner_radius, theme.control_on);
    }
}

Rect status_bar(const ChromeTheme& theme, const char* text) {
    // The frame-anchored strip: full width along the bottom edge, one
    // control height, `text` left-inset past the padding. No row in any
    // flow - no cursor at all - and no id: the caller draws it
    // wherever it fits and keeps its content clear by the returned
    // rect's top edge. Empty frames (headless) answer an empty rect
    // and draw nothing.
    const r2d::FrameSize frame = r2d::frame_size();
    if (frame.width <= 0.0f || frame.height < theme.control_height) {
        return {};
    }
    const Rect rect{0.0f, frame.height - theme.control_height,
                    frame.width, theme.control_height};

    // The chrome: the bar strip's own face (a depth step away from the
    // panels) with a 1-px rule along its top edge - the separator's own
    // look, on the one edge that faces content.
    r2d::draw_quad(rect.x, rect.y, rect.width, rect.height, theme.bar_bg);
    r2d::draw_quad(rect.x, rect.y, rect.width, 1.0f, theme.border);

    // The text, fitted to the width less both insets - a long line
    // truncates like any label. A touch quieter than body text: the
    // status line reports, it does not shout.
    char scratch[kLabelScratchBytes];
    const LabelFit fit =
        fit_text(text, std::max(0.0f, rect.width - 2.0f * theme.padding),
                 theme, scratch, sizeof(scratch));
    draw_label(rect.x + theme.padding, rect.y, rect.height, fit,
               dim(theme.text, kStatusTextDim), theme);
    return rect;
}

}  // namespace ws::ui::gui
