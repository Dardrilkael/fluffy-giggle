# ws::math is a workspace lib (the fixed-size vecmath behind the 3D camera
# path), not a third-party: PUBLIC like ws::core, which apps already receive
# transitively the same way. The include stays internal to src/ - the public
# header keeps plain floats. ws::jobs is the same kind of workspace tier
# (stage 8): App drains an installed system's marshal queue between frames.
# ws::settings + ws::app + ws::platform join because ws_ui_gui (the gui
# archive folded into ws_ui) links them PUBLIC - see the link line below.
# The registry in cmake/WsHelpers.cmake must match this list verbatim;
# ws_add_library fails configure on a mismatch.
ws_add_library(ui DEPENDS ws::core ws::math ws::input ws::gfx ws::jobs ws::settings ws::app ws::platform ws::plotmath)

# The gui subset as its own archive - the stage-2 acceptance cut. It links
# ws::core + ws::input (the frame snapshot it reads; itself core-only,
# pure CPU) + ws::jobs (the job_progress bridge's backend) + ws::settings
# (theme_json's persistence: json, migrations and the FileSystem seam -
# the jobs precedent, the reference lives in a public header) + ws::app
# (stage 13: the command_views bridge - the registry, the shortcut
# resolver and describe_chord all ride in a public gui header, so the
# same PUBLIC precedent applies; itself pure std + core + settings).
# The same
# purity class - pure std + core, no platform anywhere: no Vulkan,
# GLFW, volk or vma target ever appears on its link line, because the
# gui draws through the r2d free-function seam that
# ws_ui's renderer TUs satisfy at the final link. Sources compile once
# (ws_ui links this archive in, so apps see no difference) and
# test_ui_gui below links it WITHOUT the renderer - the acceptance the
# stage set out to prove.
file(GLOB ui_gui_srcs CONFIGURE_DEPENDS
  "${CMAKE_CURRENT_SOURCE_DIR}/src/gui/*.cpp"
  "${CMAKE_CURRENT_SOURCE_DIR}/src/canvas/*.cpp"
  "${CMAKE_CURRENT_SOURCE_DIR}/src/shell/*.cpp")
add_library(ws_ui_gui STATIC ${ui_gui_srcs})
add_library(ws::ui_gui ALIAS ws_ui_gui)
target_include_directories(ws_ui_gui
  PUBLIC "$<BUILD_INTERFACE:${CMAKE_CURRENT_SOURCE_DIR}/include>"
  PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
target_compile_features(ws_ui_gui PUBLIC cxx_std_20)
ws_set_warnings(ws_ui_gui)
target_link_libraries(ws_ui_gui PUBLIC ws::core ws::math ws::input ws::jobs ws::settings ws::app ws::platform ws::plotmath)
target_link_libraries(ws_ui PRIVATE ws_ui_gui)

# Platform + gui sources: exactly one windowing TU builds (the WindowHost
# seam, src/platform/window.h) and the gui TUs live in ws_ui_gui, not here.
# The glob picks up both windowing TUs and every gui TU; drop what this
# target does not use - a mis-filter fails loudly (the wrong TU's platform
# includes are absent), so it can never silently double-compile.
get_target_property(ui_sources ws_ui SOURCES)
if(ui_sources)
  list(REMOVE_ITEM ui_sources ${ui_gui_srcs})
  if(ANDROID)
    list(REMOVE_ITEM ui_sources
      "${CMAKE_CURRENT_SOURCE_DIR}/src/platform/window_glfw.cpp")
  else()
    list(REMOVE_ITEM ui_sources
      "${CMAKE_CURRENT_SOURCE_DIR}/src/platform/window_android.cpp")
  endif()
  set_target_properties(ws_ui PROPERTIES SOURCES "${ui_sources}")
endif()

# Every third-party target is PRIVATE on purpose: apps build against ws::
# names only, and no imgui/vulkan/glfw header or define ever escapes this
# library (apps draw through <ws/ui/widgets.hpp>). Static archives still
# forward these targets to the final link, so symbols resolve.
if(ANDROID)
  target_link_libraries(ws_ui PRIVATE imgui implot volk stb android log)
  # native_app_glue headers for src/platform/window_android.cpp (its .c
  # lands in the
  # app module in A2; the header-only usage here is enough for the seam).
  target_include_directories(ws_ui PRIVATE
    "${ANDROID_NDK}/sources/android/native_app_glue")
else()
  target_link_libraries(ws_ui PRIVATE imgui implot glfw volk stb)
  if(WIN32)
    # window_glfw.cpp's OS dark-mode probe (App::prefers_dark) reads the
    # Personalize key through RegGetValueA, which advapi32 owns. A system
    # lib, not a third-party target - PRIVATE, like every dep here.
    target_link_libraries(ws_ui PRIVATE advapi32)
  endif()
endif()

ws_add_test(ui SOURCES tests/test_ui.cpp)
# ws_add_test no-ops when WS_BUILD_TESTS=OFF (the android preset), so the
# tests' tail settings apply only when the targets exist.
if(TARGET test_ui)
  # tests exercise the internal pure-CPU batch core directly (src/ never
  # reaches apps).
  target_include_directories(test_ui PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
  # renderer2d.h (internal) declares the Vulkan half: the test needs those
  # headers to compile it, though it never drives Vulkan itself. stb is
  # the same PRIVATE class: text/font.h (on the src/ include path since the
  # growing font) declares stb_truetype, so the test needs its dir too.
  target_link_libraries(test_ui PRIVATE volk stb)
endif()

# The idle-frame pacing policy (src/app/frame_pacer.hpp): header-only and
# pure, so its suite links nothing of the app loop (no Vulkan, no window).
ws_add_test(ui_frame_pacer SOURCES tests/test_frame_pacer.cpp LINK ws::core)
if(TARGET test_ui_frame_pacer)
  target_include_directories(test_ui_frame_pacer PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
endif()

# The stage-2 acceptance test: gui + its tests with NO Vulkan or GLFW on
# the link line. Links the gui archive (ws::ui_gui; its ws::input and
# ws::jobs sides are core-only and pure CPU, so the cut stays
# renderer-free), the REAL
# pure-CPU font bake (src/text/font.cpp + its stb implementation TU -
# neither touches a GPU) and a stub standing in for the r2d free functions
# the gui draws through (tests/ui_gui_r2d_stub.cpp records every call, so
# the cases assert the gui really drew). If the gui ever grows a renderer-
# or platform-side link dependency, this executable stops linking - the
# acceptance fails loudly, not silently.
ws_add_test(ui_gui
  SOURCES tests/test_ui_gui.cpp
          tests/ui_gui_r2d_stub.cpp
          src/text/font.cpp
          src/text/stb_impl.cpp
  DEPENDS stb)
if(TARGET test_ui_gui)
  # "text/font.h" from font.cpp + "ui_gui_stub.hpp" from the test pair.
  target_include_directories(test_ui_gui PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
endif()

# The text-editing engine suite: the word/line walks, the undo/redo
# history, the single-line field's extended keyboard (Ctrl+arrows,
# Ctrl+Backspace/Delete, Ctrl+Z/Y, Up/Down as Home/End) and the
# multi-line editor's vertical half (Enter, the goal column, the
# click placement, the wheel/follow interplay) - the same purity
# class as test_ui_gui (the gui archive, the r2d stub, the real font
# bake; no renderer on the link line).
ws_add_test(ui_text_edit
  SOURCES tests/test_ui_text_edit.cpp
          tests/ui_gui_r2d_stub.cpp
          src/text/font.cpp
          src/text/stb_impl.cpp
  LINK ws::ui_gui
  DEPENDS stb)
if(TARGET test_ui_text_edit)
  target_include_directories(test_ui_text_edit PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
endif()

# The stage-14 canvas suite: the pure tessellation half (stroke/fill/
# flatten/dash) over the same gui archive + r2d stub. Same purity class
# as test_ui_gui - no Vulkan or GLFW on the link line. The canvas
# draws through the TessSink seam (a pure virtual the r2d stub
# satisfies), so the test is headless.
ws_add_test(ui_canvas
  SOURCES tests/test_ui_canvas.cpp
          tests/ui_gui_r2d_stub.cpp
          src/text/font.cpp
          src/text/stb_impl.cpp
  LINK ws::ui_gui
  DEPENDS stb)
if(TARGET test_ui_canvas)
  target_include_directories(test_ui_canvas PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
endif()

# The stage-16 grid suite: the x5 level ladder, the no-pop fade
# contract, the index math at fractional centers/zooms, the mark cap
# and the pixel-snapped draw - the gui archive + the r2d stub, the
# same purity class as test_ui_canvas.
ws_add_test(ui_grid
  SOURCES tests/test_ui_grid.cpp
          tests/ui_gui_r2d_stub.cpp
          src/text/font.cpp
          src/text/stb_impl.cpp
  LINK ws::ui_gui
  DEPENDS stb)
if(TARGET test_ui_grid)
  target_include_directories(test_ui_grid PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
endif()

# The stage-15 shell suite: the dock host, the panel framework, the
# document layer and AppShell itself, headless over the same gui
# archive + r2d stub. The shell's platform services (recent files,
# autosave, title) ride ws::platform's headless halves - the fake
# dialogs and fake boxes answer the injected interfaces, and the
# FileSystem seam is the test's own in-memory fake, so no OS half
# ever links here.
ws_add_test(ui_shell
  SOURCES tests/test_ui_shell.cpp
          tests/ui_gui_r2d_stub.cpp
          src/text/font.cpp
          src/text/stb_impl.cpp
  LINK ws::ui_gui
  DEPENDS stb)
if(TARGET test_ui_shell)
  target_include_directories(test_ui_shell PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
endif()

# The P0 split-draw acceptance (the ui-skin plan): every look half
# lifted out of the composed widgets, driven standalone and through the
# composed calls - same purity class as test_ui_gui (the gui archive,
# the r2d stub, the real font bake; no renderer on the link line).
ws_add_test(ui_gui_splits
  SOURCES tests/test_ui_gui_splits.cpp
          tests/ui_gui_r2d_stub.cpp
          src/text/font.cpp
          src/text/stb_impl.cpp
  LINK ws::ui_gui
  DEPENDS stb)
if(TARGET test_ui_gui_splits)
  target_include_directories(test_ui_gui_splits PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
endif()

# The P1 font-bake quality suite (the ui-skin plan): the pure-CPU bake
# + the embedded Inter arrays, nothing else on the link line - no gui
# archive, no renderer, no window (the same purity class the font half
# of test_ui_gui set).
ws_add_test(ui_font
  SOURCES tests/test_ui_font.cpp
          src/text/font.cpp
          src/text/stb_impl.cpp
          src/text/default_font.cpp
          src/text/default_font_regular.cpp
          src/text/default_font_semibold.cpp
          src/text/default_font_mono.cpp
  LINK ws::core
  DEPENDS stb)
if(TARGET test_ui_font)
  # ws::core's link carries core's includes only; the ui include is
  # local to this test (font.h reaches the public renderer2d.hpp).
  target_include_directories(test_ui_font PRIVATE
    "${CMAKE_CURRENT_SOURCE_DIR}/include"
    "${CMAKE_CURRENT_SOURCE_DIR}/src")
endif()

# The P2 token-pass suite (the ui-skin plan): the theme data, its
# contrast math and its json persistence - the gui archive's value
# types, no widgets, the r2d stub only for the theme's font borrow.
ws_add_test(ui_theme_tokens
  SOURCES tests/test_ui_theme_tokens.cpp
          tests/ui_gui_r2d_stub.cpp
          src/text/font.cpp
          src/text/stb_impl.cpp
  LINK ws::ui_gui
  DEPENDS stb)
if(TARGET test_ui_theme_tokens)
  target_include_directories(test_ui_theme_tokens PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
endif()

# The P3 painters-seam suite (the ui-skin plan): the routing fold, the
# stock fallbacks and the painter-blind behaviors - the gui archive +
# the r2d stub, like test_ui_gui.
ws_add_test(ui_painters
  SOURCES tests/test_ui_painters.cpp
          tests/ui_gui_r2d_stub.cpp
          src/text/font.cpp
          src/text/stb_impl.cpp
  LINK ws::ui_gui
  DEPENDS stb)
if(TARGET test_ui_painters)
  target_include_directories(test_ui_painters PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
endif()

# The P4 motion suite (the ui-skin plan): the one helper, the four
# travelers and the tint bracket - the gui archive + the r2d stub.
ws_add_test(ui_motion
  SOURCES tests/test_ui_motion.cpp
          tests/ui_gui_r2d_stub.cpp
          src/text/font.cpp
          src/text/stb_impl.cpp
  LINK ws::ui_gui
  DEPENDS stb)
if(TARGET test_ui_motion)
  target_include_directories(test_ui_motion PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
endif()

# The P5 primitives suite (the ui-skin plan): the layered outline/shadow
# pair and the stock adoption - the gui archive + the r2d stub, like
# test_ui_gui. widget_detail.hpp's helpers (shadow_bounds, the pill
# fold) are internal, so the src/ include rides too.
ws_add_test(ui_primitives
  SOURCES tests/test_ui_primitives.cpp
          tests/ui_gui_r2d_stub.cpp
          src/text/font.cpp
          src/text/stb_impl.cpp
  LINK ws::ui_gui
  DEPENDS stb)
if(TARGET test_ui_primitives)
  target_include_directories(test_ui_primitives PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
endif()

# The P6 variants suite (the ui-skin plan): the icon set (raster,
# mapping, override), the button variants' token-resolved faces and the
# snap helpers - the gui archive + the r2d stub, like test_ui_gui; the
# icon raster and the detail helpers ride src/.
ws_add_test(ui_variants
  SOURCES tests/test_ui_variants.cpp
          tests/ui_gui_r2d_stub.cpp
          src/text/font.cpp
          src/text/stb_impl.cpp
  LINK ws::ui_gui
  DEPENDS stb)
if(TARGET test_ui_variants)
  target_include_directories(test_ui_variants PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
endif()

# The tap-defect suite (the M7 leftover): the click floor - a same-frame
# tap clicks one widget per stratum, cascades strictly upward only, and
# the reuse frame's new contact is exempt. The gui archive + the r2d
# stub, the same purity class as test_ui_gui.
ws_add_test(ui_tap
  SOURCES tests/test_ui_tap.cpp
          tests/ui_gui_r2d_stub.cpp
          src/text/font.cpp
          src/text/stb_impl.cpp
  LINK ws::ui_gui
  DEPENDS stb)
if(TARGET test_ui_tap)
  target_include_directories(test_ui_tap PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
endif()

# The key-repeat suite: the OS auto-repeat edge (key_repeated) through
# the policy read (key_pressed_or_repeated) and the widgets that honor
# it (the text field's deleters and caret keys, the slider's arrows,
# the table's row walk) plus the ones that stay edge-only (activation,
# Home/End) - the gui archive + the r2d stub, the same purity class as
# test_ui_gui.
ws_add_test(ui_key_repeat
  SOURCES tests/test_ui_key_repeat.cpp
          tests/ui_gui_r2d_stub.cpp
          src/text/font.cpp
          src/text/stb_impl.cpp
  LINK ws::ui_gui
  DEPENDS stb)
if(TARGET test_ui_key_repeat)
  target_include_directories(test_ui_key_repeat PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
endif()

# The plot suite: the waveform widget end to end - the pure axis math
# (ticks, engineering notation, the view invariants) gated directly,
# and the widget driven through hand-built frames (the wheel zoom
# against the claim's one-frame settle, the rubber band, the axis
# strip drags, the pan, the double-click reset, the right-click
# cancel) with the draws asserted through the r2d stub's counters -
# the gui archive + the real font bake, the same purity class as
# test_ui_gui.
ws_add_test(ui_plot
  SOURCES tests/test_ui_plot.cpp
          tests/ui_gui_r2d_stub.cpp
          src/text/font.cpp
          src/text/stb_impl.cpp
  LINK ws::ui_gui
  DEPENDS stb)
if(TARGET test_ui_plot)
  target_include_directories(test_ui_plot PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
endif()

# The numeric input suite: the exact-value field end to end - the pure
# parse/format pair gated directly (the refusals with their own codes),
# and the widget driven through hand-built frames (the arrival's
# select-all against a press's caret placement, the typing through the
# numeric charset, Enter's consumed commit, the blur's silent one,
# Escape's abandoned edit, the stepping arrows under the OS
# auto-repeat, the clamps) plus the property grid's own row - the gui
# archive + the real font bake, the same purity class as test_ui_gui.
ws_add_test(ui_num_input
  SOURCES tests/test_ui_num_input.cpp
          tests/ui_gui_r2d_stub.cpp
          src/text/font.cpp
          src/text/stb_impl.cpp
  LINK ws::ui_gui
  DEPENDS stb)
if(TARGET test_ui_num_input)
  target_include_directories(test_ui_num_input PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
endif()

# The table virtualization suite: the virtualized walk, end to end -
# the visible window over the hit clip (the seam the scroll panels
# push, read through current_hit_clip), the sentinel rows at each
# end, the chrome path culling identically, the honest limits the
# contract spells (Tab wraps within the window; the arrows rest on a
# row the walk cannot see), and the REAL scroll panel driven through
# its reserved ScrollState key - the gui archive + the real font
# bake, the same purity class as test_ui_gui.
ws_add_test(ui_table_clip
  SOURCES tests/test_ui_table_clip.cpp
          tests/ui_gui_r2d_stub.cpp
          src/text/font.cpp
          src/text/stb_impl.cpp
  LINK ws::ui_gui
  DEPENDS stb)
if(TARGET test_ui_table_clip)
  target_include_directories(test_ui_table_clip PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
endif()

# --- Shader workflow targets (opt-in; the default build is unchanged) ------
# The committed spirv.h stays the build input (no shader compiler needed);
# these targets make staleness visible and regeneration explicit. The flags
# and the header format live ONLY in tools/compile_shaders.ps1 - the CMake
# side passes paths and reads the exit code, nothing more.
if(NOT ANDROID AND WIN32)
  set(WS_GLSLANG_EXE "" CACHE FILEPATH
      "Optional explicit shader compiler for ws_ui_check/regen_shaders")
  option(WS_UI_REGEN_SHADERS
         "Fold ws_ui_check_shaders into the build (fail the build on a stale spirv.h)"
         OFF)

  find_program(WS_POWERSHELL_EXE powershell)
  if(WS_POWERSHELL_EXE)
    set(_shaders_script "${CMAKE_CURRENT_SOURCE_DIR}/../../tools/compile_shaders.ps1")

    set(_regen_args -NoProfile -ExecutionPolicy Bypass -File ${_shaders_script})
    if(WS_GLSLANG_EXE)
      list(APPEND _regen_args -Compiler ${WS_GLSLANG_EXE})
    endif()
    # Regenerates the committed header in place. Not in ALL on purpose: a
    # build must never rewrite a source-controlled file unprompted.
    add_custom_target(ws_ui_regen_shaders
      COMMAND ${WS_POWERSHELL_EXE} ${_regen_args}
      VERBATIM)

    # -AllowMissingCompiler: a machine with no glslang anywhere must never
    # fail the build over a target it cannot run - SKIPPED and green.
    set(_check_args -NoProfile -ExecutionPolicy Bypass -File ${_shaders_script}
                    -Check -AllowMissingCompiler)
    if(WS_GLSLANG_EXE)
      list(APPEND _check_args -Compiler ${WS_GLSLANG_EXE})
    endif()
    add_custom_target(ws_ui_check_shaders
      COMMAND ${WS_POWERSHELL_EXE} ${_check_args}
      VERBATIM)

    if(WS_UI_REGEN_SHADERS)
      add_dependencies(ws_ui ws_ui_check_shaders)
    endif()
  endif()
endif()

# Dev-only shader hot reload: an internal provider recompiles the GLSL at
# frame boundaries (see src/render/shader_provider.*). Declared unconditionally
# so an ON value is CHECKED on every platform (Android and Release both
# refuse it at configure time); the define is desktop-debug-only. Default
# OFF - the default build keeps rendering from the committed spirv.h and
# contains no process-spawning code at all.
option(WS_UI_DEV_SHADER_RELOAD
       "ws::ui dev-only: hot-reload batch.vert/.frag at runtime (debug, desktop)"
       OFF)
if(WS_UI_DEV_SHADER_RELOAD)
  if(ANDROID)
    message(FATAL_ERROR
      "WS_UI_DEV_SHADER_RELOAD is desktop-only (it shells out to glslang at runtime).")
  endif()
  # Single-config Ninja presets: CMAKE_BUILD_TYPE IS the config. The
  # hot-reload path shells out per change and waits the device idle to
  # rebake - dev iteration only, never a Release behavior.
  if(NOT CMAKE_BUILD_TYPE STREQUAL "Debug")
    message(FATAL_ERROR
      "WS_UI_DEV_SHADER_RELOAD requires a Debug build (CMAKE_BUILD_TYPE=Debug).")
  endif()
  target_compile_definitions(ws_ui PRIVATE WS_UI_DEV_SHADER_RELOAD)
endif()
