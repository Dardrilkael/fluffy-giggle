// No DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN here - test_common.cpp owns doctest's
// main (one binary, several TUs).
//
// The Box2D CONTRACT suite: engine BEHAVIOR through the public API. Gravity
// and drift, bounce, stacking + sleep, per-tick force clearing (Box2D
// integrates an applied force across a step's internal substeps and clears
// it once per step - verified against src/solver.c), contact events (pair
// order, normal direction, the per-CALL union across an advance()'s
// substeps, hit events), joints (weld, distance hold, revolute motor +
// limits, the body-destroy cascade), raycast/overlap results,
// moved_bodies()/prev_transforms() semantics, the replay determinism
// contract, and the zero-allocation steady state. The backend-independent
// machinery is pinned in test_world_2d.cpp.
//
// The bottom of this file replaces global operator new/delete for the
// whole test binary: the zero-allocation case counts every C++
// allocation in the process. That measures THIS wrapper - Box2D's own C
// heap (its arena/block allocator) is engine-internal by design.

#include <doctest/doctest.h>

#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <utility>
#include <vector>

#if defined(_MSC_VER)
#include <malloc.h>
#endif

#include <new>

#include "check.hpp"

#include <ws/math/vecmath.hpp>
#include <ws/physics/2d/joint.hpp>
#include <ws/physics/2d/world.hpp>

using ws::physics::PhysicsError;
using ws::physics2d::Aabb;
using ws::physics2d::BodyDesc;
using ws::physics2d::BodyId;
using ws::physics2d::BodyMove;
using ws::physics2d::Box;
using ws::physics2d::Capsule;
using ws::physics2d::Circle;
using ws::physics2d::ContactPhase;
using ws::physics2d::DistanceJoint;
using ws::physics2d::FixedJoint;
using ws::physics2d::Part;
using ws::physics2d::RayHit;
using ws::physics2d::RevoluteJoint;
using ws::physics2d::Transform;
using ws::physics2d::World2D;
using wsphys::test::has_code;

namespace {

constexpr float kDt = 1.0f / 60.0f;

[[nodiscard]] World2D make_world(World2D::Desc desc = {}) {
  auto world = World2D::create(desc);
  REQUIRE(world.has_value());
  return std::move(*world);
}

// A 1 m^2 dynamic box (density 1 -> mass 1 kg, I = 1/6 kg*m^2): the exact
// numbers the force/torque case below depends on.
[[nodiscard]] BodyDesc dynamic_box(ws::math::Vec2 position) {
  BodyDesc d{};
  d.shape = Box{ws::math::Vec2{0.5f, 0.5f}};
  d.transform = Transform{position, 0.0f};
  return d;
}

[[nodiscard]] BodyDesc static_box(ws::math::Vec2 position,
                                  ws::math::Vec2 half) {
  BodyDesc d{};
  d.kind = ws::physics::BodyKind::static_;
  d.shape = Box{half};
  d.transform = Transform{position, 0.0f};
  return d;
}

[[nodiscard]] BodyDesc ball_at(ws::math::Vec2 position, float restitution) {
  BodyDesc d{};
  d.shape = Circle{0.5f};
  d.transform = Transform{position, 0.0f};
  d.restitution = restitution;
  return d;
}

void step_n(World2D& world, int n) {
  for (int i = 0; i < n; ++i) {
    REQUIRE(world.step().has_value());
  }
}

// The shared setup of the touching-table cases: two dynamic boxes stacked
// on the floor (the same deliberate 0.75/1.75 gaps as the stack case -
// both really fall, slam, settle), waited to full sleep.
[[nodiscard]] bool both_asleep(World2D& world, BodyId lower, BodyId upper) {
  for (int i = 0; i < 300; ++i) {
    REQUIRE(world.step().has_value());
    auto l = world.is_sleeping(lower);
    auto u = world.is_sleeping(upper);
    REQUIRE(l.has_value());
    REQUIRE(u.has_value());
    if (*l && *u) {
      return true;
    }
  }
  return false;
}

}  // namespace

TEST_CASE("gravity accelerates straight down; x stays put") {
  auto world = make_world();  // the default pool: real threaded stepping
  auto id = world.create_body(dynamic_box({0.0f, 10.0f}));
  REQUIRE(id.has_value());

  step_n(world, 60);  // one second of free fall

  auto state = world.body_state(*id);
  REQUIRE(state.has_value());
  CHECK(std::abs(state->position.x) < 0.01f);
  CHECK(state->position.y < 8.0f);   // fell
  CHECK(state->position.y > 3.0f);   // ~5.1 m expected after 1 s from rest
  CHECK(state->linear_velocity.y == doctest::Approx(-9.81f).epsilon(0.02));
  CHECK(std::abs(state->linear_velocity.x) < 0.01f);
}

TEST_CASE("a zero-gravity world preserves inertial drift exactly") {
  auto world = make_world(World2D::Desc{.gravity = {0.0f, 0.0f},
                                         .thread_count = 0});
  auto id = world.create_body(dynamic_box({0.0f, 0.0f}));
  REQUIRE(id.has_value());
  REQUIRE(world.set_velocity(*id, {2.0f, 1.0f}, 0.0f).has_value());

  step_n(world, 60);

  auto state = world.body_state(*id);
  REQUIRE(state.has_value());
  CHECK(state->position.x == doctest::Approx(2.0f).epsilon(0.001));
  CHECK(state->position.y == doctest::Approx(1.0f).epsilon(0.001));
  CHECK(state->linear_velocity.x == doctest::Approx(2.0f).epsilon(0.001));
  CHECK(state->linear_velocity.y == doctest::Approx(1.0f).epsilon(0.001));
}

TEST_CASE("restitution 1 bounces: the impact flips the velocity sign") {
  auto world = make_world(World2D::Desc{.thread_count = 0});
  auto floor = world.create_body(static_box({0.0f, -1.0f}, {50.0f, 1.0f}));
  REQUIRE(floor.has_value());
  auto ball = world.create_body(ball_at({0.0f, 5.0f}, 1.0f));
  REQUIRE(ball.has_value());

  bool bounced = false;
  bool began = false;
  for (int i = 0; i < 240; ++i) {  // 4 s
    REQUIRE(world.step().has_value());
    for (const auto& e : world.contact_events()) {
      CHECK(e.a.index < e.b.index);  // the pair-order invariant, every event
      began = true;
    }
    auto state = world.body_state(*ball);
    REQUIRE(state.has_value());
    if (state->linear_velocity.y > 0.5f) {
      bounced = true;  // moving up after a downward drop: it bounced
    }
  }
  CHECK(began);
  CHECK(bounced);
}

TEST_CASE("multi-shape parts: per-part materials ride the shapes natively") {
  // The compound floor helper: a static body whose two parts sit side by
  // side along x with DIFFERENT surface materials. The body-level material
  // is deliberately wrong for both (defaults) - part_count != 0 must IGNORE
  // it entirely (Box2D mixes per shape pair from the per-part b2ShapeDef
  // materials; there are no adapter tables to keep honest here).
  const auto compound_floor = [](ws::math::Vec2 half, float left_friction,
                                 float left_rest, float right_friction,
                                 float right_rest) {
    BodyDesc f{};
    f.kind = ws::physics::BodyKind::static_;
    f.transform = Transform{{0.0f, -1.0f}, 0.0f};
    f.parts[0] = Part{Box{half}, ws::math::Vec2{-half.x, 0.0f}, left_friction,
                      left_rest};
    f.parts[1] = Part{Box{half}, ws::math::Vec2{half.x, 0.0f}, right_friction,
                      right_rest};
    f.part_count = 2;
    return f;
  };

  SUBCASE("per-part restitution beats the ignored body-level value") {
    auto world = make_world(World2D::Desc{.thread_count = 0});
    auto floor = world.create_body(compound_floor(
        ws::math::Vec2{1.5f, 1.0f}, 0.2f, 0.0f, 0.2f, 1.0f));
    REQUIRE(floor.has_value());
    // Box2D mixes restitution with max(): a rest-0 ball on the rest-1 part
    // bounces while the same ball on the rest-0 part just stops.
    auto dead = world.create_body(ball_at({-1.5f, 5.0f}, 0.0f));
    auto live = world.create_body(ball_at({1.5f, 5.0f}, 0.0f));
    REQUIRE(dead.has_value());
    REQUIRE(live.has_value());

    float dead_apex = 0.0f;
    float live_apex = 0.0f;
    for (int i = 0; i < 90; ++i) {  // 1.5 s: fall, hit, bounce back up
      REQUIRE(world.step().has_value());
      // The drop from y=5 takes ~0.96 s (58 steps) - apex sampling starts
      // after landing, so the checks measure the BOUNCE, not the fall.
      if (i < 60) {
        continue;
      }
      auto d = world.body_state(*dead);
      auto l = world.body_state(*live);
      REQUIRE(d.has_value());
      REQUIRE(l.has_value());
      dead_apex = std::max(dead_apex, d->position.y);
      live_apex = std::max(live_apex, l->position.y);
    }
    CHECK(dead_apex < 1.5f);  // never meaningfully bounced (rests at ~0.5)
    CHECK(live_apex > 3.0f);  // back near the 5.0 drop height
  }

  SUBCASE("per-part friction beats the ignored body-level value") {
    auto world = make_world(World2D::Desc{.thread_count = 0});
    // Wide parts so each box slides over its own side for the whole second.
    auto floor = world.create_body(compound_floor(
        ws::math::Vec2{10.0f, 1.0f}, 1.0f, 0.0f, 0.0f, 0.0f));
    REQUIRE(floor.has_value());
    // Boxes start AT REST on the part surface (floor top is y=0, box half
    // 0.5), so the whole second is pure sliding - no fall eating into it.
    auto rough = world.create_body(dynamic_box({-15.0f, 0.5f}));
    auto ice = world.create_body(dynamic_box({5.0f, 0.5f}));
    REQUIRE(rough.has_value());
    REQUIRE(ice.has_value());
    REQUIRE(world.set_velocity(*rough, {3.0f, 0.0f}, 0.0f).has_value());
    REQUIRE(world.set_velocity(*ice, {3.0f, 0.0f}, 0.0f).has_value());

    step_n(world, 60);  // 1 s of sliding
    auto r = world.body_state(*rough);
    auto i = world.body_state(*ice);
    REQUIRE(r.has_value());
    REQUIRE(i.has_value());
    // Box2D mixes friction with sqrt(f1*f2): box 0.2 * part 1.0 -> 0.45
    // decelerates hard; box 0.2 * part 0.0 -> 0 keeps gliding.
    CHECK(i->linear_velocity.x > 2.9f);   // ice: barely slowed
    CHECK(r->linear_velocity.x < 0.5f);  // rough: friction ate most of it
  }
}

TEST_CASE("multi-shape parts: geometry rides the body-local offset") {
  auto world = make_world(World2D::Desc{.thread_count = 0});
  // A static body at the origin carrying ONE part translated to (3, 0):
  // the shape exists only there - the body origin itself is empty space.
  BodyDesc offset_body{};
  offset_body.kind = ws::physics::BodyKind::static_;
  offset_body.parts[0] = Part{Box{ws::math::Vec2{1.0f, 1.0f}},
                               ws::math::Vec2{3.0f, 0.0f}, 0.2f, 0.0f};
  offset_body.part_count = 1;
  auto shelf = world.create_body(offset_body);
  REQUIRE(shelf.has_value());

  auto on_shelf = world.create_body(ball_at({3.0f, 5.0f}, 0.0f));
  auto through = world.create_body(ball_at({0.0f, 5.0f}, 0.0f));
  REQUIRE(on_shelf.has_value());
  REQUIRE(through.has_value());

  step_n(world, 90);  // 1.5 s: plenty to land (and to fall far past)

  auto landed = world.body_state(*on_shelf);
  auto fell = world.body_state(*through);
  REQUIRE(landed.has_value());
  REQUIRE(fell.has_value());
  // Shelf top is y=1 (origin + half 1), ball radius 0.5 -> rests at 1.5.
  CHECK(landed->position.y == doctest::Approx(1.5f).epsilon(0.05));
  CHECK(landed->position.x == doctest::Approx(3.0f).epsilon(0.05));
  // No shape at the origin: free fall from y=5 over 1.5 s reaches ~-6.
  CHECK(fell->position.y < -5.0f);
}

TEST_CASE("two part-pairs of one body pair begin and end independently") {
  // The touching table keys on the full SHAPE pair (world_core.hpp), so a
  // second part's began must never read as a duplicate of the first, and
  // each part-pair ends on its own. Zero gravity keeps the geometry
  // deterministic: a static two-pillar base (different heights) and a
  // dynamic two-footed body, with the feet staged to touch two ticks
  // apart. Only began events carry a witness point, so the part pairs are
  // told apart by where their began points sit (x ~ 0 vs x ~ 2); ended is
  // pinned by COUNT: both part-pairs must end, each exactly once.
  auto world = make_world(World2D::Desc{.gravity = {0.0f, 0.0f},
                                        .thread_count = 0});
  BodyDesc base{};
  base.kind = ws::physics::BodyKind::static_;
  base.transform = Transform{ws::math::Vec2{0.0f, 0.0f}, 0.0f};
  base.parts[0] = Part{Box{ws::math::Vec2{0.5f, 0.5f}},
                       ws::math::Vec2{0.0f, 0.5f}, 0.2f, 0.0f};   // top y = 1.0
  base.parts[1] = Part{Box{ws::math::Vec2{0.5f, 0.25f}},
                       ws::math::Vec2{2.0f, 0.25f}, 0.2f, 0.0f};  // top y = 0.5
  base.part_count = 2;
  auto base_id = world.create_body(base);
  REQUIRE(base_id.has_value());

  BodyDesc bridge{};
  bridge.transform = Transform{ws::math::Vec2{0.0f, 1.05f}, 0.0f};
  bridge.parts[0] = Part{Box{ws::math::Vec2{0.25f, 0.25f}},
                         ws::math::Vec2{0.0f, 0.0f}, 0.2f, 0.0f};
  bridge.parts[1] = Part{Box{ws::math::Vec2{0.25f, 0.25f}},
                         ws::math::Vec2{2.0f, 0.0f}, 0.2f, 0.0f};
  bridge.part_count = 2;
  auto bridge_id = world.create_body(bridge);
  REQUIRE(bridge_id.has_value());

  int began_low = 0;   // began with a witness point over pillar 0
  int began_high = 0;  // began with a witness point over pillar 1
  int ended = 0;
  const auto collect = [&](int ticks) {
    for (int i = 0; i < ticks; ++i) {
      REQUIRE(world.step().has_value());
      for (const auto& e : world.contact_events()) {
        if (e.phase == ContactPhase::began) {
          // Pillar 0's contact points sit at x in [-0.25, 0.25]; pillar
          // 1's at x in [1.75, 2.25].
          (e.point.x < 1.0f ? began_low : began_high) += 1;
        } else if (e.phase == ContactPhase::ended) {
          ++ended;
        }
      }
    }
  };

  // Phase 1: foot 0 spawns 0.2 into pillar 0 (bottom 0.8 vs top 1.0) while
  // foot 1 clears pillar 1 by 0.3 - exactly one began, over pillar 0.
  collect(2);
  CHECK(began_low == 1);
  CHECK(began_high == 0);

  // Phase 2: the teleport sinks the whole body - foot 0 stays in contact
  // the entire time (no gap ever opens: no ended, no re-began), while
  // foot 1's 0.1 overlap with pillar 1 brings a SECOND began for the SAME
  // body pair. A slot-keyed table would swallow it as a duplicate.
  REQUIRE(world.set_transform(*bridge_id, ws::math::Vec2{0.0f, 0.65f}, 0.0f)
              .has_value());
  collect(2);
  CHECK(began_low == 1);   // foot 0 never re-began (never separated)
  CHECK(began_high == 1);  // the second part-pair's began survived

  // Phase 3: lift the whole body clear - both part-pairs separate, and
  // each ends exactly once. (Zero-g depenetration only rests the feet ON
  // the pillars, it never separates them, so the separation is driven by
  // the transform, not the solver.)
  REQUIRE(world.set_transform(*bridge_id, ws::math::Vec2{0.0f, 1.65f}, 0.0f)
              .has_value());
  for (int i = 0; i < 10 && ended < 2; ++i) {
    collect(1);
  }
  CHECK(ended == 2);      // one per part-pair, no more
  CHECK(began_low == 1);  // and never a duplicate began
  CHECK(began_high == 1);
}

TEST_CASE("a stack settles, sleeps and leaves moved_bodies() empty") {
  auto world = make_world(World2D::Desc{.thread_count = 0});
  auto floor = world.create_body(static_box({0.0f, -0.5f}, {50.0f, 0.5f}));
  REQUIRE(floor.has_value());
  std::vector<BodyId> boxes;
  for (int i = 0; i < 3; ++i) {
    // Deliberate gaps: the stack falls together, slams, then settles.
    auto id = world.create_body(dynamic_box({0.0f, 0.5f + 1.5f * i}));
    REQUIRE(id.has_value());
    boxes.push_back(*id);
  }

  // Falling: all three report as moved, and prev holds the earlier pose.
  step_n(world, 1);
  REQUIRE(world.moved_bodies().size() == 3);
  for (const auto& m : world.moved_bodies()) {
    const float cur = world.transforms()[m.id.index].position.y;
    const float prev = world.prev_transforms()[m.id.index].position.y;
    CHECK(cur < prev);
  }
  CHECK(world.prev_transforms().size() == world.transforms().size());

  step_n(world, 300);  // five seconds: slam, wobble, settle, sleep

  for (std::size_t i = 0; i < boxes.size(); ++i) {
    auto state = world.body_state(boxes[i]);
    REQUIRE(state.has_value());
    CHECK(std::abs(state->linear_velocity.x) < 0.05f);
    CHECK(std::abs(state->linear_velocity.y) < 0.05f);
    CHECK(std::abs(state->angular_velocity) < 0.05f);
    // Rest heights preserved: 0.5 / 1.5 / 2.5 (+- small solver overlap).
    CHECK(std::abs(state->position.y - (0.5f + 1.0f * i)) < 0.02f);
  }

  // Asleep: nothing moved on the last call, so the sleep sync cost is
  // zero and the prev mirror equals the current one.
  CHECK(world.moved_bodies().empty());
  for (const auto& id : boxes) {
    const auto& cur = world.transforms()[id.index];
    const auto& prev = world.prev_transforms()[id.index];
    CHECK(cur.position.x == doctest::Approx(prev.position.x));
    CHECK(cur.position.y == doctest::Approx(prev.position.y));
  }

  // CONTRACT.md 7 from the quiet side: a fully-sleeping world stays
  // event-silent, and waking a still-touching pair re-reports nothing
  // (its began stands from the original contact). Box2D needs no
  // suppression to behave here - the pin keeps the lib to the same
  // contract in both engines. The wake is proven real by the moved list,
  // so the zeros are the contract, not a failed wake.
  int quiet_edges = 0;
  for (int i = 0; i < 60; ++i) {
    REQUIRE(world.step().has_value());
    if (world.moved_bodies().empty()) {
      for (const auto& e : world.contact_events()) {
        if (e.phase != ContactPhase::hit) {
          ++quiet_edges;
        }
      }
    }
  }
  CHECK(quiet_edges == 0);

  REQUIRE(world.set_velocity(boxes[0], {0.01f, 0.0f}, 0.0f).has_value());
  bool wake_moved = false;
  int wake_edges = 0;
  for (int i = 0; i < 3; ++i) {
    REQUIRE(world.step().has_value());
    wake_moved = wake_moved || !world.moved_bodies().empty();
    for (const auto& e : world.contact_events()) {
      if (e.phase != ContactPhase::hit) {
        ++wake_edges;
      }
    }
  }
  CHECK(wake_moved);
  CHECK(wake_edges == 0);
}

TEST_CASE("a sleeping pair's real separation still reports ended") {
  // The freeze path of the touching table, Box2D side: the separation's
  // `ended` arrives while the lower box is asleep, so the lib cannot trust
  // it (a sleeping side may just be the engine tidying up) - it freezes
  // the pair, and the wake movement stamps the deadline. No re-touch
  // comes, so reconcile() owes the consumer the edge itself, a couple of
  // ticks late (CONTRACT.md 7).
  auto world = make_world(World2D::Desc{.thread_count = 0});
  auto floor = world.create_body(static_box({0.0f, -0.5f}, {50.0f, 0.5f}));
  REQUIRE(floor.has_value());
  auto lower = world.create_body(dynamic_box({0.0f, 0.75f}));
  auto upper = world.create_body(dynamic_box({0.0f, 1.75f}));
  REQUIRE(lower.has_value());
  REQUIRE(upper.has_value());
  REQUIRE(both_asleep(world, *lower, *upper));

  // The upper box teleports away - into the air, far from the stack - so
  // the pair really separates while the lower box stays asleep.
  REQUIRE(world.set_transform(*upper, {5.0f, 5.0f}, 0.0f).has_value());

  const auto names_pair = [&](const auto& e) {
    return (e.a == *lower && e.b == *upper) || (e.a == *upper && e.b == *lower);
  };
  bool saw_ended = false;
  bool saw_other = false;
  for (int i = 0; i < 10 && !saw_ended; ++i) {
    REQUIRE(world.step().has_value());
    for (const auto& e : world.contact_events()) {
      if (!names_pair(e)) {
        continue;
      }
      if (e.phase == ContactPhase::ended) {
        saw_ended = true;
      } else {
        saw_other = true;  // nothing re-touched: no began/hit for this pair
      }
    }
  }
  CHECK(saw_ended);        // the lib delivered the frozen pair's edge
  CHECK_FALSE(saw_other);
  // (Box2D also wakes the sleeping neighbor when its contact is destroyed
  // - engine freedom, CONTRACT.md 7 does not own wake-on-separation - so
  // unlike the 3D twin, the lower box need not still be asleep here.)
}

TEST_CASE("destroying a touching body is silent; the reused slot "
          "re-begins cleanly") {
  auto world = make_world(World2D::Desc{.thread_count = 0});
  auto floor = world.create_body(static_box({0.0f, -0.5f}, {50.0f, 0.5f}));
  REQUIRE(floor.has_value());
  // The two-box stack of the freeze case, settled to sleep: the
  // upper->lower pair is in the table when its owner dies.
  auto lower = world.create_body(dynamic_box({0.0f, 0.75f}));
  auto upper = world.create_body(dynamic_box({0.0f, 1.75f}));
  REQUIRE(lower.has_value());
  REQUIRE(upper.has_value());
  REQUIRE(both_asleep(world, *lower, *upper));

  REQUIRE(world.destroy_body(*upper).has_value());

  // Silence (CONTRACT.md 7: destroying a body never reports its pairs):
  // the engine's stale-shape removals resolve to dead shapes and drop,
  // and the table purged the pair - no edge names the dead slot in the
  // quiet ticks that follow.
  for (int i = 0; i < 5; ++i) {
    REQUIRE(world.step().has_value());
    for (const auto& e : world.contact_events()) {
      CHECK_FALSE(e.a == *upper);
      CHECK_FALSE(e.b == *upper);
    }
  }

  // Slot reuse: the freed slot is the only one, so the next body lands in
  // it - same index, bumped generation. Dropped onto the survivor, it
  // must begin EXACTLY once: the dead pair's stale key may neither
  // suppress the new contact nor duplicate it.
  auto reuser = world.create_body(dynamic_box({0.0f, 1.75f}));
  REQUIRE(reuser.has_value());
  CHECK(reuser->index == upper->index);
  CHECK_FALSE(*reuser == *upper);  // generation moved on: the stale id is dead

  int began = 0;
  for (int i = 0; i < 120; ++i) {  // 2 s: fall, land, settle, sleep
    REQUIRE(world.step().has_value());
    for (const auto& e : world.contact_events()) {
      if (e.phase == ContactPhase::began &&
          (e.a == *reuser || e.b == *reuser)) {
        ++began;
      }
    }
  }
  CHECK(began == 1);
}

TEST_CASE("forces accumulate within a tick and clear at its end") {
  auto world = make_world(World2D::Desc{.gravity = {0.0f, 0.0f},
                                         .thread_count = 0});
  auto id = world.create_body(dynamic_box({0.0f, 0.0f}));
  REQUIRE(id.has_value());

  // One tick of F = 10 N on 1 kg: dv = F/m * dt = 1/6 m/s.
  REQUIRE(world.apply_force(*id, {10.0f, 0.0f}).has_value());
  step_n(world, 1);
  auto state = world.body_state(*id);
  REQUIRE(state.has_value());
  CHECK(std::abs(state->linear_velocity.x - 10.0f * kDt) < 1e-3f);

  // No force this tick: the velocity coasts unchanged - it did not persist.
  step_n(world, 1);
  state = world.body_state(*id);
  REQUIRE(state.has_value());
  CHECK(std::abs(state->linear_velocity.x - 10.0f * kDt) < 1e-3f);

  // Two applies before one tick accumulate: dv doubles on top of that.
  REQUIRE(world.apply_force(*id, {10.0f, 0.0f}).has_value());
  REQUIRE(world.apply_force(*id, {10.0f, 0.0f}).has_value());
  step_n(world, 1);
  state = world.body_state(*id);
  REQUIRE(state.has_value());
  CHECK(std::abs(state->linear_velocity.x - 3.0f * 10.0f * kDt) < 1e-3f);

  // Torque behaves identically: dw = tau/I * dt = 6 * dt rad/s.
  REQUIRE(world.apply_torque(*id, 1.0f).has_value());
  step_n(world, 1);
  state = world.body_state(*id);
  REQUIRE(state.has_value());
  CHECK(std::abs(state->angular_velocity - 6.0f * kDt) < 1e-3f);
  step_n(world, 1);
  state = world.body_state(*id);
  REQUIRE(state.has_value());
  CHECK(std::abs(state->angular_velocity - 6.0f * kDt) < 1e-3f);
}

TEST_CASE("mass override: F = ma and tau = I alpha on the lib numbers") {
  // C4 (CONTRACT.md 4): the lib computes mass/inertia closed-form and the
  // adapter pushes them through b2Body_SetMassData. For a single box the
  // numbers equal what Box2D would derive itself (same physics), so this
  // case proves the override round-trips without corrupting the dynamics;
  // the composite spin case below is the structural discriminator, and
  // test_mass_properties.cpp pins the formulas themselves. Box2D
  // integrates an applied force across a step's 4 substeps and clears it
  // once per step: v = a*dt*N exactly, while x picks up the substep
  // staircase x = a*dt^2*(N*(N-1)/2 + 5N/8).
  auto world = make_world(World2D::Desc{.gravity = {0.0f, 0.0f},
                                        .thread_count = 0});
  BodyDesc d{};
  d.shape = Box{ws::math::Vec2{1.0f, 1.0f}};  // rho=3: m = 12, I = 8
  d.density = 3.0f;
  d.allow_sleep = false;
  auto id = world.create_body(d);
  REQUIRE(id.has_value());

  // F = 24 N on 12 kg: a = 2 m/s^2; 60 ticks land v exactly on 2.
  for (int i = 0; i < 60; ++i) {
    REQUIRE(world.apply_force(*id, {24.0f, 0.0f}).has_value());
    REQUIRE(world.step().has_value());
  }
  auto state = world.body_state(*id);
  REQUIRE(state.has_value());
  CHECK(std::abs(state->linear_velocity.x - 2.0f) < 1e-3f);
  const float x = 2.0f * kDt * kDt * (60.0f * 59.0f / 2.0f + 37.5f);
  CHECK(std::abs(state->position.x - x) < 3e-3f);
  CHECK(std::abs(state->position.y) < 1e-3f);

  // Torque: tau = 16 on I = 8 -> alpha = 2 rad/s^2; omega lands exactly
  // on 2 (angular velocity is substep-exact the same way v is).
  for (int i = 0; i < 60; ++i) {
    REQUIRE(world.apply_torque(*id, 16.0f).has_value());
    REQUIRE(world.step().has_value());
  }
  state = world.body_state(*id);
  REQUIRE(state.has_value());
  CHECK(std::abs(state->angular_velocity - 2.0f) < 1e-3f);
}

TEST_CASE("mass override: composites sum masses and inertias") {
  // Two parts, body-level density 1: box half=(1,1) at the origin
  // (m = 4, I = 8/3) + box half=(0.5,0.5) at (2,0) (m = 1, I = 1/6).
  // Hand-derived: m = 5, com = (0.4, 0), I about the com =
  // 8/3 + 1/6 + 4*0.4^2 + 1*1.6^2. The engine applies OUR numbers
  // (SetMassData), so the dynamics read the lib's parallel-axis sum back
  // out; Box2D's own derivation would agree (same physics) - the spin
  // case is what separates the two stories.
  auto world = make_world(World2D::Desc{.gravity = {0.0f, 0.0f},
                                        .thread_count = 0});
  BodyDesc d{};
  d.allow_sleep = false;
  d.parts[0] = Part{Box{ws::math::Vec2{1.0f, 1.0f}},
                    ws::math::Vec2{0.0f, 0.0f}, 0.2f, 0.0f};
  d.parts[1] = Part{Box{ws::math::Vec2{0.5f, 0.5f}},
                    ws::math::Vec2{2.0f, 0.0f}, 0.2f, 0.0f};
  d.part_count = 2;
  auto id = world.create_body(d);
  REQUIRE(id.has_value());

  // F = 10 N on m = 5: a = 2; 60 ticks land v exactly on 2.
  for (int i = 0; i < 60; ++i) {
    REQUIRE(world.apply_force(*id, {10.0f, 0.0f}).has_value());
    REQUIRE(world.step().has_value());
  }
  auto state = world.body_state(*id);
  REQUIRE(state.has_value());
  CHECK(std::abs(state->linear_velocity.x - 2.0f) < 1e-3f);

  // Torque through the hand-derived composite inertia: tau = 2*I ->
  // alpha = 2, omega lands exactly on 2.
  const float inertia =
      8.0f / 3.0f + 1.0f / 6.0f + 4.0f * 0.4f * 0.4f + 1.0f * 1.6f * 1.6f;
  for (int i = 0; i < 60; ++i) {
    REQUIRE(world.apply_torque(*id, 2.0f * inertia).has_value());
    REQUIRE(world.step().has_value());
  }
  state = world.body_state(*id);
  REQUIRE(state.has_value());
  CHECK(std::abs(state->angular_velocity - 2.0f) < 1e-3f);
}

TEST_CASE("mass override: a composite spins about its COM, not its origin") {
  // THE structural discriminator. The composite's COM is (0.4, 0) in
  // body-local space, so a free spin (zero gravity, no forces) must keep
  // the WORLD COM fixed while the body ORIGIN orbits it:
  //   origin = com_world - R(theta) * com, with com_world = (0.4, 0).
  // Box2D rotates about bodySim->center and rebuilds the origin
  // transform as center - R*localCenter (solver.c), and localCenter is
  // OUR mass-data center. If the override were dropped, or its center
  // ignored, the origin would sit still instead of orbiting.
  auto world = make_world(World2D::Desc{.gravity = {0.0f, 0.0f},
                                        .thread_count = 0});
  BodyDesc d{};
  d.angular_velocity = 1.0f;  // constant omega: 60 ticks -> theta = 1 rad
  d.allow_sleep = false;
  d.parts[0] = Part{Box{ws::math::Vec2{1.0f, 1.0f}},
                    ws::math::Vec2{0.0f, 0.0f}, 0.2f, 0.0f};
  d.parts[1] = Part{Box{ws::math::Vec2{0.5f, 0.5f}},
                    ws::math::Vec2{2.0f, 0.0f}, 0.2f, 0.0f};
  d.part_count = 2;
  auto id = world.create_body(d);
  REQUIRE(id.has_value());

  step_n(world, 60);
  auto state = world.body_state(*id);
  REQUIRE(state.has_value());
  CHECK(std::abs(state->rotation - 1.0f) < 1e-3f);

  const float c = 0.4f;  // hand-derived mass-weighted COM (4*0 + 1*2)/5
  const float cos_t = std::cos(state->rotation);
  const float sin_t = std::sin(state->rotation);
  CHECK(std::abs(state->position.x - c * (1.0f - cos_t)) < 1e-3f);
  CHECK(std::abs(state->position.y + c * sin_t) < 1e-3f);
}

TEST_CASE("contact events: pair order fixes the normal to point a -> b") {
  const auto run = [](bool floor_first) {
    auto world = make_world(World2D::Desc{.thread_count = 0});
    const BodyDesc floor_desc = static_box({0.0f, -0.5f}, {50.0f, 0.5f});
    const BodyDesc ball_desc = ball_at({0.0f, 5.0f}, 0.0f);
    BodyId floor{};
    BodyId ball{};
    if (floor_first) {
      floor = *world.create_body(floor_desc);
      ball = *world.create_body(ball_desc);
    } else {
      ball = *world.create_body(ball_desc);
      floor = *world.create_body(floor_desc);
    }
    REQUIRE(floor.index != ball.index);

    for (int i = 0; i < 90; ++i) {
      REQUIRE(world.step().has_value());
      if (!world.contact_events().empty()) {
        break;
      }
    }
    REQUIRE_FALSE(world.contact_events().empty());
    const auto& e = world.contact_events().front();
    CHECK(e.phase == ContactPhase::began);
    CHECK(e.a.index < e.b.index);
    // The interface sits at y=0; Box2D's speculative margin can begin the
    // contact slightly BEFORE geometric touch, hence the loose bound.
    CHECK(std::abs(e.point.y) < 0.1f);
    if (floor_first) {
      CHECK(e.a == floor);  // lower slot index wins the "a" role
      CHECK(e.b == ball);
      CHECK(e.normal.y == doctest::Approx(1.0f).epsilon(0.01));  // floor -> ball
      CHECK(std::abs(e.normal.x) < 0.01f);
    } else {
      CHECK(e.a == ball);
      CHECK(e.b == floor);
      CHECK(e.normal.y == doctest::Approx(-1.0f).epsilon(0.01));  // ball -> floor
      CHECK(std::abs(e.normal.x) < 0.01f);
    }
  };
  run(true);   // floor created first: a = floor
  run(false);  // ball created first: a = ball, normal re-faced
}

TEST_CASE("a spent event budget drops hits but never began/ended edges") {
  // Budget 2, three identical falls that land the SAME tick, spaced far
  // enough apart that no ball-ball pair exists: the tick wants 3 began +
  // 3 hit events through a budget of 2. began/ended are the edges a
  // consumer builds touching-state from - a dropped `ended` leaves a
  // stuck pair forever - so ALL edges must survive a spent budget;
  // only the high-volume hit stream may be capped.
  World2D::Desc desc{};
  desc.thread_count = 0;
  desc.max_contact_events = 2;      // tiny budget: overflow is guaranteed
  desc.hit_speed_threshold = 0.5f;  // m/s: hits fire alongside the edges
  auto world = make_world(desc);
  REQUIRE(world.create_body(static_box({0.0f, -0.5f}, {50.0f, 0.5f})).has_value());
  for (const float x : {-10.0f, 0.0f, 10.0f}) {
    REQUIRE(world.create_body(ball_at({x, 5.0f}, 0.0f)).has_value());
  }

  for (int i = 0; i < 90; ++i) {
    REQUIRE(world.step().has_value());
    if (!world.contact_events().empty()) {
      break;
    }
  }
  REQUIRE_FALSE(world.contact_events().empty());

  // Which of the 3 hits survive is the backend's feed order - assert
  // only feed-order-robust facts.
  int began = 0;
  int hits = 0;
  std::vector<BodyId> began_pairs;
  for (const auto& e : world.contact_events()) {
    if (e.phase == ContactPhase::began) {
      ++began;
      began_pairs.push_back(e.b);  // normalization: a.index < b.index = floor
    } else if (e.phase == ContactPhase::hit) {
      ++hits;
    }
  }
  CHECK(began == 3);  // every edge survived the spent budget
  CHECK(hits <= 2);   // the budget still caps the hit stream
  REQUIRE(began_pairs.size() == 3);
  for (std::size_t i = 0; i < began_pairs.size(); ++i) {
    for (std::size_t j = i + 1; j < began_pairs.size(); ++j) {
      CHECK_FALSE(began_pairs[i] == began_pairs[j]);  // distinct balls
    }
  }
}

TEST_CASE("is_bullet/set_bullet: the sweep reaches dynamic targets too") {
  // Box2D sweeps EVERY fast body against static geometry on its own, so
  // the discriminator is a fast body vs a resting DYNAMIC target. The
  // start offset phases the ticks so no end pose lands in the overlap
  // window (per-tick travel 1.67 m vs a 0.4 m window, clearance 0.57 m
  // on both sides - far past the 0.02 m speculative distance): the
  // discrete path never even pairs them and walks through; the bullet's
  // mid-tick sweep finds the crossing.
  const auto run = [](bool bullet, bool via_runtime) {
    auto world = make_world(World2D::Desc{.gravity = {0.0f, 0.0f},
                                         .thread_count = 0});
    // Resting dynamic target: a thin tall box at x=20 (spans 19.9..20.1).
    BodyDesc target = dynamic_box({20.0f, 0.0f});
    target.shape = Box{ws::math::Vec2{0.1f, 2.0f}};
    auto tid = world.create_body(target);
    REQUIRE(tid.has_value());
    BodyDesc d = dynamic_box({0.767f, 0.0f});
    d.shape = Circle{0.1f};
    d.linear_velocity = {100.0f, 0.0f};
    if (!via_runtime) {
      d.is_bullet = bullet;
    }
    auto id = world.create_body(d);
    REQUIRE(id.has_value());
    if (via_runtime) {
      REQUIRE(world.set_bullet(*id, bullet).has_value());
    }
    step_n(world, 30);  // half a second: 50 m of clear-track travel
    auto state = world.body_state(*id);
    REQUIRE(state.has_value());
    auto tstate = world.body_state(*tid);
    REQUIRE(tstate.has_value());
    // Relative position: robust to the caught pair coasting together.
    return state->position.x - tstate->position.x;
  };
  // Discrete tunneled: the ball ends 30 m AHEAD of the untouched target.
  CHECK(run(false, false) > 5.0f);
  CHECK(run(false, true) > 5.0f);
  // Bullet caught it mid-flight: the ball never passed what it hit, and
  // the pair coasts together after the e = 0 impact, difference ~-0.2.
  CHECK(run(true, false) < 0.0f);
  CHECK(run(true, true) < 0.0f);
}

TEST_CASE("advance() unions contact events across its substeps") {
  World2D::Desc desc{};
  desc.thread_count = 0;
  desc.hit_speed_threshold = 1.0f;  // m/s: enables hit events
  desc.max_substeps = 128;
  auto world = make_world(desc);
  auto floor = world.create_body(static_box({0.0f, -0.5f}, {50.0f, 0.5f}));
  REQUIRE(floor.has_value());
  auto ball = world.create_body(ball_at({0.0f, 5.0f}, 0.0f));
  REQUIRE(ball.has_value());

  // 1.5 s in ONE advance() call: ~89 ticks. The impact lands mid-call
  // (t = 0.96 s); its events MUST survive to the call's end.
  REQUIRE(world.advance(1.5f).has_value());
  bool saw_began = false;
  bool saw_hit = false;
  for (const auto& e : world.contact_events()) {
    REQUIRE(e.a.index < e.b.index);
    if (e.phase == ContactPhase::began) {
      saw_began = true;
    }
    if (e.phase == ContactPhase::hit) {
      saw_hit = true;
      CHECK(e.speed > 1.0f);  // the world's threshold
      // Free fall over 4.5 m: sqrt(2 * 9.81 * 4.5) = 9.4 m/s.
      CHECK(e.speed == doctest::Approx(9.4f).epsilon(0.1));
    }
  }
  CHECK(saw_began);
  CHECK(saw_hit);

  // Resting: began fires once per overlap (no repeat) and the impact is
  // over, so a plain one-tick call reports neither.
  REQUIRE(world.advance(1.0f / 60.0f).has_value());
  for (const auto& e : world.contact_events()) {
    CHECK(e.phase != ContactPhase::began);
    CHECK(e.phase != ContactPhase::hit);
  }
}

TEST_CASE("collision filters gate contacts, sensors and events") {
  // The rule is BOTH-directional: (a.collision_layer & b.collision_mask)
  // && (b.collision_layer & a.collision_mask). Every subcase is the same
  // 5 m drop onto a floor whose interface sits at y = 0 (ball center
  // rests at 0.5), so the y position after the steps IS the verdict.

  SUBCASE("a one-directional reject is a reject: the ball falls through") {
    auto world = make_world(World2D::Desc{.thread_count = 0});
    BodyDesc floor_desc = static_box({0.0f, -0.5f}, {50.0f, 0.5f});
    floor_desc.collision_mask = 2u;  // accepts layer 2 only: rejects the layer-1 ball
    auto floor = world.create_body(floor_desc);
    REQUIRE(floor.has_value());
    auto ball = world.create_body(ball_at({0.0f, 5.0f}, 0.0f));
    REQUIRE(ball.has_value());

    bool any_event = false;
    for (int i = 0; i < 90; ++i) {
      REQUIRE(world.step().has_value());
      any_event = any_event || !world.contact_events().empty();
    }
    CHECK_FALSE(any_event);  // the pair never existed
    auto state = world.body_state(*ball);
    REQUIRE(state.has_value());
    CHECK(state->position.y < -1.0f);  // through the interface, still falling
  }

  SUBCASE("runtime set_collision_filter flips a resting pair off") {
    auto world = make_world(World2D::Desc{.thread_count = 0});
    auto floor = world.create_body(static_box({0.0f, -0.5f}, {50.0f, 0.5f}));
    REQUIRE(floor.has_value());
    auto ball = world.create_body(ball_at({0.0f, 5.0f}, 0.0f));
    REQUIRE(ball.has_value());

    step_n(world, 120);  // drop and settle
    auto state = world.body_state(*ball);
    REQUIRE(state.has_value());
    CHECK(std::abs(state->position.y - 0.5f) < 0.05f);  // resting on it

    // Mask 0 accepts nothing; Box2D wakes the island on a filter change,
    // so the re-gated pair dies and the ball drops out of the world.
    REQUIRE(world.set_collision_filter(*ball, 1u, 0u).has_value());
    step_n(world, 90);
    state = world.body_state(*ball);
    REQUIRE(state.has_value());
    CHECK(state->position.y < -1.0f);
  }

  SUBCASE("a sensor fires began, does not respond, and sails the ball through") {
    auto world = make_world(World2D::Desc{.thread_count = 0});
    BodyDesc zone_desc = static_box({0.0f, -0.5f}, {50.0f, 0.5f});
    zone_desc.is_sensor = true;
    auto zone = world.create_body(zone_desc);
    REQUIRE(zone.has_value());
    auto ball = world.create_body(ball_at({0.0f, 5.0f}, 0.0f));
    REQUIRE(ball.has_value());

    bool sensor_began = false;
    for (int i = 0; i < 90; ++i) {
      REQUIRE(world.step().has_value());
      for (const auto& e : world.contact_events()) {
        if (e.phase == ContactPhase::began) {
          sensor_began = true;  // the only pair in the world
        }
      }
    }
    CHECK(sensor_began);
    auto state = world.body_state(*ball);
    REQUIRE(state.has_value());
    CHECK(state->position.y < -1.0f);  // no impulse: it fell straight through
  }

  SUBCASE("a filtered sensor stays silent") {
    auto world = make_world(World2D::Desc{.thread_count = 0});
    BodyDesc zone_desc = static_box({0.0f, -0.5f}, {50.0f, 0.5f});
    zone_desc.is_sensor = true;
    zone_desc.collision_mask = 0u;  // the zone accepts nothing
    auto zone = world.create_body(zone_desc);
    REQUIRE(zone.has_value());
    auto ball = world.create_body(ball_at({0.0f, 5.0f}, 0.0f));
    REQUIRE(ball.has_value());

    bool any_event = false;
    for (int i = 0; i < 90; ++i) {
      REQUIRE(world.step().has_value());
      any_event = any_event || !world.contact_events().empty();
    }
    CHECK_FALSE(any_event);
  }
}

TEST_CASE("runtime set_gravity redirects the fall and wakes the sleepers") {
  SUBCASE("flipping the sign turns the fall into a climb") {
    auto world = make_world(World2D::Desc{.thread_count = 0});
    auto id = world.create_body(dynamic_box({0.0f, 10.0f}));
    REQUIRE(id.has_value());

    step_n(world, 30);  // 0.5 s of free fall: y ~8.7, v ~-4.9
    auto state = world.body_state(*id);
    REQUIRE(state.has_value());

    REQUIRE(world.set_gravity({0.0f, 9.81f}).has_value());
    step_n(world, 60);  // one more second: the climb retraces the fall

    state = world.body_state(*id);
    REQUIRE(state.has_value());
    // Unflipped the box would sit at ~-0.9 and still be diving; flipped
    // the climb retraces the fall, landing back just above the flip
    // height (~8.8) with an upward velocity.
    CHECK(state->position.y > 8.4f);
    CHECK(state->linear_velocity.y > 4.0f);
  }

  SUBCASE("a resting pile sleeps, then wakes and leaves the floor") {
    auto world = make_world(World2D::Desc{.thread_count = 0});
    auto floor = world.create_body(static_box({0.0f, -1.0f}, {50.0f, 1.0f}));
    REQUIRE(floor.has_value());
    auto ball = world.create_body(ball_at({0.0f, 5.0f}, 0.3f));
    REQUIRE(ball.has_value());

    step_n(world, 240);  // 4 s: settle, then outlast the sleep timer
    auto state = world.body_state(*ball);
    REQUIRE(state.has_value());
    CHECK(std::abs(state->position.y - 0.5f) < 0.05f);  // resting on the floor
    REQUIRE(world.step().has_value());
    bool moved_while_sleeping = false;
    for (const auto& m : world.moved_bodies()) {
      if (m.id == *ball) {
        moved_while_sleeping = true;
      }
    }
    CHECK_FALSE(moved_while_sleeping);  // it really slept

    REQUIRE(world.set_gravity({0.0f, 9.81f}).has_value());
    step_n(world, 60);

    state = world.body_state(*ball);
    REQUIRE(state.has_value());
    // Unwoken it would sit at 0.5 forever; the wake-all lifts it out.
    CHECK(state->position.y > 1.5f);
  }
}

TEST_CASE("welded bodies move as one; destroying a body releases the joint") {
  auto world = make_world(World2D::Desc{.gravity = {0.0f, 0.0f},
                                         .thread_count = 0});
  auto a = world.create_body(dynamic_box({0.0f, 0.0f}));
  auto b = world.create_body(dynamic_box({1.0f, 0.0f}));
  REQUIRE(a.has_value());
  REQUIRE(b.has_value());
  auto joint = world.create_joint(FixedJoint{*a, *b});
  REQUIRE(joint.has_value());

  REQUIRE(world.set_velocity(*a, {1.0f, 0.0f}, 0.0f).has_value());
  REQUIRE(world.set_velocity(*b, {1.0f, 0.0f}, 0.0f).has_value());  // wake both
  step_n(world, 60);
  auto sa = world.body_state(*a);
  auto sb = world.body_state(*b);
  REQUIRE(sa.has_value());
  REQUIRE(sb.has_value());
  CHECK(sb->position.x - sa->position.x == doctest::Approx(1.0f).epsilon(0.01));
  CHECK(sa->linear_velocity.x == doctest::Approx(1.0f).epsilon(0.01));
  CHECK(sb->linear_velocity.x == doctest::Approx(1.0f).epsilon(0.01));

  // The cascade: killing a destroys the joint (engines refuse joints whose
  // bodies are gone - the lib removes the joint first) and the survivor
  // keeps simulating, unconstrained.
  REQUIRE(world.destroy_body(*a).has_value());
  CHECK(has_code(world.destroy_joint(*joint), PhysicsError::invalid_handle));
  step_n(world, 30);
  auto free_b = world.body_state(*b);
  REQUIRE(free_b.has_value());
  CHECK(free_b->linear_velocity.x == doctest::Approx(1.0f).epsilon(0.01));
  CHECK(free_b->position.x > 1.0f);  // kept drifting
}

TEST_CASE("a distance joint holds the pair at its length until destroyed") {
  auto world = make_world(World2D::Desc{.gravity = {0.0f, 0.0f},
                                         .thread_count = 0});
  auto a = world.create_body(dynamic_box({0.0f, 0.0f}));
  auto b = world.create_body(dynamic_box({2.0f, 0.0f}));
  REQUIRE(a.has_value());
  REQUIRE(b.has_value());
  auto joint = world.create_joint(DistanceJoint{*a, *b, 2.0f});
  REQUIRE(joint.has_value());

  REQUIRE(world.set_velocity(*b, {3.0f, 0.0f}, 0.0f).has_value());  // pulls away
  step_n(world, 60);
  auto sa = world.body_state(*a);
  auto sb = world.body_state(*b);
  REQUIRE(sa.has_value());
  REQUIRE(sb.has_value());
  const float held = std::hypot(sb->position.x - sa->position.x,
                                sb->position.y - sa->position.y);
  CHECK(held == doctest::Approx(2.0f).epsilon(0.02));  // the rod held

  // Explicit destroy: the pair drifts apart freely.
  REQUIRE(world.destroy_joint(*joint).has_value());
  REQUIRE(world.apply_linear_impulse(*b, {2.0f, 0.0f}).has_value());
  step_n(world, 60);
  sb = world.body_state(*b);
  sa = world.body_state(*a);
  REQUIRE(sb.has_value());
  REQUIRE(sa.has_value());
  const float free = std::hypot(sb->position.x - sa->position.x,
                                sb->position.y - sa->position.y);
  CHECK(free > 3.0f);
}

TEST_CASE("revolute joint: the motor spins the arm; limits stop it") {
  const auto make = []() {
    auto world = make_world(World2D::Desc{.gravity = {0.0f, 0.0f},
                                           .thread_count = 0});
    auto anchor = world.create_body(static_box({0.0f, 0.0f}, {0.25f, 0.25f}));
    auto arm = world.create_body(dynamic_box({1.0f, 0.0f}));
    REQUIRE(anchor.has_value());
    REQUIRE(arm.has_value());
    RevoluteJoint joint{};
    joint.a = *anchor;
    joint.b = *arm;
    joint.world_anchor = {0.0f, 0.0f};
    joint.enable_motor = true;
    joint.motor_speed = 2.0f;  // rad/s
    joint.max_motor_torque = 100.0f;
    auto id = world.create_joint(joint);
    REQUIRE(id.has_value());
    return std::pair{std::move(world), *arm};
  };

  SUBCASE("free spin reaches the motor speed") {
    auto [world, arm] = make();
    step_n(world, 60);  // 1 s at ~2 rad/s from a ~0.02 s spin-up
    auto state = world.body_state(arm);
    REQUIRE(state.has_value());
    const float angle = std::atan2(state->position.y, state->position.x);
    CHECK(std::abs(angle - 2.0f) < 0.15f);
  }
  SUBCASE("limits stop the spin at 0.25 rad") {
    auto [world, arm] = make();
    RevoluteJoint limited{};
    // (Re-create with limits: the make() helper left them off.)
    auto world2 = std::move(world);
    // destroy and rebuild the joint with limits on a fresh pair
    auto anchor = world2.create_body(static_box({0.0f, 5.0f}, {0.25f, 0.25f}));
    auto arm2 = world2.create_body(dynamic_box({1.0f, 5.0f}));
    REQUIRE(anchor.has_value());
    REQUIRE(arm2.has_value());
    limited.a = *anchor;
    limited.b = *arm2;
    limited.world_anchor = {0.0f, 5.0f};
    limited.enable_motor = true;
    limited.motor_speed = 2.0f;
    limited.max_motor_torque = 100.0f;
    limited.enable_limits = true;
    limited.lower_angle = -0.25f;
    limited.upper_angle = 0.25f;
    REQUIRE(world2.create_joint(limited).has_value());
    step_n(world2, 60);
    auto state = world2.body_state(*arm2);
    REQUIRE(state.has_value());
    const float angle = std::atan2(state->position.y - 5.0f,
                                   state->position.x);
    CHECK(std::abs(angle - 0.25f) < 0.03f);
  }
}

TEST_CASE("raycast: closest hit, t in world units, a miss is nullopt") {
  auto world = make_world(World2D::Desc{.thread_count = 0});
  auto box = world.create_body(static_box({0.0f, 0.0f}, {0.5f, 0.5f}));
  REQUIRE(box.has_value());

  auto hit = world.raycast({0.0f, -5.0f}, {0.0f, 2.0f}, 10.0f);
  REQUIRE(hit.has_value());   // Result level: no error
  REQUIRE(hit->has_value());  // the optional: there is a hit
  CHECK((*hit)->body == *box);
  CHECK((*hit)->t == doctest::Approx(4.5f).epsilon(0.001));  // up to the face
  CHECK((*hit)->point.y == doctest::Approx(-0.5f).epsilon(0.001));
  CHECK((*hit)->normal.y == doctest::Approx(-1.0f).epsilon(0.001));
  CHECK(std::abs((*hit)->normal.x) < 0.001f);

  // max_distance stops the segment short of the box.
  auto short_ray = world.raycast({0.0f, -5.0f}, {0.0f, 2.0f}, 4.0f);
  REQUIRE(short_ray.has_value());
  CHECK_FALSE(short_ray->has_value());

  // A parallel ray misses cleanly.
  auto miss = world.raycast({5.0f, 0.0f}, {1.0f, 0.0f}, 10.0f);
  REQUIRE(miss.has_value());
  CHECK_FALSE(miss->has_value());
}

TEST_CASE("overlap queries return the touched bodies, sorted by index") {
  auto world = make_world(World2D::Desc{.gravity = {0.0f, 0.0f},
                                         .thread_count = 0});
  auto near_a = world.create_body(static_box({0.0f, 0.0f}, {0.5f, 0.5f}));
  auto near_b = world.create_body(static_box({10.0f, 0.0f}, {0.5f, 0.5f}));
  auto far = world.create_body(static_box({100.0f, 0.0f}, {0.5f, 0.5f}));
  REQUIRE(near_a.has_value());
  REQUIRE(near_b.has_value());
  REQUIRE(far.has_value());

  auto hits = world.overlap_circle({5.0f, 0.0f}, 6.0f);
  REQUIRE(hits.has_value());
  REQUIRE(hits->size() == 2);
  CHECK((*hits)[0] == *near_a);  // sorted by id index, not broad-phase order
  CHECK((*hits)[1] == *near_b);

  auto aabb_hits = world.overlap_aabb(Aabb{{-1.0f, -1.0f}, {11.0f, 1.0f}});
  REQUIRE(aabb_hits.has_value());
  REQUIRE(aabb_hits->size() == 2);
  CHECK((*aabb_hits)[0] == *near_a);
  CHECK((*aabb_hits)[1] == *near_b);

  auto none = world.overlap_circle({50.0f, 50.0f}, 1.0f);
  REQUIRE(none.has_value());
  CHECK(none->empty());
}

TEST_CASE("moved_bodies: kinematics report, statics never do; new bodies "
          "spawn un-lerped") {
  auto world = make_world(World2D::Desc{.gravity = {0.0f, 0.0f},
                                         .thread_count = 0});
  auto floor = world.create_body(static_box({0.0f, -10.0f}, {50.0f, 1.0f}));
  REQUIRE(floor.has_value());
  BodyDesc platform{};
  platform.kind = ws::physics::BodyKind::kinematic;
  platform.shape = Box{ws::math::Vec2{2.0f, 0.25f}};
  auto moving = world.create_body(platform);
  REQUIRE(moving.has_value());
  REQUIRE(world.set_velocity(*moving, {2.0f, 0.0f}, 0.0f).has_value());

  step_n(world, 60);  // one second at 2 m/s -> x = 2
  auto state = world.body_state(*moving);
  REQUIRE(state.has_value());
  CHECK(state->position.x == doctest::Approx(2.0f).epsilon(0.001));

  bool saw_moving = false;
  for (int i = 0; i < 10; ++i) {
    REQUIRE(world.step().has_value());
    for (const auto& m : world.moved_bodies()) {
      CHECK_FALSE(m.id == *floor);  // statics never appear
      if (m.id == *moving) {
        saw_moving = true;
        CHECK(m.position.x == doctest::Approx(
                                  world.transforms()[m.id.index].position.x)
                                  .epsilon(0.001));
      }
    }
  }
  CHECK(saw_moving);
  REQUIRE(world.moved_bodies().size() == 1);  // the kinematic, awake forever

  // A body created after steps spawns un-lerped: prev = creation pose, then
  // prev = pre-tick pose once it simulates.
  BodyDesc falling = dynamic_box({0.0f, 5.0f});
  falling.linear_velocity = {0.0f, -1.0f};
  auto fresh = world.create_body(falling);
  REQUIRE(fresh.has_value());
  CHECK(world.prev_transforms()[fresh->index].position.y ==
        doctest::Approx(5.0f));
  step_n(world, 1);
  CHECK(world.prev_transforms()[fresh->index].position.y ==
        doctest::Approx(5.0f));
  CHECK(world.transforms()[fresh->index].position.y < 5.0f);
}

TEST_CASE("sleep control: the wake rules are the lib's, not the engine's") {
  auto world = make_world();
  auto floor = world.create_body(static_box({0.0f, -1.0f}, {20.0f, 1.0f}));
  REQUIRE(floor.has_value());

  // Every is_sleeping read below flows through this: a failed read must
  // never look like a pass.
  const auto sleeping = [&world](BodyId id) {
    const auto result = world.is_sleeping(id);
    REQUIRE(result.has_value());
    return *result;
  };

  // Twins from the same height: one pinned awake for life at create, one
  // left free to doze off.
  BodyDesc pinned_desc = dynamic_box({-2.0f, 0.6f});
  pinned_desc.allow_sleep = false;
  auto pinned = world.create_body(pinned_desc);
  REQUIRE(pinned.has_value());
  auto twin = world.create_body(dynamic_box({2.0f, 0.6f}));
  REQUIRE(twin.has_value());

  // Both settle onto the floor; only the free twin falls asleep (bounded
  // wait - a sleeper must appear or the test says so, no hang).
  bool slept = false;
  for (int i = 0; i < 300 && !slept; ++i) {
    REQUIRE(world.step().has_value());
    slept = sleeping(*twin);
  }
  REQUIRE(slept);
  CHECK(sleeping(*pinned) == false);
  CHECK(sleeping(*floor) == false);  // statics never sleep (CONTRACT.md 6)

  // wake() is unconditional; no step is needed to observe it.
  REQUIRE(world.wake(*twin).has_value());
  CHECK(sleeping(*twin) == false);

  // Resettle, then set_velocity: the wake rule is "iff the new velocity is
  // nonzero" (CONTRACT.md 6) - a zero set must leave a sleeper asleep.
  slept = false;
  for (int i = 0; i < 300 && !slept; ++i) {
    REQUIRE(world.step().has_value());
    slept = sleeping(*twin);
  }
  REQUIRE(slept);
  REQUIRE(world.set_velocity(*twin, {0.0f, 0.0f}, 0.0f).has_value());
  CHECK(sleeping(*twin));
  REQUIRE(world.set_velocity(*twin, {0.1f, 0.0f}, 0.0f).has_value());
  CHECK(sleeping(*twin) == false);

  // Resettle, then set_sleepable: permitting sleep never wakes; forbidding
  // it wakes immediately, even from sleep.
  slept = false;
  for (int i = 0; i < 300 && !slept; ++i) {
    REQUIRE(world.step().has_value());
    slept = sleeping(*twin);
  }
  REQUIRE(slept);
  REQUIRE(world.set_sleepable(*twin, true).has_value());
  CHECK(sleeping(*twin));
  REQUIRE(world.set_sleepable(*twin, false).has_value());
  CHECK(sleeping(*twin) == false);

  // The pinned twin stayed awake through all of it.
  CHECK(sleeping(*pinned) == false);
}

namespace {

// The global operator new/delete overrides at the bottom of this file bump
// this counter; only before/after deltas around a window are meaningful.
long long g_alloc_count = 0;

}  // namespace

[[nodiscard]] long long allocation_count() { return g_alloc_count; }

TEST_CASE("steady-state stepping allocates zero C++ heap") {
  World2D::Desc desc{};
  desc.max_bodies = 64;
  desc.max_contact_events = 512;
  desc.thread_count = 2;  // the threaded path must hold the promise too
  auto world = make_world(desc);

  auto floor = world.create_body(static_box({0.0f, -10.0f}, {50.0f, 1.0f}));
  REQUIRE(floor.has_value());
  std::vector<BodyId> ids;
  for (int i = 0; i < 24; ++i) {
    auto id = world.create_body(dynamic_box({-4.0f + 1.0f * i,
                                            2.0f + 1.0f * (i % 4)}));
    REQUIRE(id.has_value());
    ids.push_back(*id);
  }
  auto weld = world.create_joint(FixedJoint{ids[0], ids[1]});
  REQUIRE(weld.has_value());
  auto rod = world.create_joint(DistanceJoint{ids[2], ids[3], 1.0f});
  REQUIRE(rod.has_value());

  step_n(world, 30);  // warm-up: settle Box2D's arenas and our buffers

  const long long before = allocation_count();
  for (int i = 0; i < 60; ++i) {
    REQUIRE(world.step().has_value());
    REQUIRE(world.contact_events().size() <= 512);
    // +2: the two bodies spawned mid-window (below) are awake and moving
    // too, and neither is in ids.
    REQUIRE(world.moved_bodies().size() <= ids.size() + 2);
    (void)world.prev_transforms();
    (void)world.interpolation_alpha();
    if (i == 30) {
      // The rest of the steady-state API surface, mid-window. The batch is
      // caller-owned stack memory - exactly the renderer pattern.
      const BodyMove batch_data[]{BodyMove{ids[4], {0.0f, 30.0f}, 0.5f}};
      REQUIRE(world.set_transforms(std::span{batch_data}).has_value());
      REQUIRE(world.apply_linear_impulse(ids[5], {0.1f, 0.2f}).has_value());
      REQUIRE(world.body_state(ids[6]).has_value());
    }
    if (i == 45) {
      // Spawn/despawn stays allocation-free too (capacity is pre-reserved;
      // Box2D's own growth happens on its C heap, not through new).
      REQUIRE(world.destroy_body(ids[7]).has_value());
      auto fresh = world.create_body(dynamic_box({2.0f, 25.0f}));
      REQUIRE(fresh.has_value());
      // A compound spawn mid-window: the one desc copy stays free because
      // parts ride a fixed array, not a vector (the array IS the fix this
      // test pins - a vector's MSVC debug proxy would allocate here).
      BodyDesc compound = dynamic_box({-2.0f, 25.0f});
      compound.parts[0] = Part{Circle{0.5f}, {}, 0.2f, 0.0f};
      compound.parts[1] = Part{Box{ws::math::Vec2{0.5f, 0.5f}},
                               ws::math::Vec2{2.0f, 0.0f}, 0.2f, 0.0f};
      compound.part_count = 2;
      auto compound_id = world.create_body(compound);
      REQUIRE(compound_id.has_value());
    }
  }
  CHECK(allocation_count() - before == 0);
}

TEST_CASE("determinism: same binary, same thread count, same call sequence") {
  const auto replay_hash = [](unsigned int thread_count) {
    World2D::Desc desc{};
    desc.thread_count = thread_count;
    desc.max_bodies = 64;
    auto world = make_world(desc);
    auto floor = world.create_body(static_box({0.0f, -10.0f}, {50.0f, 1.0f}));
    REQUIRE(floor.has_value());
    std::vector<BodyId> ids;
    for (int i = 0; i < 5; ++i) {
      BodyDesc d = dynamic_box({-3.0f + 1.5f * i, 5.0f + 0.7f * i});
      d.restitution = 0.3f;
      auto id = world.create_body(d);
      REQUIRE(id.has_value());
      REQUIRE(world.set_velocity(*id, {0.3f * i, -1.0f}, 0.0f).has_value());
      ids.push_back(*id);
    }
    for (int s = 0; s < 120; ++s) {
      if (s % 30 == 0) {
        REQUIRE(world.apply_linear_impulse(ids[(s / 30) % ids.size()],
                                           {0.5f, 1.0f})
                    .has_value());
      }
      REQUIRE(world.step().has_value());
    }
    // FNV-1a over the raw bytes of every body's pose: bit-identical
    // replays must hash identically.
    std::uint64_t hash = 1469598103934665603ull;
    const auto mix = [&hash](const void* p, std::size_t n) {
      const auto* bytes = static_cast<const unsigned char*>(p);
      for (std::size_t i = 0; i < n; ++i) {
        hash ^= bytes[i];
        hash *= 1099511628211ull;
      }
    };
    for (const auto& id : ids) {
      auto state = world.body_state(id);
      REQUIRE(state.has_value());
      mix(&state->position.x, sizeof(float));
      mix(&state->position.y, sizeof(float));
      mix(&state->rotation, sizeof(float));
    }
    return hash;
  };

  const auto serial_a = replay_hash(0);
  const auto serial_b = replay_hash(0);
  CHECK(serial_a == serial_b);
  const auto threaded_a = replay_hash(2);
  const auto threaded_b = replay_hash(2);
  CHECK(threaded_a == threaded_b);
}

// --- global allocation counters --------------------------------------------
// Replaces the process's operators so the zero-allocation case can see
// every C++ heap allocation. All allocations funnel through one family:
// _aligned_malloc/_aligned_free on MSVC, aligned_alloc/free elsewhere, so
// every delete pairs with its allocator regardless of alignment.

void* operator new(std::size_t n) {
  ++g_alloc_count;
  n = n ? n : 1;
#if defined(_MSC_VER)
  if (void* p = _aligned_malloc(n, 16)) {
    return p;
  }
#else
  if (void* p = std::aligned_alloc(16, ((n + 15u) / 16u) * 16u)) {
    return p;
  }
#endif
  throw std::bad_alloc{};
}

void* operator new[](std::size_t n) { return ::operator new(n); }

void* operator new(std::size_t n, std::align_val_t a) {
  ++g_alloc_count;
  n = n ? n : 1;
  const std::size_t alignment =
      static_cast<std::size_t>(a) < 16u ? 16u : static_cast<std::size_t>(a);
#if defined(_MSC_VER)
  if (void* p = _aligned_malloc(n, alignment)) {
    return p;
  }
#else
  if (void* p = std::aligned_alloc(alignment,
                                  ((n + alignment - 1u) / alignment) * alignment)) {
    return p;
  }
#endif
  throw std::bad_alloc{};
}

void* operator new[](std::size_t n, std::align_val_t a) {
  return ::operator new(n, a);
}

void operator delete(void* p) noexcept {
#if defined(_MSC_VER)
  _aligned_free(p);
#else
  std::free(p);
#endif
}

void operator delete(void* p, std::size_t) noexcept { ::operator delete(p); }
void operator delete(void* p, std::align_val_t) noexcept {
  ::operator delete(p);
}
void operator delete(void* p, std::size_t, std::align_val_t) noexcept {
  ::operator delete(p);
}
void operator delete[](void* p) noexcept { ::operator delete(p); }
void operator delete[](void* p, std::size_t) noexcept { ::operator delete(p); }
void operator delete[](void* p, std::align_val_t) noexcept {
  ::operator delete(p);
}
void operator delete[](void* p, std::size_t, std::align_val_t) noexcept {
  ::operator delete(p);
}
