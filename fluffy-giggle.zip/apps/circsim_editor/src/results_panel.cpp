// apps/circsim_editor - the Results panel (see results_panel.hpp).
//
// The layout, top to bottom: the header row (the table combo over the
// run's analyses, the export pair), the legend (one row per signal - a
// color swatch, the visibility checkbox, and the live readout at the
// hover index, falling back to the last sample), the plot itself (a
// fixed-height flow rect the canvas draws into in screen space; the
// scroll panel's clip keeps it inside the panel), and the measurement
// rows. A table with no sweep axis (.op) has no plot - its signals
// render as value rows, the ngspice op printout shape.
//
// The y range spans the VISIBLE signals only, x spans the analysis's
// own axis (the step axes are skipped, per results.hpp's contract) or
// the sample index when there is none; both ride ws::circsim::plot's
// padding and tick ladder, and long sweeps ride its min/max
// decimation so a 100k-point tran still shows its envelope at ~1
// vertex per pixel.
//
// Stage 5 adds the plot's hands: the wheel zooms both axes toward the
// cursor (the plot registers its own wheel claim - the innermost rect
// beats the enclosing scroll panel's), a left-drag rubber band zooms
// to the box, dragging on an axis strip stretches that axis, the
// middle/space drag pans, a double-click resets, a right-click
// cancels an in-flight drag. Every gesture rides ws::circsim::plot's
// clamp/zoom/pan math (headless, tested) against the HOME range - the
// padded auto fit - so the view can never leave the data; the
// decimation slices to the visible x window so a zoomed-in view
// spends its pixel budget on the samples it shows.
//
// Stage 6 gives a mixed V/I legend its second spine. The y fit splits
// per axis (ws::circsim::signal_y_axis): the voltage columns keep the
// left scale, the current columns earn a right one - own padded fit,
// own tick ladder, own label strip (the frame's right margin widens
// for it), own drag strip. Every stage-5 gesture now works on three
// windows: the wheel zooms x toward the cursor and each y spine
// toward its own mapped anchor, the band commits its box through each
// spine's own transform, the pan slides both y windows by the same
// pixels, and the right strip's drag stretches the amp window alone.
// A table with no visible current column draws exactly the stage-5
// shape - the right margin, strip and ticks only exist when the
// second spine does.
//
// Stage 7 is the polish pass: a floating hover tooltip (x plus every
// visible signal, units included), a sparkline per legend row, show
// all / hide all and a "fit view" button, a zero rail, an empty-state
// message, aligned value rows with units, and a one-line gesture
// cheat sheet under the plot. The per-frame debug logging and the
// per-frame index vector in the hover path are gone.
//
// Stage 8 is the frame-budget pass (the big-circuit fix): a run with
// dozens of signals over tens of thousands of samples used to re-walk
// every column three times a frame (the y fit, each sparkline, each
// series' decimation), which priced an idle frame at O(signals x
// samples) and made big results panels crawl. The per-frame work over
// the run's data is now cached against what it actually depends on
// (ResultsCache's frame-budget block): per-signal constants (the
// y-fit envelope, the sparkline envelope, the spine flags) once per
// (run, table), and the series decimations once per (x window, pixel
// budget). An idle frame maps cached keep lists through the screen
// transform - O(signals x budget) - and the axisless tables join
// the envelope club through ws::circsim::decimate_minmax_index.
//
// Stage 9 is the family pass (the .step fix): a stepped run lands as
// one table whose inner axis REPEATS once per step point (the
// scr_trigger_vfmm shape - 24 passes x 1103 rows), and one polyline
// over it chords every reset into a lines-between-vertices mess. The
// axis now splits into its monotone passes (ws::circsim::
// split_axis_runs - a falling .dc pass included, drawn reversed) and
// every pass overlays on the shared window: one stroke per pass per
// signal, broken at the resets, each decimated to the pixel budget
// and cached like the sorted path always was. A sorted axis is the
// one-run family - the two draw paths are one.

#include "results_panel.hpp"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <string>
#include <utility>
#include <vector>
#include <span>

#include <ws/core/log.hpp>
#include <ws/input/input.hpp>
#include <ws/plotmath/plotmath.hpp>
#include <ws/spice/results.hpp>
#include <ws/circsim/overlay.hpp>
#include <ws/circsim/png.hpp>
#include <ws/ui/renderer2d.hpp>

namespace editor {
namespace {

namespace canvas = ws::ui::canvas;
using canvas::Paint;
using canvas::Point;

// The series palette: data colors, not chrome - the shared wheel the
// legend swatches, the polylines AND the canvas's net-colored wires all
// ride (i mod N, like every scope) - editor.hpp's series_color, the
// one definition the app owns.
using editor::series_color;

[[nodiscard]] const char* analysis_name(ws::spice::AnalysisKind kind) {
    switch (kind) {
        case ws::spice::AnalysisKind::Op: return ".op";
        case ws::spice::AnalysisKind::Dc: return ".dc";
        case ws::spice::AnalysisKind::Tran: return ".tran";
        case ws::spice::AnalysisKind::Ac: return ".ac";
        case ws::spice::AnalysisKind::Noise: return ".noise";
    }
    return "?";
}

// The unit a signal is read in: the classifier's spine, spelled out.
[[nodiscard]] const char* unit_of(const std::string& name) {
    return ws::circsim::signal_y_axis(name) ==
                   ws::circsim::PlotYAxis::Right
               ? "A"
               : "V";
}

[[nodiscard]] std::string with_unit(double v, const char* unit,
                                    int digits = 4) {
    std::string out = ws::circsim::format_eng(v, digits);
    out += ' ';
    out += unit;
    return out;
}

struct ValueRow {
    std::string name;
    double value = 0.0;
    const char* unit = "";
};

// Keeps the per-signal visibility flags aligned with the table being
// shown (all-visible on a table switch; the flags survive frames).
//
// The size half of the condition guards the INVARIANT "visible has
// exactly t.signals.size() flags for the shown table": a mismatch can
// only mean the flags and `visible_for` disagree about which table
// they belong to (a delivery that reset one and not the other, or a
// table switch that landed mid-frame), and every reader downstream
// indexes visible[i] against t.signals[i] - the legend's checkbox
// write (which re-checks the size before it indexes, the same guard
// reading the same invariant from the write side) and the plot's
// series loop. Re-assigning on the mismatch restores all-visible,
// the same honest answer as a table switch, instead of drawing
// against flags sized for some other table.
void sync_visibility(Editor& ed, const ws::spice::Table& t) {
    if (ed.results.visible_for != ed.results.table ||
        ed.results.visible.size() != t.signals.size()) {
        ed.results.visible.assign(t.signals.size(), 1u);
        ed.results.visible_for = ed.results.table;
    }
}

// The manual view belongs to the table it was made on: a switch (or a
// fresh run, which resets view_for) drops back to the auto fit. Synced
// for EVERY table, once a frame, like sync_visibility - a table with no
// plot (.op: value rows) never reaches draw_plot, so a reset that lived
// there missed tran -> op -> tran and the old zoom came back. The
// markers are sample indices into one table and ride the same rule.
void sync_view(ResultsCache& cache) {
    if (cache.view_for != cache.table) {
        cache.view = PlotView{};
        cache.view_for = cache.table;
    }
    if (cache.markers_for != cache.table) {
        cache.markers.clear();
        cache.markers_for = cache.table;
    }
}

// The per-signal constants of the shown table (ResultsCache's
// frame-budget block): every column's finite envelope (the y fit and
// the sparkline scale both read it), the sparkline's 40-bucket
// envelope, and the two-axis classifier's spine flag. One walk per
// (run, table) - the tables are immutable once delivered, so the key
// (run_id, table index) is sound by construction, and a frame that
// changes nothing (the common case) reads the vectors as-is. The y
// fit below and every legend row drop from O(samples) to O(1)/O(40)
// per frame, whatever the circuit's size.
void ensure_series_stats(Editor& ed, const ws::spice::Table& t) {
    ResultsCache& cache = ed.results;
    if (cache.stats_for == cache.table &&
        cache.stats_run == cache.run_id &&
        cache.stats.size() == t.signals.size()) {
        return;  // the constants of THIS table of THIS run
    }
    cache.stats.clear();
    cache.stats.resize(t.signals.size());
    constexpr std::size_t kSparkBuckets = 40;
    for (std::size_t i = 0; i < t.signals.size(); ++i) {
        ResultsCache::SeriesStats& st = cache.stats[i];
        st.right = ws::circsim::signal_y_axis(t.signals[i].name) ==
                   ws::circsim::PlotYAxis::Right;
        const std::span<const double> ys = t.signals[i].data;
        const std::size_t n = ys.size();
        // The finite envelope: one scan serves the y fit (which used
        // to re-scan every visible column per frame) and the
        // sparkline's scale.
        double lo = std::numeric_limits<double>::infinity();
        double hi = -std::numeric_limits<double>::infinity();
        for (double v : ys) {
            if (std::isfinite(v)) {
                lo = std::min(lo, v);
                hi = std::max(hi, v);
            }
        }
        if (lo <= hi) {
            st.finite = true;
            st.lo = lo;
            st.hi = hi;
        }
        // The sparkline envelope: the exact point list draw_sparkline
        // used to rebuild per frame per legend row, materialized once
        // - 2 entries per bucket (the min and max sample's VALUE in
        // occurrence order; a NaN pair for a bucket with nothing
        // finite). n < 2 draws no sparkline; the empty vector is its
        // own answer.
        const std::size_t buckets = std::min(kSparkBuckets, n);
        st.spark_env.assign(buckets * 2u,
                            std::numeric_limits<double>::quiet_NaN());
        for (std::size_t b = 0; b < buckets; ++b) {
            const std::size_t i0 = b * n / buckets;
            const std::size_t i1 = std::max(i0 + 1u, (b + 1u) * n / buckets);
            std::size_t imin = n;
            std::size_t imax = n;
            for (std::size_t k = i0; k < i1 && k < n; ++k) {
                if (!std::isfinite(ys[k])) {
                    continue;
                }
                if (imin == n || ys[k] < ys[imin]) {
                    imin = k;
                }
                if (imax == n || ys[k] > ys[imax]) {
                    imax = k;
                }
            }
            if (imin == n) {
                continue;  // nothing finite: the NaN pair stays
            }
            // Index order inside the bucket, so a falling edge does
            // not zigzag (draw_sparkline's own rule).
            const std::size_t first = std::min(imin, imax);
            const std::size_t second = std::max(imin, imax);
            st.spark_env[b * 2u] = ys[first];
            st.spark_env[b * 2u + 1u] = ys[second];
        }
    }
    cache.stats_for = cache.table;
    cache.stats_run = cache.run_id;
}

// The plot's axis math, hover lookup and gesture factors ride
// ws::plotmath now (the unify-plotting merge): the same shared core
// the generic gui plot widget calls, one authoritative spelling of
// the ladder, the view invariants, the nearest-sample walk and the
// navigation constants. The local strictly_increasing/nearest_sample
// copies are gone; ws::circsim::plot's own functions (this file's
// other seam) are the same core through the circsim facade.

// --- waveform render experiments (opt-in; see the env vars below) -------------
//
// Both knobs are read ONCE, at first use, so an A/B run is two launches of the
// same binary - no rebuild, no per-frame cost when they are unset.
//
//   CIRCSIM_PLOT_PROF=1         log per-stage CPU timings of the plot's series
//                               loop every kProfWindow frames (INFO).
//   CIRCSIM_PLOT_PROF=2         the same, plus a SHADOW tessellation on cache
//                               misses into a throwaway TessBuffer (timed, not
//                               drawn): "tess" is the tessellator alone, so
//                               stroke - tess = the canvas wrapper + r2d's
//                               per-quad recording. Costs extra CPU: use it for
//                               the split, not for the baseline.
//   CIRCSIM_PLOT_PROF=3         like 2, but the shadow tessellation lands in a
//                               sink that only COUNTS quads (no vertex copy).
//                               That is the tessellator's own cost: PROF=2's
//                               TessBuffer sink adds its own per-quad vertex
//                               store, which can make "tess" exceed "stroke".
//                               stroke - tess is then the canvas wrapper +
//                               r2d recording.
//   CIRCSIM_PLOT_JOIN=round     stroke the plot's SERIES with round joins
//                               (round | bevel | miter; unset = bevel, i.e. the
//                               shipped look). Legend sparklines and everything
//                               else keep their own paint.
//
// MSVC deprecates getenv (C4996); a one-shot read is fine, so the warning is
// suppressed scoped - the same spelling libs/ui/src/app/app.cpp uses.
const char* wave_getenv(const char* name) {
#if defined(_MSC_VER)
#pragma warning(push)
#pragma warning(disable : 4996)
#endif
    return std::getenv(name);
#if defined(_MSC_VER)
#pragma warning(pop)
#endif
}

struct WaveEnv {
    int prof = 0;  // 0 off, 1 timings, 2/3 + shadow tessellation (2 into a
                   // TessBuffer, 3 into a counting sink)
    canvas::StrokeJoin join = canvas::StrokeJoin::bevel;
};

const WaveEnv& wave_env() {
    static const WaveEnv env = [] {
        WaveEnv e;
        const char* p = wave_getenv("CIRCSIM_PLOT_PROF");
        e.prof = (p == nullptr || p[0] == '\0' || p[0] == '0')
                     ? 0
                     : (p[0] == '3' ? 3 : (p[0] == '2' ? 2 : 1));
        const char* j = wave_getenv("CIRCSIM_PLOT_JOIN");
        if (j != nullptr) {
            if (std::strcmp(j, "bevel") == 0) {
                e.join = canvas::StrokeJoin::bevel;
            } else if (std::strcmp(j, "miter") == 0) {
                e.join = canvas::StrokeJoin::miter;
            }
        }
        return e;
    }();
    return env;
}

// Per-frame counters for the plot's series loop, folded into a window and
// logged. "prep" = everything in a series' iteration except the stroke call
// (the decimation cache check, the x/y mapping into scratch_pts); "stroke" =
// stroke_series() whole (Renderer2DCanvas::stroke_polyline -> screen copy ->
// CPU tessellator -> r2d quad recording). The tessellator alone is not split
// out here; see the notes in the PR/summary.
struct WaveProf {
    using Clock = std::chrono::steady_clock;
    static constexpr int kProfWindow = 120;  // frames per log line

    // One frame.
    double prep_ms = 0.0;
    double stroke_ms = 0.0;
    std::size_t series = 0;
    std::size_t points = 0;
    std::size_t polylines = 0;
    std::size_t heap_polylines = 0;  // > 64 pts: Renderer2DCanvas heap-allocs
                                     // a screen copy for each, every frame
    double tess_ms = 0.0;            // PROF>=2: shadow tessellation only
    std::size_t quads = 0;           // PROF>=2: quads that tessellation emitted

    // The window.
    int frames = 0;
    double w_prep_ms = 0.0, w_stroke_ms = 0.0, w_frame_max_ms = 0.0;
    double w_tess_ms = 0.0;
    std::size_t w_series = 0, w_points = 0, w_polylines = 0, w_heap = 0;
    std::size_t w_quads = 0;
    std::size_t cache_hits = 0, cache_misses = 0;
    std::size_t w_cache_hits = 0, w_cache_misses = 0;
};

WaveProf& wave_prof() {
    static WaveProf p;
    return p;
}

[[nodiscard]] WaveProf::Clock::time_point wave_now() {
    return wave_env().prof != 0 ? WaveProf::Clock::now()
                           : WaveProf::Clock::time_point{};
}

[[nodiscard]] double wave_ms_since(WaveProf::Clock::time_point t0) {
    return std::chrono::duration<double, std::milli>(WaveProf::Clock::now() -
                                                     t0)
        .count();
}

void wave_prof_begin_frame() {
    if (wave_env().prof == 0) {
        return;
    }
    WaveProf& p = wave_prof();
    p.prep_ms = p.stroke_ms = p.tess_ms = 0.0;
    p.series = p.points = p.polylines = p.heap_polylines = p.quads = 0u;
    p.cache_hits = p.cache_misses = 0u;
}

void wave_prof_end_frame() {
    if (wave_env().prof == 0) {
        return;
    }
    WaveProf& p = wave_prof();
    p.w_tess_ms += p.tess_ms;
    p.w_quads += p.quads;
    p.w_cache_hits += p.cache_hits;
    p.w_cache_misses += p.cache_misses;
    p.w_prep_ms += p.prep_ms;
    p.w_stroke_ms += p.stroke_ms;
    p.w_frame_max_ms = std::max(p.w_frame_max_ms, p.prep_ms + p.stroke_ms);
    p.w_series += p.series;
    p.w_points += p.points;
    p.w_polylines += p.polylines;
    p.w_heap += p.heap_polylines;
    if (++p.frames < WaveProf::kProfWindow) {
        return;
    }
    const double n = static_cast<double>(p.frames);
    ws::core::info(
        "plot prof ({} frames): prep {:.3f} ms/frame, stroke {:.3f} ms/frame "
        "(worst frame {:.3f} ms) | {:.1f} series, {:.0f} pts, {:.1f} "
        "polylines ({:.1f} heap-copied) per frame",
        p.frames, p.w_prep_ms / n, p.w_stroke_ms / n, p.w_frame_max_ms,
        static_cast<double>(p.w_series) / n,
        static_cast<double>(p.w_points) / n,
        static_cast<double>(p.w_polylines) / n,
        static_cast<double>(p.w_heap) / n);
    ws::core::info(
        "plot tess cache: {} hits, {} misses ({}% hit rate)",
        p.w_cache_hits, p.w_cache_misses,
        (p.w_cache_hits + p.w_cache_misses) != 0u
            ? 100.0 * static_cast<double>(p.w_cache_hits) /
                  static_cast<double>(p.w_cache_hits + p.w_cache_misses)
            : 0.0);
    if (wave_env().prof >= 2) {
        ws::core::info(
            "plot prof split (PROF={}, {} sink): tessellator {:.3f} ms/frame "
            "for {:.0f} quads/frame ({:.1f} ns/quad); stroke minus "
            "tessellator {:.3f} ms/frame",
            wave_env().prof, wave_env().prof >= 3 ? "counting" : "TessBuffer",
            p.w_tess_ms / n, static_cast<double>(p.w_quads) / n,
            p.w_quads > 0u ? p.w_tess_ms * 1.0e6 /
                                 static_cast<double>(p.w_quads)
                           : 0.0,
            (p.w_stroke_ms - p.w_tess_ms) / n);
    }
    p.frames = 0;
    p.w_prep_ms = p.w_stroke_ms = p.w_frame_max_ms = p.w_tess_ms = 0.0;
    p.w_series = p.w_points = p.w_polylines = p.w_heap = p.w_quads = 0u;
    p.w_cache_hits = p.w_cache_misses = 0u;
}

// One series polyline, mapped to the frame (the series loop's clip rect
// does the cutting); non-finite
// samples break the line into segments rather than poisoning the
// tessellator with NaN vertices. `join` defaults to round, the shipped look;
// the plot's series loop passes wave_env().join (CIRCSIM_PLOT_JOIN). When
// `polylines` / `heap_polylines` are non-null they count the strokes issued
// (and those long enough, > 64 points, that Renderer2DCanvas::stroke_polyline
// heap-allocates its screen copy).
void stroke_series(canvas::Canvas2D& rc,
                   const std::vector<Point>& pts, std::uint32_t color,
                   float width = 2.0f,
                   canvas::StrokeJoin join = canvas::StrokeJoin::round,
                   std::size_t* polylines = nullptr,
                   std::size_t* heap_polylines = nullptr) {
    Paint paint;
    paint.width = width;
    paint.color = color;
    paint.join = join;
    std::size_t run = 0;
    for (std::size_t i = 0; i <= pts.size(); ++i) {
        const bool break_here = i == pts.size() ||
                                std::isnan(pts[i].x) || std::isnan(pts[i].y);
        if (break_here && run >= 2u) {
            rc.stroke_polyline(pts.data() + (i - run),
                               static_cast<int>(run), paint);
            if (polylines != nullptr) {
                ++*polylines;
            }
            if (heap_polylines != nullptr && run > 64u) {
                ++*heap_polylines;
            }
        }
        if (i == pts.size()) {
            break;
        }
        run = break_here ? 0u : run + 1u;
    }
}

// PROF=3's sink: counts quads and nothing else, so the timing is the
// tessellator's own (one virtual call per quad, which the real sinks pay too).
class CountingSink final : public canvas::TessSink {
public:
    void quad(const ws::math::Vec2 (&)[4],
              const ws::math::Vec4 (&)[4]) override {
        ++count;
    }
    std::size_t count = 0;
};

// PROF>=2 only: tessellate `pts` exactly as stroke_series would (same NaN run
// splitting, same paint) into `out`, with no drawing. Timed by the caller.
void shadow_tessellate(const std::vector<Point>& pts, std::uint32_t color,
                       float width, canvas::StrokeJoin join,
                       canvas::TessSink& out) {
    Paint paint;
    paint.width = width;
    paint.color = color;
    paint.join = join;
    std::size_t run = 0;
    for (std::size_t i = 0; i <= pts.size(); ++i) {
        const bool break_here = i == pts.size() ||
                                std::isnan(pts[i].x) || std::isnan(pts[i].y);
        if (break_here && run >= 2u) {
            canvas::stroke_polyline(pts.data() + (i - run),
                                    static_cast<int>(run), paint, out, false);
        }
        if (i == pts.size()) {
            break;
        }
        run = break_here ? 0u : run + 1u;
    }
}

// Tessellate the already-mapped screen-space points into a retained
// buffer. NaNs split stepped passes exactly as stroke_series does.
void tessellate_series(const std::vector<Point>& pts,
                       std::uint32_t color, float width,
                       canvas::StrokeJoin join, canvas::TessBuffer& out) {
    out.clear();
    Paint paint;
    paint.width = width;
    paint.color = color;
    paint.join = join;
    std::size_t run = 0;
    for (std::size_t i = 0; i <= pts.size(); ++i) {
        const bool break_here = i == pts.size() ||
                                std::isnan(pts[i].x) || std::isnan(pts[i].y);
        if (break_here && run >= 2u) {
            canvas::stroke_polyline(pts.data() + (i - run),
                                    static_cast<int>(run), paint, out, false);
        }
        if (i == pts.size()) break;
        run = break_here ? 0u : run + 1u;
    }
}

// --- the plot -----------------------------------------------------------------

// The plot rect's margins: the frame sits inside; the x axis's strip
// is the bottom margin (its labels live there), the y axis's is the
// left one. The strips are the axis-drag zooms' handles, so they are
// interaction geometry, not just spacing. Stage 6: a right axis
// widens the right margin to a label strip of its own - and that
// strip is the right spine's drag handle. The no-axis margin is the
// stage-5 shape exactly.
constexpr float kPlotHeight = 220.0f;
// The frame's margins and the 40x30 guard: the shared core's
// constants (the widget's frame draws the identical ones - one
// spelling, the unify-plotting merge).
constexpr float kMarginLeft = ws::plotmath::kMarginLeft;
constexpr float kMarginBottom = ws::plotmath::kMarginBottom;
constexpr float kMarginTop = ws::plotmath::kMarginTop;
constexpr float kMarginRight = ws::plotmath::kMarginRight;
constexpr float kMarginRightAxis = ws::plotmath::kMarginRightAxis;

// The band's fill/outline: the theme's accent, alpha-split (a wash
// under the series, a line around the box). r2d packs 0xRRGGBBAA, so
// the alpha is the low byte.
[[nodiscard]] std::uint32_t with_alpha(std::uint32_t color,
                                       std::uint8_t a) {
    return (color & 0xFFFFFF00u) | std::uint32_t(a);
}

// A legend sparkline: the cached 40-bucket envelope (see
// ensure_series_stats) squeezed into `r`, scaled to its own range,
// with a dot at the hover sample. It is a thumbnail of the SHAPE - the
// plot carries the numbers - and it costs O(buckets) a frame instead
// of the two full-column scans it used to run per legend row.
// False when the enclosing clip hides `r` ENTIRELY: a scroll panel
// (the dock's body) pushes one rect into both r2d's clip stack and the
// gui's hit clip, so a row scrolled out of sight is recorded, tessellated
// and submitted for nothing. No clip pushed (a bare layout, a test
// bench) shows everything - the safe default. Touching edges count as
// hidden (the clip is half-open, like Rect::contains).
[[nodiscard]] bool clip_shows(const gui::GuiContext& gui,
                              const gui::Rect& r) {
    const gui::Rect* clip = gui.current_hit_clip();
    if (clip == nullptr) {
        return true;
    }
    return r.x < clip->x + clip->width && r.x + r.width > clip->x &&
           r.y < clip->y + clip->height && r.y + r.height > clip->y;
}

void draw_sparkline(canvas::Canvas2D& rc, const gui::Rect& r,
                    std::span<const double> ys,
                    const ResultsCache::SeriesStats& st,
                    std::uint32_t color, int mark,
                    std::vector<Point>& pts) {
    const std::size_t n = ys.size();
    const std::size_t buckets = st.spark_env.size() / 2u;
    if (n < 2u || buckets < 2u || !st.finite) {
        return;
    }
    double lo = st.lo;
    double hi = st.hi;
    if (!(hi > lo)) {
        lo -= 1.0;  // a flat signal rides the middle rail
        hi += 1.0;
    }
    const float h = r.height - 4.0f;
    const auto py = [&](double v) {
        return static_cast<float>(r.y + 2.0f + (hi - v) / (hi - lo) * h);
    };
    pts.clear();
    pts.reserve(buckets * 2u);
    for (std::size_t b = 0; b < buckets; ++b) {
        const float px = r.x + static_cast<float>(b) *
                                   (r.width - 1.0f) /
                                   static_cast<float>(buckets - 1u);
        pts.push_back(Point{px, py(st.spark_env[b * 2u])});
        pts.push_back(Point{px, py(st.spark_env[b * 2u + 1u])});
    }
    stroke_series(rc, pts, with_alpha(color, 200), 1.2f, wave_env().join);
    if (mark >= 0 && static_cast<std::size_t>(mark) < n &&
        std::isfinite(ys[static_cast<std::size_t>(mark)])) {
        const float mx = r.x + static_cast<float>(mark) *
                                   (r.width - 1.0f) /
                                   static_cast<float>(n - 1u);
        rc.fill_circle({mx, py(ys[static_cast<std::size_t>(mark)])}, 2.2f,
                       color);
    }
}

// The frame geometry plus the range pairs the interaction pass works
// on: home (the auto fit - the outermost view) and the effective view
// (the manual window riding over it), per spine - x, the left y and
// (stage 6) the right y. The input pass mutates the effective pair;
// the draw pass reads it. wx/wy/wy1 map screen px to data through the
// CURRENT effective view of their own spine.
struct PlotFrame {
    float fx = 0.0f, fy = 0.0f, iw = 0.0f, ih = 0.0f;
    float mr = kMarginRight;       // the right margin (wider with an axis)
    bool has_right = false;        // a right (current) spine exists
    ws::circsim::PlotRange xr{};   // home x
    ws::circsim::PlotRange yr{};   // home y, left (V)
    ws::circsim::PlotRange yr1{};  // home y, right (A) - sane-empty when absent
    ws::circsim::PlotRange vxr{};  // effective x
    ws::circsim::PlotRange vyr{};  // effective y, left
    ws::circsim::PlotRange vyr1{}; // effective y, right

    [[nodiscard]] double wx(float px) const {
        return vxr.lo + (static_cast<double>(px) - fx) / iw *
                            (vxr.hi - vxr.lo);
    }
    [[nodiscard]] double wy(float py) const {
        return vyr.hi - (static_cast<double>(py) - fy) / ih *
                            (vyr.hi - vyr.lo);
    }
    [[nodiscard]] double wy1(float py) const {
        return vyr1.hi - (static_cast<double>(py) - fy) / ih *
                             (vyr1.hi - vyr1.lo);
    }
};

// One pointer frame over the plot (stage 5): the wheel zoom (its own
// wheel claim - the innermost rect beats the enclosing scroll
// panel's), the rubber-band box zoom in the frame, the axis-drag
// zooms on the two strips, the middle/space pan, the double-click
// reset, and the right-click cancel. The Schematic panel's idioms:
// raw InputFrame edges gated on claims_open, a drag keeps running
// wherever the pointer goes once armed, and every drag rebases from
// its press-time capture each frame so a cancel restores the view
// exactly and a drag never drifts.
void handle_plot_input(Editor& ed, gui::GuiContext& gui, PlotFrame& pf) {
    using ws::circsim::clamp_view;
    using ws::circsim::pan_range;
    using ws::circsim::zoom_range;

    ResultsCache& cache = ed.results;
    PlotGesture& g = cache.gesture;
    const ws::input::InputFrame& in = gui.input();

    // (The manual view is per table: sync_view dropped it on the switch,
    // before any plot - or the lack of one - was drawn.)

    // The effective view: the manual windows clamped into their home,
    // or home itself - x and the left spine exactly as stage 5 left
    // them; the right spine (stage 6) additionally refuses a degenerate
    // window (span 0 can survive a clamp when the axis membership
    // changed under a stored view), because a zero-span spine cannot
    // map a single pixel.
    pf.vxr = cache.view.active
                 ? clamp_view({cache.view.x_lo, cache.view.x_hi}, pf.xr)
                 : pf.xr;
    pf.vyr = cache.view.active
                 ? clamp_view({cache.view.y_lo, cache.view.y_hi}, pf.yr)
                 : pf.yr;
    pf.vyr1 = pf.yr1;
    if (pf.has_right && cache.view.active) {
        const ws::circsim::PlotRange c =
            clamp_view({cache.view.y1_lo, cache.view.y1_hi}, pf.yr1);
        if (c.hi > c.lo) {
            pf.vyr1 = c;
        }
    }

    // The claimable rect: frame + all three strips, so the wheel works
    // over the axes too. The innermost rect beats the scroll panel's
    // claim; the win settles one frame later (the gui's contract),
    // which is why the consumption gates on wheel_won - the first
    // notch after arriving over the plot still scrolls the panel.
    const gui::Rect claimable{
        pf.fx - kMarginLeft, pf.fy - kMarginTop,
        pf.iw + kMarginLeft + pf.mr, pf.ih + kMarginTop + kMarginBottom};
    gui.register_wheel_claim(claimable, &cache.view);

    const bool in_frame =
        in.mouse_x >= pf.fx && in.mouse_x < pf.fx + pf.iw &&
        in.mouse_y >= pf.fy && in.mouse_y < pf.fy + pf.ih;
    const bool on_x_axis =
        in.mouse_x >= pf.fx && in.mouse_x < pf.fx + pf.iw &&
        in.mouse_y >= pf.fy + pf.ih &&
        in.mouse_y < pf.fy + pf.ih + kMarginBottom;
    const bool on_y_axis =
        in.mouse_x >= pf.fx - kMarginLeft && in.mouse_x < pf.fx &&
        in.mouse_y >= pf.fy && in.mouse_y < pf.fy + pf.ih;
    // The right spine's strip (stage 6): right of the frame, inside
    // its height - the amp window's drag handle. It exists only when
    // the second spine does.
    const bool on_y1_axis =
        pf.has_right && in.mouse_x >= pf.fx + pf.iw &&
        in.mouse_x < pf.fx + pf.iw + pf.mr && in.mouse_y >= pf.fy &&
        in.mouse_y < pf.fy + pf.ih;
    const bool over = in_frame || on_x_axis || on_y_axis || on_y1_axis;

    // The double-click clock: runs while the pointer is over the plot,
    // resets on every press there, dies when it leaves - the "two
    // clicks, same spot, soon" detector the reset rides.
    if (over) {
        g.click_clock += in.dt_seconds;
    } else {
        g.click_clock = 100.0f;
    }

    if (!gui.claims_open()) {
        return;  // a modal veil freezes the plot, the canvas's rule
    }

    // The right press cancels the in-flight gesture, restoring the
    // press-time view exactly - both spines included (stage 6).
    if (g.kind != PlotGesture::Kind::None &&
        in.mouse_pressed[ws::input::mouse::kRight] != 0) {
        cache.view.active = g.was_active;
        if (g.was_active) {
            cache.view.x_lo = g.x_lo;
            cache.view.x_hi = g.x_hi;
            cache.view.y_lo = g.y_lo;
            cache.view.y_hi = g.y_hi;
            cache.view.y1_lo = g.y1_lo;
            cache.view.y1_hi = g.y1_hi;
        }
        g.kind = PlotGesture::Kind::None;
        return;
    }

    // The wheel: zoom x toward the cursor and each y spine toward its
    // own mapped anchor (the same screen point, mapped per spine -
    // that is what both spines zooming "toward the cursor" means when
    // they disagree about what the cursor sits on) at the canvas's
    // 1.15-per-notch factor - but never mid-gesture (the band's press
    // point is captured in the view it started in).
    if (in_frame && in.scroll_dy != 0.0f &&
        g.kind == PlotGesture::Kind::None &&
        gui.wheel_won(&cache.view)) {
        if (!cache.view.active) {
            cache.view = PlotView{true, pf.vxr.lo, pf.vxr.hi,
                                  pf.vyr.lo, pf.vyr.hi,
                                  pf.vyr1.lo, pf.vyr1.hi};
        }
        const double wx = pf.wx(in.mouse_x);
        const double wy = pf.wy(in.mouse_y);
        const double wy1 = pf.wy1(in.mouse_y);
        const double f =
            in.scroll_dy > 0.0f
                ? ws::plotmath::kWheelFactor
                : 1.0 / ws::plotmath::kWheelFactor;
        const ws::circsim::PlotRange nx =
            zoom_range({cache.view.x_lo, cache.view.x_hi}, pf.xr, wx, f);
        const ws::circsim::PlotRange ny =
            zoom_range({cache.view.y_lo, cache.view.y_hi}, pf.yr, wy, f);
        const ws::circsim::PlotRange ny1 =
            zoom_range({cache.view.y1_lo, cache.view.y1_hi}, pf.yr1,
                       wy1, f);
        cache.view.x_lo = nx.lo;
        cache.view.x_hi = nx.hi;
        cache.view.y_lo = ny.lo;
        cache.view.y_hi = ny.hi;
        cache.view.y1_lo = ny1.lo;
        cache.view.y1_hi = ny1.hi;
        pf.vxr = nx;
        pf.vyr = ny;
        pf.vyr1 = pf.has_right ? ny1 : pf.vyr1;
    }

    // The pan: middle-drag, or space+left-drag (the Schematic panel's
    // rule). Content follows the cursor: dragging right slides the
    // window left, dragging down slides it up (the y flip). The same
    // pixel shift maps through each spine's own span (stage 6) - the
    // two y windows slide by different data amounts and stay in step
    // on screen.
    const bool space_down = in.key_down[ws::input::keys::kSpace] != 0;
    const bool pan_held =
        in.mouse_down[ws::input::mouse::kMiddle] != 0 ||
        (space_down && in.mouse_down[ws::input::mouse::kLeft] != 0);
    if (pan_held && (in_frame || g.kind == PlotGesture::Kind::Pan)) {
        if (g.kind != PlotGesture::Kind::Pan) {
            g.kind = PlotGesture::Kind::Pan;
            g.from_x = in.mouse_x;
            g.from_y = in.mouse_y;
            g.x_lo = pf.vxr.lo;
            g.x_hi = pf.vxr.hi;
            g.y_lo = pf.vyr.lo;
            g.y_hi = pf.vyr.hi;
            g.y1_lo = pf.vyr1.lo;
            g.y1_hi = pf.vyr1.hi;
            g.was_active = cache.view.active;
            if (!cache.view.active) {
                cache.view = PlotView{true, pf.vxr.lo, pf.vxr.hi,
                                      pf.vyr.lo, pf.vyr.hi,
                                      pf.vyr1.lo, pf.vyr1.hi};
            }
        }
        const double dx =
            -(static_cast<double>(in.mouse_x - g.from_x) /
              static_cast<double>(pf.iw)) *
            (g.x_hi - g.x_lo);
        const double frac =
            static_cast<double>(in.mouse_y - g.from_y) /
            static_cast<double>(pf.ih);
        const double dy0 = frac * (g.y_hi - g.y_lo);
        const double dy1 = frac * (g.y1_hi - g.y1_lo);
        const ws::circsim::PlotRange nx =
            pan_range({g.x_lo, g.x_hi}, pf.xr, dx);
        const ws::circsim::PlotRange ny =
            pan_range({g.y_lo, g.y_hi}, pf.yr, dy0);
        const ws::circsim::PlotRange ny1 =
            pan_range({g.y1_lo, g.y1_hi}, pf.yr1, dy1);
        cache.view.x_lo = nx.lo;
        cache.view.x_hi = nx.hi;
        cache.view.y_lo = ny.lo;
        cache.view.y_hi = ny.hi;
        cache.view.y1_lo = ny1.lo;
        cache.view.y1_hi = ny1.hi;
        pf.vxr = nx;
        pf.vyr = ny;
        if (pf.has_right) {
            pf.vyr1 = ny1;
        }
        return;  // a pan frame owns the pointer
    }
    if (g.kind == PlotGesture::Kind::Pan && !pan_held) {
        g.kind = PlotGesture::Kind::None;
    }

    // The left-button gestures run to release wherever the pointer
    // goes (the press owns it): the band commits its box on release,
    // the axis zooms land live as the drag moves.
    if (g.kind == PlotGesture::Kind::Band ||
        g.kind == PlotGesture::Kind::ZoomX ||
        g.kind == PlotGesture::Kind::ZoomY) {
        if (in.mouse_down[ws::input::mouse::kLeft] == 0) {
            const bool was_band = g.kind == PlotGesture::Kind::Band;
            bool committed = false;
            if (was_band &&
                std::fabs(in.mouse_x - g.from_x) >=
                    ws::plotmath::kBandMinPx &&
                std::fabs(in.mouse_y - g.from_y) >=
                    ws::plotmath::kBandMinPx) {
                // The box's corners map through each spine's OWN
                // transform (stage 6): one screen band, three windows
                // - x, the left spine's volts, the right spine's amps
                // - each clamped into its own home.
                const double x0 = pf.wx(g.from_x);
                const double x1 = pf.wx(in.mouse_x);
                const double y0 = pf.wy(g.from_y);
                const double y1 = pf.wy(in.mouse_y);
                const double y10 = pf.wy1(g.from_y);
                const double y11 = pf.wy1(in.mouse_y);
                const ws::circsim::PlotRange bx =
                    clamp_view({std::min(x0, x1), std::max(x0, x1)},
                               pf.xr);
                const ws::circsim::PlotRange by =
                    clamp_view({std::min(y0, y1), std::max(y0, y1)},
                               pf.yr);
                const ws::circsim::PlotRange by1 =
                    clamp_view({std::min(y10, y11),
                                std::max(y10, y11)}, pf.yr1);
                cache.view = PlotView{true, bx.lo, bx.hi, by.lo, by.hi,
                                      by1.lo, by1.hi};
                pf.vxr = bx;
                pf.vyr = by;
                if (pf.has_right) {
                    pf.vyr1 = by1;
                }
                committed = true;
            }
            g.kind = PlotGesture::Kind::None;
            if (!was_band || committed) {
                return;
            }
            // A tiny band's release falls through so the second press
            // of a double click still lands on the arming block below.
        } else {
            if (g.kind == PlotGesture::Kind::ZoomX) {
                // Dragging right stretches the axis: zoom in.
                const double f =
                    std::exp((static_cast<double>(in.mouse_x) - g.from_x) *
                             ws::plotmath::kStripExp);
                const ws::circsim::PlotRange nx =
                    zoom_range({g.x_lo, g.x_hi}, pf.xr, g.anchor_x, f);
                cache.view.active = true;
                cache.view.x_lo = nx.lo;
                cache.view.x_hi = nx.hi;
                pf.vxr = nx;
            } else if (g.kind == PlotGesture::Kind::ZoomY &&
                       g.zoom_axis == 0) {
                // Dragging up on the left strip zooms the volt window
                // in (pulling the range open reads like pulling the
                // axis up).
                const double f =
                    std::exp((g.from_y - static_cast<double>(in.mouse_y)) *
                             ws::plotmath::kStripExp);
                const ws::circsim::PlotRange ny =
                    zoom_range({g.y_lo, g.y_hi}, pf.yr, g.anchor_y, f);
                cache.view.active = true;
                cache.view.y_lo = ny.lo;
                cache.view.y_hi = ny.hi;
                pf.vyr = ny;
            } else if (g.kind == PlotGesture::Kind::ZoomY) {
                // The right strip's drag (stage 6): the amp window's
                // own zoom, same gesture language, its own anchor.
                const double f =
                    std::exp((g.from_y - static_cast<double>(in.mouse_y)) *
                             ws::plotmath::kStripExp);
                const ws::circsim::PlotRange ny1 =
                    zoom_range({g.y1_lo, g.y1_hi}, pf.yr1, g.anchor_y1,
                               f);
                cache.view.active = true;
                cache.view.y1_lo = ny1.lo;
                cache.view.y1_hi = ny1.hi;
                if (pf.has_right) {
                    pf.vyr1 = ny1;
                }
            }
            return;  // a gesture frame owns the pointer
        }
    }

    // Arming: the second click of a pair inside the frame resets the
    // view; the first click starts the band (frame) or an axis zoom
    // (strips - the left one owns the volt window, the right one the
    // amp window, stage 6).
    if (in.mouse_pressed[ws::input::mouse::kLeft] != 0 && over) {
        if (in_frame &&
            g.click_clock < ws::plotmath::kDoubleClickSecs &&
            std::fabs(in.mouse_x - g.click_x) <
                ws::plotmath::kDoubleClickPx &&
            std::fabs(in.mouse_y - g.click_y) <
                ws::plotmath::kDoubleClickPx) {
            cache.view = PlotView{};
            pf.vxr = pf.xr;
            pf.vyr = pf.yr;
            pf.vyr1 = pf.yr1;
            g.click_clock = 100.0f;
            return;
        }
        g.click_clock = 0.0f;
        g.click_x = in.mouse_x;
        g.click_y = in.mouse_y;
        g.from_x = in.mouse_x;
        g.from_y = in.mouse_y;
        g.x_lo = pf.vxr.lo;
        g.x_hi = pf.vxr.hi;
        g.y_lo = pf.vyr.lo;
        g.y_hi = pf.vyr.hi;
        g.y1_lo = pf.vyr1.lo;
        g.y1_hi = pf.vyr1.hi;
        g.was_active = cache.view.active;
        if (on_x_axis) {
            g.kind = PlotGesture::Kind::ZoomX;
            g.anchor_x = pf.wx(in.mouse_x);
            // The axis zooms write one axis over the other's landed
            // window: seed the manual view with the effective one
            // (the wheel and the pan seed the same way).
            if (!cache.view.active) {
                cache.view = PlotView{true, pf.vxr.lo, pf.vxr.hi,
                                      pf.vyr.lo, pf.vyr.hi,
                                      pf.vyr1.lo, pf.vyr1.hi};
            }
        } else if (on_y_axis) {
            g.kind = PlotGesture::Kind::ZoomY;
            g.zoom_axis = 0;
            g.anchor_y = pf.wy(in.mouse_y);
            if (!cache.view.active) {
                cache.view = PlotView{true, pf.vxr.lo, pf.vxr.hi,
                                      pf.vyr.lo, pf.vyr.hi,
                                      pf.vyr1.lo, pf.vyr1.hi};
            }
        } else if (on_y1_axis) {
            g.kind = PlotGesture::Kind::ZoomY;
            g.zoom_axis = 1;
            g.anchor_y1 = pf.wy1(in.mouse_y);
            if (!cache.view.active) {
                cache.view = PlotView{true, pf.vxr.lo, pf.vxr.hi,
                                      pf.vyr.lo, pf.vyr.hi,
                                      pf.vyr1.lo, pf.vyr1.hi};
            }
        } else if (in_frame) {
            g.kind = PlotGesture::Kind::Band;  // the box lands at release
        }
    }
}

void draw_plot(Editor& ed, gui::GuiContext& gui,
               gui::LayoutCursor& layout, const gui::ChromeTheme& theme,
               const ws::spice::Table& t, const char* x_name) {
    const gui::Rect plot =
        layout.next(layout.remaining_width(), kPlotHeight);

    // The two-axis split (stage 6) FIRST: whether the visible signals
    // earn a right spine decides the frame's right margin, so it is
    // plot geometry, not a draw detail. The classifier's flags and
    // every column's finite envelope are per-table constants - they
    // ride the stats cache (ensure_series_stats built this table's)
    // instead of the per-frame classify walk plus the full-column
    // scan per visible signal the stage-7 code ran.
    const std::vector<ResultsCache::SeriesStats>& stats = ed.results.stats;
    bool has_right = false;
    for (std::size_t i = 0; i < t.signals.size(); ++i) {
        if (i < ed.results.visible.size() &&
            ed.results.visible[i] != 0u && i < stats.size() &&
            stats[i].right) {
            has_right = true;
            break;
        }
    }
    const float mr = has_right ? kMarginRightAxis : kMarginRight;
    const float iw = plot.width - kMarginLeft - mr;
    const float ih = plot.height - kMarginTop - kMarginBottom;
    if (iw < ws::plotmath::kMinInnerW || ih < ws::plotmath::kMinInnerH) {
        return;  // too narrow to be worth a frame
    }
    const float fx = plot.x + kMarginLeft;
    const float fy = plot.y + kMarginTop;

    // The x axis: the analysis's own (step axes skipped), or the
    // sample index when the table has none.
    const std::size_t x_index =
        t.sweep_axes.empty()
            ? 0u
            : std::min(t.step_axes, t.sweep_axes.size() - 1u);
    const std::span<const double> xs = t.axis(x_index);
    const bool by_index = xs.empty();
    const std::size_t n = t.row_count();
    if (n == 0u) {
        return;
    }
    // The axis's sortedness is a per-table constant of the run (the
    // axis data is immutable once delivered), so it rides the cache
    // keyed to the table (ResultsCache::x_sorted_for) instead of the
    // per-frame walk strictly_increasing used to cost - the same key
    // shape `visible` and `view` keep. A delivery resets the key
    // (main.cpp's block beside visible_for): a same-indexed table of
    // a new run is a different axis.
    if (ed.results.x_sorted_for != ed.results.table) {
        ed.results.x_sorted =
            !by_index && ws::plotmath::strictly_increasing(xs);
        ed.results.x_sorted_for = ed.results.table;
    }
    // Stage 9: the axis's monotone runs, the same per-table constant
    // `x_sorted` is (same key shape, reset beside it on a delivery).
    // A sorted axis answers one run; a stepped run's repeating inner
    // axis answers one per pass - the family the series loop overlays.
    if (ed.results.x_runs_for != ed.results.table) {
        ed.results.x_runs = ws::circsim::split_axis_runs(xs);
        ed.results.x_runs_for = ed.results.table;
    }

    // The home ranges: each y spine fits ITS OWN visible company
    // (stage 6 - the volts on the left, the amps on the right), x
    // over the axis (or the index run); padded by plot's expand_range
    // on all three. Home is the outermost view - every manual window
    // clamps inside its own spine's home.
    double y_lo = std::numeric_limits<double>::infinity();
    double y_hi = -std::numeric_limits<double>::infinity();
    double y1_lo = std::numeric_limits<double>::infinity();
    double y1_hi = -std::numeric_limits<double>::infinity();
    bool any_visible = false;
    double x_lo = 0.0;
    double x_hi = static_cast<double>(n - 1u);
    if (!by_index) {
        // The runs' union envelope (stage 9): for a sorted axis it is
        // the old front/back (a monotone run's ends ARE its extremes);
        // for a step family it spans every pass's extent, where
        // front/back would clip any pass longer than the last one.
        // An axis with no finite sample keeps the index-run fallback.
        if (ed.results.x_runs.finite) {
            x_lo = ed.results.x_runs.lo;
            x_hi = ed.results.x_runs.hi;
        }
    }
    for (std::size_t i = 0; i < t.signals.size(); ++i) {
        if (i >= ed.results.visible.size() || ed.results.visible[i] == 0u) {
            continue;
        }
        any_visible = true;
        // The cached finite envelope - the same min/max the per-frame
        // scan below this block used to re-derive over every sample
        // of every visible column, read here in O(1).
        const ResultsCache::SeriesStats& st =
            i < stats.size() ? stats[i] : ResultsCache::SeriesStats{};
        if (!st.finite) {
            continue;
        }
        if (st.right) {
            y1_lo = std::min(y1_lo, st.lo);
            y1_hi = std::max(y1_hi, st.hi);
        } else {
            y_lo = std::min(y_lo, st.lo);
            y_hi = std::max(y_hi, st.hi);
        }
    }
    if (y_lo > y_hi) {
        y_lo = 0.0;  // nothing visible on the left: an empty-but-sane frame
        y_hi = 1.0;
    }
    if (y1_lo > y1_hi) {
        y1_lo = 0.0;  // same sane-empty answer for the right spine
        y1_hi = 1.0;
    }

    PlotFrame pf;
    pf.fx = fx;
    pf.fy = fy;
    pf.iw = iw;
    pf.ih = ih;
    pf.mr = mr;
    pf.has_right = has_right;
    pf.xr = ws::circsim::expand_range(x_lo, x_hi);
    pf.yr = ws::circsim::expand_range(y_lo, y_hi);
    pf.yr1 = ws::circsim::expand_range(y1_lo, y1_hi);
    handle_plot_input(ed, gui, pf);  // the hands; pf carries the effective view

    // The mappings, in double: the series loop subtracts the frame origin
    // from these (frame-local points for the cached geometry) before the
    // float cast, so the screen-space forms below are the same numbers
    // they always were.
    const auto sx_d = [&](double v) {
        return fx + (v - pf.vxr.lo) / (pf.vxr.hi - pf.vxr.lo) * iw;
    };
    const auto sy_d = [&](double v) {
        return fy + (pf.vyr.hi - v) / (pf.vyr.hi - pf.vyr.lo) * ih;
    };
    const auto sy1_d = [&](double v) {
        return fy + (pf.vyr1.hi - v) / (pf.vyr1.hi - pf.vyr1.lo) * ih;
    };
    const auto sx = [&](double v) { return static_cast<float>(sx_d(v)); };
    const auto sy = [&](double v) { return static_cast<float>(sy_d(v)); };
    const auto sy1 = [&](double v) { return static_cast<float>(sy1_d(v)); };
    // A series maps through its OWN spine (stage 6): the flag is the
    // classifier's cached answer, the visibility gate the caller
    // already ran.
    const auto sy_of_d = [&](std::size_t i, double v) {
        return i < stats.size() && stats[i].right ? sy1_d(v) : sy_d(v);
    };
    const auto sy_of = [&](std::size_t i, double v) {
        return static_cast<float>(sy_of_d(i, v));
    };

    canvas::Canvas2D& rc = ed.results_draw_canvas();
    rc.set_view_scale(1.0f);  // identity: local == screen

    // --- the card: the plot sits on the same canvas-colored surface the
    // schematic does, so a chart reads as a chart and not as lines drawn
    // straight on the panel face.
    rc.fill_rounded_rect(fx, fy, iw, ih, 3.0f, theme.canvas_bg);

    // --- the frame
    Paint frame_paint;
    frame_paint.width = 1.0f;
    frame_paint.color = gui::dim(theme.text, 0.35f);
    const Point quad[4] = {{fx, fy}, {fx + iw, fy}, {fx + iw, fy + ih},
                           {fx, fy + ih}};
    rc.stroke_polyline(quad, 4, frame_paint, true);

    // --- the grid + tick labels (over the EFFECTIVE view - a manual
    // window relabels its own axis)
    const std::vector<double> x_ticks =
        ws::circsim::nice_ticks(pf.vxr.lo, pf.vxr.hi, 6u);
    const std::vector<double> y_ticks =
        ws::circsim::nice_ticks(pf.vyr.lo, pf.vyr.hi, 5u);
    Paint grid_paint;
    grid_paint.width = 1.0f;
    grid_paint.color = gui::dim(theme.text, 0.12f);
    const ws::ui::r2d::Font* font = theme.font != nullptr ? theme.font
                                                          : ed.font;
    const bool can_label = font != nullptr && font->line_height() > 0.0f;
    // The axis ink: neutral, unless TWO spines are drawn and a spine
    // carries exactly one visible series - then it wears that series'
    // color (V in the red trace's red, A in the blue's), so which axis
    // belongs to which trace reads without opening the legend.
    std::uint32_t left_ink = gui::dim(theme.text, 0.6f);
    std::uint32_t right_ink = left_ink;
    if (has_right) {
        int left_n = 0;
        int right_n = 0;
        std::size_t left_i = 0;
        std::size_t right_i = 0;
        for (std::size_t i = 0; i < t.signals.size(); ++i) {
            if (i < ed.results.visible.size() &&
                ed.results.visible[i] != 0u && i < stats.size()) {
                if (stats[i].right) {
                    ++right_n;
                    right_i = i;
                } else {
                    ++left_n;
                    left_i = i;
                }
            }
        }
        if (left_n == 1) {
            left_ink = gui::dim(series_color(left_i), 0.92f);
        }
        if (right_n == 1) {
            right_ink = gui::dim(series_color(right_i), 0.92f);
        }
    }
    for (double tick : x_ticks) {
        const float px = sx(tick);
        if (px < fx || px > fx + iw) {
            continue;
        }
        rc.stroke_line({px, fy}, {px, fy + ih}, grid_paint);
        if (can_label) {
            const std::string label = ws::circsim::format_eng(tick);
            const float w = rc.measure_text(label.c_str(), *font);
            (void)rc.draw_text(px - w * 0.5f, fy + ih + 2.0f,
                               label.c_str(), *font,
                               gui::dim(theme.text, 0.6f));
        }
    }
    for (double tick : y_ticks) {
        const float py = sy(tick);
        if (py < fy || py > fy + ih) {
            continue;
        }
        rc.stroke_line({fx, py}, {fx + iw, py}, grid_paint);
        if (can_label) {
            const std::string label = ws::circsim::format_eng(tick);
            const float w = rc.measure_text(label.c_str(), *font);
            (void)rc.draw_text(fx - w - 4.0f,
                               py - font->line_height() * 0.5f,
                               label.c_str(), *font, left_ink);
        }
    }
    // The right spine's ticks (stage 6): marks on the frame's right
    // edge and labels in the widened margin - no grid lines, the left
    // axis's rows already carry the plot's horizontal rails, and a
    // second set would fight the series for them.
    if (has_right) {
        const std::vector<double> y1_ticks =
            ws::circsim::nice_ticks(pf.vyr1.lo, pf.vyr1.hi, 5u);
        for (double tick : y1_ticks) {
            const float py = sy1(tick);
            if (py < fy || py > fy + ih) {
                continue;
            }
            rc.stroke_line({fx + iw, py}, {fx + iw + 3.0f, py},
                           grid_paint);
            if (can_label) {
                const std::string label = ws::circsim::format_eng(tick);
                (void)rc.draw_text(fx + iw + 4.0f,
                                   py - font->line_height() * 0.5f,
                                   label.c_str(), *font, right_ink);
            }
        }
    }
    // The zero rail: a brighter line where the left spine crosses 0,
    // so a signal's sign reads without counting ticks.
    if (pf.vyr.lo < 0.0 && pf.vyr.hi > 0.0) {
        Paint zero_paint;
        zero_paint.width = 1.0f;
        zero_paint.color = gui::dim(theme.text, 0.32f);
        rc.stroke_line({fx, sy(0.0)}, {fx + iw, sy(0.0)}, zero_paint);
    }
    // The x axis's name, quiet, inside the frame's top-left.
    if (can_label) {
        (void)rc.draw_text(fx + 5.0f, fy + 3.0f, x_name, *font,
                           gui::dim(theme.text, 0.45f));
    }
    // Everything unchecked: say so instead of showing a mystery frame.
    if (!any_visible && can_label) {
        const char* msg = "all signals hidden - tick one in the legend";
        const float w = rc.measure_text(msg, *font);
        (void)rc.draw_text(fx + (iw - w) * 0.5f,
                           fy + (ih - font->line_height()) * 0.5f, msg,
                           *font, gui::dim(theme.text, 0.5f));
    }

    // --- the hover index (before the series, so the readout rows
    // below see this frame's answer)
    const ws::input::InputFrame& in = gui.input();
    const bool hovering = gui.claims_open() &&
                          in.mouse_x >= fx && in.mouse_x < fx + iw &&
                          in.mouse_y >= fy && in.mouse_y < fy + ih;
    // The x axis's sortedness: the cached per-table answer (computed
    // at the top of the draw, keyed like `visible`).
    const bool x_sorted = ed.results.x_sorted;
    if (hovering) {
        const double wx =
            pf.vxr.lo + (static_cast<double>(in.mouse_x) - fx) / iw *
                            (pf.vxr.hi - pf.vxr.lo);
        if (by_index) {
            // The axis IS the index: round and clamp, no scan.
            ed.results.hover = static_cast<int>(std::clamp<long long>(
                std::llround(wx), 0, static_cast<long long>(n) - 1));
        } else {
            ed.results.hover =
                ws::plotmath::nearest_sample(xs, wx, x_sorted, n);
        }
    } else {
        ed.results.hover = -1;
    }

    // --- the series
    const std::size_t budget =
        std::max<std::size_t>(64u, static_cast<std::size_t>(iw));
    // The decimation cache's key (ResultsCache's frame-budget block):
    // the table (its delivery rides run_id), the x window the slice
    // bounds to, and the pixel budget. A miss - a table switch, a new
    // run, a gesture frame, a resize - unbuilt-s every keep WITHOUT
    // freeing their buffers (a pan rebuilds into the same storage
    // every frame it moves); a hit - the common idle frame - reuses
    // the lists verbatim and skips the per-signal decimation walk
    // entirely.
    ResultsCache& cache = ed.results;
    if (cache.decim_for != cache.table || cache.decim_run != cache.run_id ||
        cache.decim_budget != budget || cache.decim_lo != pf.vxr.lo ||
        cache.decim_hi != pf.vxr.hi ||
        cache.decim.size() != t.signals.size()) {
        cache.decim.resize(t.signals.size());
        for (ResultsCache::DecimKeep& dk : cache.decim) {
            dk.built = false;  // the idx buffers ride on (capacity kept)
        }
        cache.decim_for = cache.table;
        cache.decim_run = cache.run_id;
        cache.decim_lo = pf.vxr.lo;
        cache.decim_hi = pf.vxr.hi;
        cache.decim_budget = budget;
    }
    // One point buffer for every series of the frame (the canvas
    // consumes points synchronously, so nothing holds them past a
    // stroke) - the old code allocated two fresh vectors per signal
    // per frame.
    std::vector<Point>& pts = cache.scratch_pts;
    cache.geometry.resize(t.signals.size());
    auto* renderer = dynamic_cast<canvas::Renderer2DCanvas*>(&rc);
    // The falling runs' reversed views (build-time scratch only): the
    // decimator bucket-walks ASCENDING x, so a descending run is read
    // back to front, its keeps mapped home and re-sorted.
    std::vector<double> rev_x;
    std::vector<double> rev_y;
    // A frame the enclosing clip hides ENTIRELY draws nothing anyone can
    // see: a long legend runs the plot down past the dock's scroll
    // viewport, and every frame would still decimate, tessellate-or-hit
    // and submit every signal's ~2.8k quads for it (several times the
    // legend's own cost). Skip the series loop then. The caches are
    // untouched by the skip - the decimation key above updated either
    // way, and a geometry entry's key is exact - so the first frame the
    // plot scrolls back in is a hit when nothing moved. Everything below
    // the loop (crosshair, tooltip, playhead) reads the data directly.
    // No clip pushed (a bare layout, a test bench) shows everything.
    const bool series_shown = clip_shows(gui, gui::Rect{fx, fy, iw, ih});
    wave_prof_begin_frame();
    // The series live INSIDE the frame. The slice keeps one sample of
    // slack past each window edge (the stroke needs the neighbor to
    // cross the boundary), so in a zoomed view the boundary segments
    // run on past the frame - over the tick labels and the margins -
    // unless the canvas cuts them. The clip is a draw-time state both
    // backends honor (Renderer2D stamps the active clip into every
    // command, replayed quads included), so the cached screen-space
    // geometry is unaffected: it stays valid with or without it. One
    // balanced pair around the whole loop - every `continue` below
    // stays inside it.
    rc.push_clip(fx, fy, iw, ih);
    for (std::size_t i = 0; series_shown && i < t.signals.size(); ++i) {
        if (i >= ed.results.visible.size() || ed.results.visible[i] == 0u) {
            // A hidden signal's retained geometry is left alone: it was
            // not freed anyway (built = false kept the whole buffer
            // allocated, unusable), and the key is exact, so a re-show
            // with the view unchanged is a hit - while one after any
            // change (a zoom, a resize, the y fit moving with the
            // visible set) mismatches and rebuilds into the same
            // storage. Nothing a hide could make stale needs a flag.
            continue;
        }
        const std::span<const double> ys = t.signals[i].data;
        if (ys.empty()) {
            continue;
        }
        const auto prof_series_t0 = wave_now();
        WaveProf& prof = wave_prof();
        constexpr float kSeriesWidth = 2.0f;
        const std::uint32_t color = series_color(i);
        ResultsCache::SeriesGeometry* cached_geometry =
            renderer != nullptr ? &cache.geometry[i] : nullptr;
        ResultsCache::SeriesGeometryKey geometry_key;
        if (cached_geometry != nullptr) {
            const bool right_axis = i < stats.size() && stats[i].right;
            const ws::circsim::PlotRange yrange = right_axis ? pf.vyr1 : pf.vyr;
            geometry_key.run = cache.run_id;
            geometry_key.table = cache.table;
            geometry_key.decim_x_lo = cache.decim_lo;
            geometry_key.decim_x_hi = cache.decim_hi;
            geometry_key.decim_budget = cache.decim_budget;
            geometry_key.x_lo = pf.vxr.lo; geometry_key.x_hi = pf.vxr.hi;
            geometry_key.y_lo = yrange.lo; geometry_key.y_hi = yrange.hi;
            geometry_key.plot_w = plot.width; geometry_key.plot_h = plot.height;
            geometry_key.frame_w = iw; geometry_key.frame_h = ih;
            geometry_key.width = kSeriesWidth;
            geometry_key.join = wave_env().join;
            geometry_key.color = color;
            if (cached_geometry->built && cached_geometry->key == geometry_key) {
                const auto replay_t0 = wave_now();
                if (wave_env().prof != 0) ++prof.cache_hits;
                renderer->replay_quads(cached_geometry->buffer, fx, fy);
                if (wave_env().prof != 0) {
                    const double stroke_ms = wave_ms_since(replay_t0);
                    prof.stroke_ms += stroke_ms;
                    prof.prep_ms += wave_ms_since(prof_series_t0) - stroke_ms;
                    ++prof.series;
                }
                continue;  // no decimation walk, mapping, or tessellation
            }
            if (wave_env().prof != 0) ++prof.cache_misses;
        }
        ResultsCache::DecimKeep& dk = cache.decim[i];
        const auto x_at = [&](std::size_t k) {
            return by_index ? static_cast<double>(k)
                            : (k < xs.size() ? xs[k] : 0.0);
        };
        pts.clear();
        // The cached geometry is built FRAME-LOCAL (origin = the frame's
        // top-left) and replayed at (fx, fy), so a layout shift or a
        // scroll that only moves the frame never re-tessellates. The
        // uncached backends stroke in screen space as always (origin 0).
        const double ox = cached_geometry != nullptr ? double{fx} : 0.0;
        const double oy = cached_geometry != nullptr ? double{fy} : 0.0;
        const auto push = [&](std::size_t k) {
            if (k >= ys.size()) {
                return;
            }
            const double yv = ys[k];
            pts.push_back(Point{static_cast<float>(sx_d(x_at(k)) - ox),
                                std::isfinite(yv)
                                    ? static_cast<float>(sy_of_d(i, yv) - oy)
                                    : std::numeric_limits<float>::
                                          quiet_NaN()});
        };
        // The decimation window: the visible x slice (one sample of
        // slack each side), so a zoomed-in view spends the pixel
        // budget on the samples it shows. The auto view's padded home
        // spans all the data, so the slice is transparent there - one
        // code path, no special case.
        const auto slice = [&](std::span<const double> ax, std::size_t r0,
                               std::size_t r1) {
            const auto b0 = std::lower_bound(ax.begin() + r0,
                                             ax.begin() + r1, pf.vxr.lo);
            const auto b1 = std::upper_bound(ax.begin() + r0,
                                             ax.begin() + r1, pf.vxr.hi);
            const std::size_t i0 =
                b0 != ax.begin() + r0
                    ? static_cast<std::size_t>(b0 - ax.begin()) - 1u
                    : r0;
            const std::size_t i1 =
                b1 != ax.begin() + r1
                    ? static_cast<std::size_t>(b1 - ax.begin()) + 1u
                    : r1;
            return std::pair{i0, i1};
        };
        if (!dk.built) {
            dk.built = true;
            dk.runs.clear();
            if (by_index) {
                // The axisless table: one pseudo-run over the index,
                // the index envelope (decimate_minmax_index) its keep.
                ResultsCache::RunKeep rk;
                rk.i0 = 0;
                rk.i1 = std::min(n, ys.size());
                rk.idx = ws::circsim::decimate_minmax_index(
                    ys.subspan(0, rk.i1), budget);
                dk.runs.push_back(std::move(rk));
            } else {
                // The axis runs (stage 9): a sorted axis answers ONE
                // run and this is the sorted path as it always was; a
                // stepped run's repeating inner axis answers one run
                // per PASS, each decimated on its own - the family
                // overlay. The keep list is cached beside the window
                // and budget like the single-run answer always was,
                // and an idle frame maps it untouched.
                //
                // The passes overlay ONE window, so the pixel budget
                // is SHARED, not multiplied: each pass decimates to
                // its slice (budget / passes, floored at 64 so a
                // many-pass family stays legible). Handing every pass
                // the full budget cost budget x passes keeps - the
                // 24-pass scr_trigger shape this split fixes.
                const std::size_t passes =
                    ed.results.x_runs.runs.size() > 0u
                        ? ed.results.x_runs.runs.size()
                        : 1u;
                const std::size_t pass_budget =
                    passes > 1u
                        ? std::max<std::size_t>(64u, budget / passes)
                        : budget;
                for (const ws::circsim::AxisRun& run :
                     ed.results.x_runs.runs) {
                    const std::size_t r0 = std::min(run.begin, ys.size());
                    const std::size_t r1 = std::min(run.end, ys.size());
                    ResultsCache::RunKeep rk;
                    if (r1 > r0) {
                        if (run.rising) {
                            const auto [i0, i1] = slice(xs, r0, r1);
                            rk.i0 = i0;
                            rk.i1 = i1;
                            if (i1 > i0) {
                                rk.idx = ws::circsim::decimate_minmax(
                                    xs.subspan(i0, i1 - i0),
                                    ys.subspan(i0, i1 - i0), pass_budget);
                                // decimate_minmax answers positions
                                // RELATIVE to the span it was handed
                                // (the slice, starting at i0); the
                                // draw below pushes ABSOLUTE sample
                                // positions, so rebase here.
                                for (std::size_t& k : rk.idx) {
                                    k += i0;
                                }
                            }
                        } else {
                            // A falling run (a .dc walking its source
                            // down): decimate the REVERSED span - the
                            // ascending view the bucket walk needs -
                            // then map the keeps home and sort.
                            const std::size_t m = r1 - r0;
                            rev_x.resize(m);
                            rev_y.resize(m);
                            for (std::size_t j = 0; j < m; ++j) {
                                rev_x[j] = xs[r1 - 1u - j];
                                rev_y[j] = ys[r1 - 1u - j];
                            }
                            const auto [j0, j1] = slice(rev_x, 0u, m);
                            rk.i0 = r1 - j1;
                            rk.i1 = r1 - j0;
                            if (j1 > j0) {
                                const std::vector<std::size_t> rev =
                                    ws::circsim::decimate_minmax(
                                        std::span<const double>(
                                            rev_x.data() + j0,
                                            j1 - j0),
                                        std::span<const double>(
                                            rev_y.data() + j0,
                                            j1 - j0),
                                        pass_budget);
                                // `rev` is relative to the sub-span that
                                // starts at j0 in the reversed array,
                                // so the reversed position is j0 + j.
                                rk.idx.reserve(rev.size());
                                for (std::size_t j : rev) {
                                    rk.idx.push_back(r1 - 1u - (j0 + j));
                                }
                                std::sort(rk.idx.begin(), rk.idx.end());
                            }
                        }
                    }
                    dk.runs.push_back(std::move(rk));
                }
            }
        }
        // The draw: one polyline per run - the reset between two runs
        // is a BREAK (the NaN vertex stroke_series already knows), so
        // a family overlays its passes instead of chording them. An
        // empty idx draws the run's slice raw (it fits the budget);
        // an empty slice draws nothing.
        bool first_run = true;
        for (const ResultsCache::RunKeep& rk : dk.runs) {
            if (!first_run) {
                pts.push_back(Point{
                    std::numeric_limits<float>::quiet_NaN(),
                    std::numeric_limits<float>::quiet_NaN()});
            }
            first_run = false;
            if (rk.idx.empty()) {
                for (std::size_t k = rk.i0; k < rk.i1; ++k) {
                    push(k);
                }
            } else {
                for (std::size_t k : rk.idx) {
                    push(k);
                }
            }
        }
        const auto prof_stroke_t0 = wave_now();
        if (cached_geometry != nullptr) {
            tessellate_series(pts, color, kSeriesWidth, wave_env().join,
                              cached_geometry->buffer);
            cached_geometry->key = geometry_key;
            cached_geometry->built = true;
            renderer->replay_quads(cached_geometry->buffer, fx, fy);
        } else {
            // CommandListCanvas and other recording/test backends retain
            // their original command stream through the default no-op seam.
            stroke_series(rc, pts, color, kSeriesWidth, wave_env().join,
                          &prof.polylines, &prof.heap_polylines);
        }
        if (wave_env().prof != 0) {
            const double stroke_ms = wave_ms_since(prof_stroke_t0);
            prof.stroke_ms += stroke_ms;
            prof.prep_ms += wave_ms_since(prof_series_t0) - stroke_ms;
            ++prof.series;
            prof.points += pts.size();
            if (wave_env().prof >= 2) {
                if (wave_env().prof >= 3) {
                    CountingSink counting;
                    const auto t0 = WaveProf::Clock::now();
                    shadow_tessellate(pts, series_color(i), 2.0f,
                                      wave_env().join, counting);
                    prof.tess_ms += wave_ms_since(t0);
                    prof.quads += counting.count;
                } else {
                    static canvas::TessBuffer shadow;  // capacity is kept
                    shadow.clear();
                    const auto t0 = WaveProf::Clock::now();
                    shadow_tessellate(pts, series_color(i), 2.0f,
                                      wave_env().join, shadow);
                    prof.tess_ms += wave_ms_since(t0);
                    prof.quads += shadow.quad_count();
                }
            }
        }
    }
    rc.pop_clip();
    wave_prof_end_frame();

    // --- the crosshair + per-series markers at the hover sample
    if (ed.results.hover >= 0) {
        const std::size_t k = static_cast<std::size_t>(ed.results.hover);
        const double hx = by_index ? static_cast<double>(k)
                                   : (k < xs.size() ? xs[k] : 0.0);
        const float px = sx(hx);
        Paint cross;
        cross.width = 1.0f;
        cross.color = gui::dim(theme.text, 0.5f);
        cross.dash.count = 2;
        cross.dash.lengths[0] = 4.0f;
        cross.dash.lengths[1] = 3.0f;
        rc.stroke_line({px, fy}, {px, fy + ih}, cross);
        for (std::size_t i = 0; i < t.signals.size(); ++i) {
            if (i >= ed.results.visible.size() ||
                ed.results.visible[i] == 0u || k >= t.signals[i].data.size()) {
                continue;
            }
            const double yv = t.signals[i].data[k];
            if (std::isfinite(yv)) {
                rc.fill_circle({px, sy_of(i, yv)}, 3.0f, series_color(i));
            }
        }

        // The floating tooltip: x on top, then one colored row per
        // visible signal (capped, "+N more" past the cap). It flips to
        // the cursor's left near the right edge and stays inside the
        // frame; it hides while a gesture is in flight.
        if (can_label &&
            ed.results.gesture.kind == PlotGesture::Kind::None) {
            struct Row {
                std::string text;
                std::uint32_t color;  // 0 = no swatch
            };
            constexpr std::size_t kMaxRows = 8;
            std::vector<Row> rows;
            std::size_t overflow = 0;
            rows.push_back(Row{std::string(x_name) + " = " +
                                   ws::circsim::format_eng(hx, 5),
                               0u});
            for (std::size_t i = 0; i < t.signals.size(); ++i) {
                if (i >= ed.results.visible.size() ||
                    ed.results.visible[i] == 0u ||
                    k >= t.signals[i].data.size() ||
                    !std::isfinite(t.signals[i].data[k])) {
                    continue;
                }
                if (rows.size() > kMaxRows) {
                    ++overflow;
                    continue;
                }
                rows.push_back(Row{
                    t.signals[i].name + "  " +
                        with_unit(t.signals[i].data[k],
                                  unit_of(t.signals[i].name)),
                    series_color(i)});
            }
            if (overflow > 0u) {
                rows.push_back(
                    Row{"+" + std::to_string(overflow) + " more", 0u});
            }
            const float lh = font->line_height();
            float text_w = 0.0f;
            for (const Row& r : rows) {
                text_w = std::max(text_w,
                                  rc.measure_text(r.text.c_str(), *font));
            }
            const float bw = text_w + 26.0f;
            const float bh = lh * static_cast<float>(rows.size()) + 10.0f;
            float bx = px + 12.0f;
            if (bx + bw > fx + iw) {
                bx = px - 12.0f - bw;
            }
            bx = std::max(bx, fx);
            float by = fy + 6.0f;
            by = std::max(fy, std::min(by, fy + ih - bh));
            // Theme-aware (it used to be a hardcoded dark box, wrong on
            // the light chrome): a soft drop shadow, then the popup face.
            rc.fill_rounded_rect(bx, by + 3.0f, bw, bh, theme.control_radius(),
                                 gui::dim(theme.shadow, 0.6f));
            rc.fill_rounded_rect(bx, by, bw, bh, theme.control_radius(),
                                 gui::dim(theme.panel_bg, 0.96f));
            const Point tip[4] = {{bx, by}, {bx + bw, by},
                                  {bx + bw, by + bh}, {bx, by + bh}};
            Paint tip_border;
            tip_border.width = 1.0f;
            tip_border.color = theme.border_strong;
            rc.stroke_polyline(tip, 4, tip_border, true);
            for (std::size_t r = 0; r < rows.size(); ++r) {
                const float ty = by + 5.0f + lh * static_cast<float>(r);
                if (rows[r].color != 0u) {
                    rc.fill_circle({bx + 10.0f, ty + lh * 0.5f}, 3.0f,
                                   rows[r].color);
                }
                (void)rc.draw_text(
                    bx + 18.0f, ty, rows[r].text.c_str(), *font,
                    rows[r].color != 0u ? theme.text : theme.text_secondary);
            }
        }
    }

    // --- the playhead: the sweep table the canvas animates, swept
    // here too (patch 0012). The transport row below and the canvas
    // strip scrub the same playback.t - one clock, so the plot's
    // cursor and the schematic's LED glow can never disagree. The
    // table the clock rides (a .tran time axis or a .dc swept
    // source) only; a pointer zoomed away from the playhead simply
    // loses the line (the view is the truth, the line never
    // stretches to it).
    if (!by_index && ed.canvas_sweep_table() == &t) {
        const double ph = ed.playback.t;
        if (ph >= pf.vxr.lo && ph <= pf.vxr.hi) {
            const float px = sx(ph);
            Paint sweep;
            sweep.width = 1.5f;
            sweep.color = theme.control_on;
            rc.stroke_line({px, fy}, {px, fy + ih}, sweep);
            const Point cap[3] = {{px - 4.0f, fy},
                                  {px + 4.0f, fy},
                                  {px, fy + 6.0f}};
            rc.fill_polygon(cap, 3, theme.control_on);
        }
    }

    // --- the in-flight band + the manual-view hint -------------------
    const PlotGesture& g = ed.results.gesture;
    if (g.kind == PlotGesture::Kind::Band) {
        const float bx0 = std::min(g.from_x, in.mouse_x);
        const float bx1 = std::max(g.from_x, in.mouse_x);
        const float by0 = std::min(g.from_y, in.mouse_y);
        const float by1 = std::max(g.from_y, in.mouse_y);
        const Point box[4] = {{bx0, by0}, {bx1, by0}, {bx1, by1},
                              {bx0, by1}};
        const std::uint32_t accent = theme.control_on;
        rc.fill_polygon(box, 4, with_alpha(accent, 36));
        Paint band;
        band.width = 1.0f;
        band.color = with_alpha(accent, 200);
        rc.stroke_polyline(box, 4, band, true);
        if (can_label) {
            // The cursor reads the band exists for: the data-space
            // deltas of its two corners - dx on the sweep, dy on the
            // LEFT spine (the primary scale; the right spine's units
            // ride its own legend readouts).
            const double dx = std::fabs(pf.wx(in.mouse_x) -
                                        pf.wx(g.from_x));
            const double dy = std::fabs(pf.wy(in.mouse_y) -
                                        pf.wy(g.from_y));
            char readout[96];
            std::snprintf(readout, sizeof readout, "dx %s  dy %s",
                          ws::circsim::format_eng(dx).c_str(),
                          ws::circsim::format_eng(dy).c_str());
            (void)rc.draw_text(bx0 + 4.0f, by0 + 2.0f, readout, *font,
                               gui::dim(theme.text, 0.75f));
        }
    } else if (ed.results.view.active && can_label) {
        const char* hint = "double-click resets";
        const float w = rc.measure_text(hint, *font);
        // A pill under the words: a trace passing through the corner
        // used to strike the hint through ("doubleclick resets").
        rc.fill_rounded_rect(fx + iw - w - 11.0f, fy + 3.0f, w + 12.0f,
                             font->line_height() + 4.0f, 4.0f,
                             gui::dim(theme.panel_bg, 0.9f));
        (void)rc.draw_text(fx + iw - w - 5.0f, fy + 5.0f, hint, *font,
                           gui::dim(theme.text, 0.6f));
    }
}

// --- the value rows (.op tables, measurements) ----------------------------------

void draw_value_rows(Editor& ed, gui::LayoutCursor& layout,
                     const gui::ChromeTheme& theme,
                     const std::vector<ValueRow>& rows) {
    const ws::ui::r2d::Font* font =
        ed.font_mono != nullptr && !ed.font_mono->empty() ? ed.font_mono
                                                          : theme.font;
    if (font == nullptr || font->line_height() <= 0.0f) {
        // The fontless fallback: plain text rows.
        for (const ValueRow& r : rows) {
            const std::string line =
                r.name + " = " + with_unit(r.value, r.unit, 5);
            gui::text(layout, theme, line.c_str());
        }
        return;
    }
    // Two aligned columns - names left, values on a common edge - so a
    // long .op printout scans like a table instead of ragged "a = b" text.
    canvas::Canvas2D& rc = ed.results_draw_canvas();
    rc.set_view_scale(1.0f);
    float name_w = 0.0f;
    for (const ValueRow& r : rows) {
        name_w = std::max(name_w, rc.measure_text(r.name.c_str(), *font));
    }
    const float col = name_w + 14.0f;
    const float line_h = font->line_height() + 3.0f;
    for (const ValueRow& r : rows) {
        const gui::Rect row = layout.next(layout.remaining_width(), line_h);
        (void)ws::ui::r2d::draw_text(row.x, row.y, r.name.c_str(), *font,
                                     gui::dim(theme.text, 0.65f));
        const std::string value = with_unit(r.value, r.unit, 5);
        (void)ws::ui::r2d::draw_text(row.x + col, row.y, value.c_str(),
                                     *font, gui::dim(theme.text, 0.95f));
    }
}

// The sweep table's transport row (patch 0012): the SAME playback
// the canvas strip wears - play/pause, a scrub track, the axis
// readout and the rate chip. One clock: a scrub here animates the
// schematic, a scrub on the canvas sweeps this plot's playhead line,
// and the two strips can never disagree because there is only one
// field. Drawn only when the shown table IS the canvas sweep table
// (a .tran time axis or a .dc swept source) - the clock's units are
// that table's own, so no other table may drive it (a frequency
// sweep's row would write Hz into a seconds clock).
void draw_transport_row(Editor& ed, gui::GuiContext& gui,
                        gui::LayoutCursor& layout,
                        const gui::ChromeTheme& theme,
                        const ws::spice::Table& t) {
    if (ed.canvas_sweep_table() != &t) {
        return;  // the clock belongs to another table's axis
    }
    const ws::circsim::OverlayWindow w = ws::circsim::overlay_window(t);
    if (!(w.t1 > w.t0)) {
        return;  // a degenerate sweep has nothing to sweep
    }

    // Play/pause: a paused playhead at the run's end restarts (the
    // canvas strip's own rule - the settled state stays one press
    // away from the sweep).
    if (gui::button(gui, layout, theme,
                    ed.playback.playing ? "pause" : "play", 56.0f)) {
        if (!ed.playback.playing && ed.playback.t >= w.t1) {
            ed.playback.t = w.t0;
        }
        ed.playback.playing = !ed.playback.playing;
    }
    layout.same_line();

    // The scrub track: custom chrome over the strip's pointer rule -
    // a press inside arms, the drag owns the pointer until release.
    const float track_w =
        std::max(60.0f, layout.remaining_width() - 170.0f);
    const gui::Rect track = layout.next(track_w, 20.0f);
    const ws::input::InputFrame& in = gui.input();
    const auto frac_of = [&](float mx) {
        return std::clamp(
            (mx - track.x) / static_cast<double>(track.width), 0.0, 1.0);
    };
    const auto over_track = [&]() {
        return gui.claims_open() && in.mouse_x >= track.x &&
               in.mouse_x < track.x + track.width && in.mouse_y >= track.y &&
               in.mouse_y < track.y + track.height;
    };
    if (ed.results_scrub) {
        if (in.mouse_down[ws::input::mouse::kLeft] == 0) {
            ed.results_scrub = false;  // release: the drag lets go
        } else {
            ed.playback.t = ws::circsim::overlay_scrub(w, frac_of(in.mouse_x));
        }
    } else if (in.mouse_pressed[ws::input::mouse::kLeft] != 0 &&
               over_track()) {
        ed.results_scrub = true;
        ed.playback.t = ws::circsim::overlay_scrub(w, frac_of(in.mouse_x));
    }

    // The track's face: the rail, the played span, the knob - the
    // canvas strip's look, at the row's own scale.
    canvas::Canvas2D& rc = ed.results_draw_canvas();
    rc.set_view_scale(1.0f);
    const double frac =
        std::clamp((ed.playback.t - w.t0) / (w.t1 - w.t0), 0.0, 1.0);
    const float ty = track.y + track.height * 0.5f - 1.0f;
    const Point rail{track.x, ty};
    rc.fill_rects(&rail, 1, track.width, 2.0f, gui::dim(theme.text, 0.30f));
    const Point played{track.x, ty};
    rc.fill_rects(&played, 1, static_cast<float>(track.width * frac), 2.0f,
                  theme.control_on);
    rc.fill_circle(Point{track.x + static_cast<float>(track.width * frac),
                         track.y + track.height * 0.5f},
                   4.0f, theme.control_on);

    // The readout, then the rate chip (the ladder's cycle - the same
    // field the canvas chip walks). The axis's own spelling: seconds
    // for a .tran, "V1 = 3.4V" for a .dc sweep.
    layout.same_line();
    const std::string label =
        ws::circsim::overlay_axis_readout(t, ed.playback.t);
    gui::text(layout, theme, label.c_str());
    layout.same_line();
    if (gui::button(gui, layout, theme,
                    ws::circsim::overlay_rate_label(ed.playback.rate),
                    52.0f)) {
        ed.playback.rate = ws::circsim::overlay_rate_next(ed.playback.rate);
    }
}






}  // namespace

// E3's plot image: the SHOWN table's visible series rendered headless
// through RasterCanvas - the frame, the engineering-notation grid and
// tick labels, one polyline per RUN per visible signal (full
// resolution, no decimation - a PNG is written once, not drawn at
// 60 fps), the markers, and a legend row per series. Pure over its
// inputs so the headless suite can gate the bytes' shape (the
// RasterCanvas pixel seam is the test's). `visible` parallels
// t.signals (nullptr = all visible), `x_name` labels the axis.
// Public (results_panel.hpp) so the app's export wiring and the tests
// reach it.
//
// The one-shot LIVE HOME view (the PNG/live consistency contract):
// this is draw_plot's automatic fit, not a re-derivation - the same
// spine split (signal_y_axis over the visible columns), the same x
// envelope (split_axis_runs' union over every pass, where a
// front/back walk would clip any pass longer than the last), the
// same per-spine expand_range, the same hidden-signal exclusion, the
// same one-polyline-per-axis-run series shape with NaN break
// vertices between runs. What stays PNG's own: the margins' pixel
// sizes (a 1280x720 export has room the panel's flow rect does not),
// the embedded bitmap font, and the backend's rasterization. The
// export does NOT receive the interactive PlotView - the written
// contract is the full-data HOME view (the panel's fit-view answer),
// never the zoomed window; see results_panel.hpp's note.
[[nodiscard]] std::string render_plot_png(const ws::spice::Table& t,
                                          const std::uint8_t* visible,
                                          const char* x_name,
                                          const int* markers,
                                          std::size_t marker_count) {
    using ws::circsim::RasterCanvas;
    constexpr int kW = 1280;
    constexpr int kH = 720;
    constexpr double kML = 72.0, kMB = 48.0, kMT = 40.0;
    constexpr double kMR = 24.0, kMRAxis = 72.0;
    RasterCanvas rc(kW, kH, 0x1E2229u);

    const std::size_t n = t.row_count();
    const bool by_index = t.sweep_axes.empty();
    const std::span<const double> xs =
        by_index ? std::span<const double>{}
                 : t.axis(std::min(t.step_axes, t.sweep_axes.size() - 1u));
    const auto x_at = [&](std::size_t k) {
        return by_index ? static_cast<double>(k)
                        : (k < xs.size() ? xs[k] : 0.0);
    };

    // The visible set (the live fit's gate: a hidden column never
    // moves either spine) and the per-signal spine flags - the same
    // classifier the live plot's SeriesStats cache carries
    // (signal_y_axis over the signal's own name, computed once here
    // instead of cached: a one-shot export has no frame budget).
    std::vector<std::uint8_t> vis;
    std::vector<char> right;
    vis.reserve(t.signals.size());
    right.reserve(t.signals.size());
    bool has_right = false;
    for (std::size_t i = 0; i < t.signals.size(); ++i) {
        const bool shown =
            visible == nullptr || visible[i] != 0u;
        vis.push_back(shown ? 1u : 0u);
        const bool is_right =
            shown && ws::circsim::signal_y_axis(t.signals[i].name) ==
                         ws::circsim::PlotYAxis::Right;
        right.push_back(is_right ? 1 : 0);
        has_right = has_right || is_right;
    }

    // The x envelope: split_axis_runs' union over every monotone run
    // - the live plot's own x home (stage 9's rule: a family whose
    // passes differ in span fits its union, where a front/back walk
    // would clip any pass longer than the last). An axisless table
    // (or one with no finite x) falls back to the index run, exactly
    // the live path's shape.
    const ws::circsim::AxisRuns runs =
        by_index ? ws::circsim::AxisRuns{}
                 : ws::circsim::split_axis_runs(xs);
    double x_lo = 0.0;
    double x_hi = static_cast<double>(n > 0u ? n - 1u : 1u);
    if (!by_index && runs.finite) {
        x_lo = runs.lo;
        x_hi = runs.hi;
    }

    // Each y spine fits ITS OWN visible company (the live plot's
    // stage-6 rule): the left keeps the voltage columns, the right
    // the current ones - a mixed V/I table on one scale would flatten
    // itself into a lie. A spine with nothing finite keeps the
    // sane-empty 0/1 window (the live path's own guard), which
    // expand_range then opens around its magnitude.
    double y_lo = std::numeric_limits<double>::infinity();
    double y_hi = -std::numeric_limits<double>::infinity();
    double y1_lo = std::numeric_limits<double>::infinity();
    double y1_hi = -std::numeric_limits<double>::infinity();
    for (std::size_t i = 0; i < t.signals.size(); ++i) {
        if (i >= vis.size() || !vis[i] ||
            t.signals[i].data.size() != n) {
            continue;
        }
        for (double v : t.signals[i].data) {
            if (!std::isfinite(v)) {
                continue;
            }
            if (right[i]) {
                y1_lo = std::min(y1_lo, v);
                y1_hi = std::max(y1_hi, v);
            } else {
                y_lo = std::min(y_lo, v);
                y_hi = std::max(y_hi, v);
            }
        }
    }
    if (y_lo > y_hi) {
        y_lo = 0.0;  // nothing visible on the left: an empty-but-sane frame
        y_hi = 1.0;
    }
    if (y1_lo > y1_hi) {
        y1_lo = 0.0;  // same sane-empty answer for the right spine
        y1_hi = 1.0;
    }

    // The padding the live plot's own expand_range gives, all three
    // windows (a degenerate span opens around its magnitude - a
    // constant line still gets an axis - and non-finite answers the
    // sane-empty 0/1 frame).
    const ws::circsim::PlotRange px =
        ws::circsim::expand_range(x_lo, x_hi);
    const ws::circsim::PlotRange py =
        ws::circsim::expand_range(y_lo, y_hi);
    const ws::circsim::PlotRange py1 =
        ws::circsim::expand_range(y1_lo, y1_hi);

    // The margins: the right one widens for the right spine's label
    // strip exactly when a visible current column exists (the live
    // frame's own has_right rule); a V-only table draws the same
    // geometry it always did.
    const double mr = has_right ? kMRAxis : kMR;
    const double iw = kW - kML - mr;
    const double ih = kH - kMT - kMB;
    const auto sx = [&](double v) {
        return kML + (v - px.lo) / (px.hi - px.lo) * iw;
    };
    const auto sy = [&](double v) {
        return kMT + (py.hi - v) / (py.hi - py.lo) * ih;
    };
    const auto sy1 = [&](double v) {
        return kMT + (py1.hi - v) / (py1.hi - py1.lo) * ih;
    };
    // A series maps through its OWN spine (the live plot's sy_of):
    const auto sy_of = [&](std::size_t i, double v) {
        return right[i] ? sy1(v) : sy(v);
    };

    // The frame.
    rc.stroke_polyline({{kML, kMT}, {kML + iw, kMT}, {kML + iw, kMT + ih},
                        {kML, kMT + ih}},
                       1.0, 0x60666Fu);

    // The grid + tick labels (engineering notation, the shared
    // ladder): x below the frame, the left spine's on the left, and
    // - when the right spine exists - its own ladder's marks on the
    // frame's right edge and labels in the widened margin (the live
    // plot's own stage-6 shape: marks, not grid lines, so the two
    // ladders never fight over the horizontal rails).
    const std::vector<double> x_ticks =
        ws::circsim::nice_ticks(px.lo, px.hi, 8u);
    const std::vector<double> y_ticks =
        ws::circsim::nice_ticks(py.lo, py.hi, 6u);
    for (double tick : x_ticks) {
        const double pxs = sx(tick);
        if (pxs < kML || pxs > kML + iw) {
            continue;
        }
        rc.stroke_polyline({{pxs, kMT}, {pxs, kMT + ih}}, 1.0,
                           0x2A2F38u);
        rc.draw_text(ws::circsim::format_eng(tick, 4), pxs, kMT + ih + 8.0,
                     RasterCanvas::HAlign::Center,
                     RasterCanvas::VAlign::Top, 0xA8ADB8u);
    }
    for (double tick : y_ticks) {
        const double pys = sy(tick);
        if (pys < kMT || pys > kMT + ih) {
            continue;
        }
        rc.stroke_polyline({{kML, pys}, {kML + iw, pys}}, 1.0,
                           0x2A2F38u);
        rc.draw_text(ws::circsim::format_eng(tick, 4), kML - 8.0, pys,
                     RasterCanvas::HAlign::Right,
                     RasterCanvas::VAlign::Middle, 0xA8ADB8u);
    }
    if (has_right) {
        const std::vector<double> y1_ticks =
            ws::circsim::nice_ticks(py1.lo, py1.hi, 6u);
        for (double tick : y1_ticks) {
            const double pys = sy1(tick);
            if (pys < kMT || pys > kMT + ih) {
                continue;
            }
            rc.stroke_polyline(
                {{kML + iw, pys}, {kML + iw + 3.0, pys}}, 1.0,
                0x2A2F38u);
            rc.draw_text(ws::circsim::format_eng(tick, 4),
                         kML + iw + 8.0, pys,
                         RasterCanvas::HAlign::Left,
                         RasterCanvas::VAlign::Middle, 0xA8ADB8u);
        }
    }

    // The series: full resolution, ONE POLYLINE PER AXIS RUN - the
    // live plot's own series shape (stage 9). A run is a maximal
    // strictly-monotone span of the axis; the break between two runs
    // is a NaN vertex (the stroker's own line-break answer), so a
    // .step family overlays its passes instead of chording the reset
    // into an artificial diagonal, and a descending run (a .dc
    // walking its source down) draws its span in its own direction -
    // its x values still map through sx, so the pixels land where
    // the data lives. An axisless table is one pseudo-run over the
    // index. Non-finite Y values break the polyline inside a run
    // exactly as they always did.
    for (std::size_t i = 0; i < t.signals.size(); ++i) {
        if (i >= vis.size() || !vis[i] ||
            t.signals[i].data.size() != n) {
            continue;
        }
        const std::uint32_t color = series_color(i) >> 8u;
        const std::span<const double> ys = t.signals[i].data;
        // The runs to draw: the axis's own, or the single pseudo-run
        // of the index axis.
        ws::circsim::AxisRun index_run;
        index_run.begin = 0;
        index_run.end = n;
        index_run.rising = true;
        const std::span<const ws::circsim::AxisRun> sig_runs =
            by_index
                ? std::span<const ws::circsim::AxisRun>(&index_run, 1u)
                : std::span<const ws::circsim::AxisRun>(
                      runs.runs.data(), runs.runs.size());
        bool first_run = true;
        std::vector<std::pair<double, double>> run;
        for (const ws::circsim::AxisRun& r : sig_runs) {
            const std::size_t r0 = std::min(r.begin, ys.size());
            const std::size_t r1 = std::min(r.end, ys.size());
            if (r1 <= r0) {
                continue;
            }
            // The break between runs: a NaN vertex at the seam of
            // every pair, the live draw's own shape.
            if (!first_run && run.size() >= 2u) {
                rc.stroke_polyline(run, 2.0, color);
            }
            first_run = false;
            run.clear();
            for (std::size_t k = r0; k < r1; ++k) {
                const double yv = ys[k];
                if (std::isfinite(yv)) {
                    run.emplace_back(sx(x_at(k)), sy_of(i, yv));
                } else if (run.size() >= 2u) {
                    rc.stroke_polyline(run, 2.0, color);
                }
                if (!std::isfinite(yv)) {
                    run.clear();
                }
            }
        }
        if (run.size() >= 2u) {
            rc.stroke_polyline(run, 2.0, color);
        }
    }

    // The markers: a solid accent line each, with its x spelled.
    for (std::size_t mi = 0; mi < marker_count; ++mi) {
        const int k = markers[mi];
        if (k < 0 || static_cast<std::size_t>(k) >= n) {
            continue;
        }
        const double mx = x_at(static_cast<std::size_t>(k));
        rc.stroke_polyline({{sx(mx), kMT}, {sx(mx), kMT + ih}}, 1.0,
                           0x3E7ACBu);
        rc.draw_text(ws::circsim::format_eng(mx, 4), sx(mx), kMT + 4.0,
                     RasterCanvas::HAlign::Left, RasterCanvas::VAlign::Top,
                     0x8FB8E8u);
    }

    // The title and the axis name, then the legend along the bottom:
    // swatch + name, the panel's own legend order.
    rc.draw_text(analysis_name(t.analysis), kML, 12.0,
                 RasterCanvas::HAlign::Left, RasterCanvas::VAlign::Top,
                 0xE6E8ECu, 2);
    if (x_name != nullptr && x_name[0] != 0) {
        rc.draw_text(x_name, kML + iw, kMT + ih + 26.0,
                     RasterCanvas::HAlign::Right,
                     RasterCanvas::VAlign::Top, 0xA8ADB8u);
    }
    double lx = kML;
    constexpr double kLegendY = kH - 26.0;
    for (std::size_t i = 0; i < t.signals.size(); ++i) {
        if (i >= vis.size() || !vis[i]) {
            continue;
        }
        rc.fill_disc(lx + 4.0, kLegendY + 4.0, 4.0,
                     series_color(i) >> 8u);
        rc.draw_text(t.signals[i].name, lx + 14.0, kLegendY,
                     RasterCanvas::HAlign::Left, RasterCanvas::VAlign::Top,
                     0xD5D9E0u);
        lx += 28.0 + RasterCanvas::text_width(t.signals[i].name);
    }
    return rc.encode_png();
}

// E2: a legend row's signal name resolved onto the schematic thing it
// names, through the run's OWN back-map - the same maps the Problems
// panel locates through (the run's export, not a rebuilt one, so the
// answer matches the names the table carries even when the schematic
// has since moved). A v(net) whose net the map knows answers the Net
// target (a generated v(N001) included - that is the point); an
// i(part) answers the Part target; anything else (re()/im() pairs,
// onoise, a name the deck never spelled) answers Kind::None and the
// row draws no locate button at all - never a dead affordance.
[[nodiscard]] ws::circsim::DiagTarget locate_signal(
    const Editor& ed, const std::string& name) {
    using ws::circsim::DiagTarget;
    if (!ed.results.has || name.size() < 4u) {
        return DiagTarget{};
    }
    const std::size_t close = name.rfind(')');
    if (close == std::string::npos) {
        return DiagTarget{};
    }
    const bool is_v = name.rfind("v(", 0) == 0;
    const bool is_i = name.rfind("i(", 0) == 0;
    if (!is_v && !is_i) {
        return DiagTarget{};
    }
    const std::string inner =
        name.substr(2, close - 2u);
    if (inner.empty()) {
        return DiagTarget{};
    }
    if (is_v) {
        // v(net): the net the token names. node_net keys the DECK's
        // node token - exactly the name the engine's column spells.
        const auto it = ed.results.map.node_net.find(inner);
        if (it != ed.results.map.node_net.end()) {
            DiagTarget t;
            t.kind = DiagTarget::Kind::Net;
            t.net = it->second;
            return t;
        }
        return DiagTarget{};
    }
    // i(part): the element the deck named (a part's ref, or a
    // multi-card symbol's claimed name - both live in element_part).
    const auto it = ed.results.map.element_part.find(inner);
    if (it != ed.results.map.element_part.end()) {
        DiagTarget t;
        t.kind = DiagTarget::Kind::Part;
        t.part = it->second;
        return t;
    }
    return DiagTarget{};
}// --- the panel -----------------------------------------------------------------

void draw_results_panel(Editor& ed, gui::GuiContext& gui,
                        gui::LayoutCursor& layout,
                        const gui::ChromeTheme& theme) {
    if (ed.doc == nullptr || ed.schem() == nullptr) {
        gui::text(layout, theme, "No document open");
        return;
    }
    if (!ed.results.has) {
        gui::text(layout, theme,
                  "No results yet - run a simulation with Ctrl+Enter "
                  "(Circuit > Simulate)");
        return;
    }
    const ws::spice::Results& res = ed.results.run.results;
    if (res.tables.empty()) {
        gui::text(layout, theme,
                  "The run produced no results - see the Problems panel");
        return;
    }
    if (ed.results.table >= res.tables.size()) {
        ed.results.table = 0;
    }
    const ws::spice::Table& t = res.tables[ed.results.table];
    sync_visibility(ed, t);
    sync_view(ed.results);
    // The per-signal constants of this table (the finite envelopes,
    // the sparkline envelopes, the spine flags): one walk per
    // (run, table) - the frame-budget caches' first member. Both the
    // legend rows below and draw_plot read it.
    ensure_series_stats(ed, t);

    const bool stale = ed.results.version != ed.schem()->version();

    // --- the header: table combo + the export pair
    {
        std::vector<std::string> labels;
        labels.reserve(res.tables.size());
        for (const ws::spice::Table& table : res.tables) {
            labels.push_back(analysis_name(table.analysis));
        }
        std::vector<const char*> items;
        items.reserve(labels.size());
        for (const std::string& label : labels) {
            items.push_back(label.c_str());
        }
        FieldBuf& combo = ed.fields["results.table"];
        if (combo.stamp != ed.field_stamp) {
            combo.stamp = ed.field_stamp;
            combo.combo_open = false;
        }
        int picked = static_cast<int>(ed.results.table);
        // The picker FILLS its own line (negative width): the old
        // fixed 190px reservation squeezed the export pair into
        // "Export …" stubs at a narrow panel - the pair now flows on
        // its own line below, whole (B1's no-mid-word-cut rule).
        if (gui::combo(gui, layout, theme, "table", items.data(),
                       static_cast<int>(items.size()), picked,
                       combo.combo_open, -1.0f)) {
            if (picked >= 0 &&
                static_cast<std::size_t>(picked) < res.tables.size()) {
                const bool changed =
                    ed.results.table != static_cast<std::size_t>(picked);
                ed.results.table = static_cast<std::size_t>(picked);
                if (changed) {
                    // A different table may drive the one clock: the
                    // playhead re-parks on the new sweep table's own
                    // axis end and pauses - a seconds playhead left
                    // running against a volts axis would animate
                    // nonsense. Nothing scrubbable: the clock stops.
                    const ws::spice::Table* sweep =
                        ed.canvas_sweep_table();
                    if (sweep != nullptr) {
                        const std::span<const double> axis =
                            ws::circsim::overlay_sweep_axis(*sweep);
                        if (!axis.empty()) {
                            ed.playback.t = axis.back();
                        }
                    }
                    ed.playback.playing = false;
                }
            }
        }
        // The export pair, flowed on their own line and sized to their
        // whole labels (B2: two "Export …" stubs were one
        // indistinguishable button - the labels are the purpose).
        // button_row_flow wraps the overflow when the line cannot
        // hold both (the no-mid-word-cut rule, the same reflow the
        // legend toolbar below rides).
        static const char* const kExportCells[] = {"Export CSV",
                                                    "Export JSON"};
        const int export_btn = gui::button_row_flow(
            gui, layout, theme, "results.export", kExportCells, 2, 96.0f,
            nullptr);
        if (export_btn == 0 && ed.export_results) {
            ed.export_results(false);
        } else if (export_btn == 1 && ed.export_results) {
            ed.export_results(true);
        }
        if (stale) {
            gui::ChromeTheme warn = theme;
            warn.text = gui::dim(theme.toast_warning, 0.95f);
            (void)gui::text_wrapped(
                layout, warn,
                "Out of date - the schematic changed since the run "
                "(Ctrl+Enter re-runs)");
        }
    }

    // --- the selected table
    if (t.sweep == ws::spice::SweepKind::None) {
        // The .op shape: one value row per signal, no plot.
        gui::separator(layout, theme);
        std::vector<ValueRow> rows;
        rows.reserve(t.signals.size());
        for (const ws::spice::Signal& s : t.signals) {
            if (!s.data.empty()) {
                rows.push_back(
                    ValueRow{s.name, s.data.front(), unit_of(s.name)});
            }
        }
        draw_value_rows(ed, layout, theme, rows);
    } else {
        const std::size_t x_index =
            t.sweep_axes.empty()
                ? 0u
                : std::min(t.step_axes, t.sweep_axes.size() - 1u);
        const char* x_name =
            !t.sweep_names.empty() &&
                    x_index < t.sweep_names.size() &&
                    !t.sweep_names[x_index].empty()
                ? t.sweep_names[x_index].c_str()
                : "sample";

        // The legend: swatch + visibility + the spine tag + the live
        // readout (the hover sample, else the last one - the
        // waveform's resting state is the readout people want at a
        // glance). The tag (stage 6) is which y spine the signal
        // rides, spelled in units: V on the left scale, A on the
        // right one - the classifier's answer, quiet, so a mixed
        // legend reads its split without opening the plot.
        gui::separator(layout, theme);
        gui::ChromeTheme quiet = theme;
        quiet.text = gui::dim(theme.text, 0.45f);
        // The toolbar: bulk visibility, the discoverable "fit view"
        // (the double-click still works), and the hover x readout.
        // The toolbar REFLOWS (button_row_flow): a narrow panel wraps
        // "Fit view" onto the next line whole instead of drawing
        // "Sho…"/"Hid…" stubs - the labels ARE the pair's purpose
        // (B2), and the row never shrinks a button below its own
        // whole label (B1).
        static const char* const kLegendCells[] = {"Show all", "Hide all",
                                                   "Fit view"};
        // "Fit view" rides the same flowed row but draws DEAD until a
        // gesture makes the view active (the double-click still resets
        // directly) - the dead face reads "not applicable yet", the
        // same lock Remove selected wears; Show/Hide stay alive.
        const bool fit_dead = !ed.results.view.active;
        const bool legend_dead[3] = {false, false, fit_dead};
        const int legend_btn = gui::button_row_flow(
            gui, layout, theme, "legend.tools", kLegendCells, 3, 72.0f,
            legend_dead);
        if (legend_btn == 0) {
            ed.results.visible.assign(t.signals.size(), 1u);
        } else if (legend_btn == 1) {
            ed.results.visible.assign(t.signals.size(), 0u);
        } else if (legend_btn == 2) {
            ed.results.view = PlotView{};  // dead never activates
        }
        const int at = ed.results.hover >= 0
                           ? ed.results.hover
                           : static_cast<int>(t.row_count()) - 1;
        for (std::size_t i = 0; i < t.signals.size(); ++i) {
            const ws::spice::Signal& s = t.signals[i];
            gui.ids().push(static_cast<int>(i));
            const gui::Rect swatch = layout.next(14.0f, 14.0f);
            canvas::Canvas2D& sw = ed.results_draw_canvas();
            sw.set_view_scale(1.0f);
            // Centered on the row's own height (the checkbox beside it is
            // a full control tall); it used to hang ~5px above center.
            sw.fill_rounded_rect(
                swatch.x,
                swatch.y + std::max(0.0f, (theme.control_height - 12.0f) *
                                              0.5f),
                12.0f, 12.0f, 3.0f, series_color(i));
            layout.same_line(6.0f);
            bool vis = i < ed.results.visible.size()
                           ? ed.results.visible[i] != 0u
                           : true;
            if (gui::checkbox(gui, layout, theme, s.name.c_str(), vis)) {
                if (ed.results.visible.size() == t.signals.size()) {
                    ed.results.visible[i] = vis ? 1u : 0u;
                }
            }
            layout.same_line();
            gui::text(layout, quiet,
                      ws::circsim::signal_y_axis(s.name) ==
                              ws::circsim::PlotYAxis::Right
                          ? "A"
                          : "V",
                      14.0f);
            layout.same_line();
            const gui::Rect spark = layout.next(48.0f, 14.0f);
            // The layout still advances (the row's own widgets and the
            // plot below ride it); only the drawing is skipped for a
            // sparkline the scroll clip hides - a 48-signal legend is
            // ~19k quads a frame, most of them past the viewport.
            if (clip_shows(gui, spark)) {
                draw_sparkline(sw, spark, s.data, ed.results.stats[i],
                               series_color(i), ed.results.hover,
                               ed.results.scratch_pts);
            }
            if (at >= 0 && static_cast<std::size_t>(at) < s.data.size()) {
                layout.same_line();
                const std::string value = with_unit(
                    s.data[static_cast<std::size_t>(at)], unit_of(s.name));
                gui::text(layout, theme,
                          (ed.results.hover >= 0 ? value : value + "  (end)")
                              .c_str());
            }
            gui.ids().pop();
        }

        gui::separator(layout, theme);
        draw_plot(ed, gui, layout, theme, t, x_name);
        draw_transport_row(ed, gui, layout, theme, t);
        // The hover x readout rides BELOW the plot (a readout, like
        // the value rows under the legend): the hover state toggling
        // must never shift the plot's own geometry, because every
        // gesture maps pointer coordinates through the frame built
        // this frame - a frame that moves mid-gesture (the hover row
        // appearing above the plot when the pointer crossed into it)
        // armed the band at one y and committed it at another, 36px
        // off.
        if (ed.results.hover >= 0) {
            const std::span<const double> hxs = t.axis(x_index);
            const std::size_t hk =
                static_cast<std::size_t>(ed.results.hover);
            const double hx = hxs.empty() ? static_cast<double>(hk)
                                          : (hk < hxs.size() ? hxs[hk] : 0.0);
            char xline[128];
            std::snprintf(xline, sizeof xline, "%s = %s  (sample %d)",
                          x_name, ws::circsim::format_eng(hx, 5).c_str(),
                          ed.results.hover);
            (void)gui::text_wrapped(layout, quiet, xline);
        }
        gui::text(layout, quiet,
                  "wheel zoom | drag box | drag axis | space+drag pan | "
                  "dbl-click fit | right-click cancel");
    }

    // --- the measurements
    if (!ed.results.run.measurements.empty()) {
        gui::separator(layout, theme);
        gui::text(layout, theme, "Measurements");
        const ws::ui::r2d::Font* font =
            ed.font_mono != nullptr && !ed.font_mono->empty()
                ? ed.font_mono
                : theme.font;
        int index = 0;
        for (const ws::spice::Measurement& m :
             ed.results.run.measurements) {
            gui.ids().push(index);
            char line[192];
            if (m.value.has_value()) {
                std::snprintf(line, sizeof line, "%s = %s",
                              m.name.c_str(),
                              ws::circsim::format_eng(*m.value, 5).c_str());
            } else {
                std::snprintf(line, sizeof line, "%s: failed - %s",
                              m.name.c_str(), m.note.c_str());
            }
            if (font != nullptr && font->line_height() > 0.0f) {
                const float line_h = font->line_height() + 2.0f;
                const gui::Rect row =
                    layout.next(layout.remaining_width(), line_h);
                (void)ws::ui::r2d::draw_text(
                    row.x, row.y, line, *font,
                    m.value.has_value()
                        ? gui::dim(theme.text, 0.85f)
                        : gui::dim(theme.toast_warning, 0.95f));
            } else {
                gui::text(layout, theme, line);
            }
            gui.ids().pop();
            ++index;
        }
    }

    // --- the fourier table (§7.9): the shown analysis's series only -
    // .tran tables get the harmonic rows, .op tables the DC line. A
    // .dc/.ac/.noise view hides the section entirely (nothing to
    // analyse against), and a failed series reads like a failed
    // measurement - the same warning color, the same note contract.
    if (!ed.results.run.fouriers.empty() &&
        (t.analysis == ws::spice::AnalysisKind::Tran ||
         t.analysis == ws::spice::AnalysisKind::Op)) {
        const char* shown = analysis_name(t.analysis);
        bool any = false;
        for (const ws::spice::Fourier& f : ed.results.run.fouriers) {
            if (f.analysis == shown) {
                any = true;
                break;
            }
        }
        if (any) {
            gui::separator(layout, theme);
            gui::text(layout, theme, "Fourier");
            const ws::ui::r2d::Font* font =
                ed.font_mono != nullptr && !ed.font_mono->empty()
                    ? ed.font_mono
                    : theme.font;
            const auto row_line = [&](const char* line,
                                      std::uint32_t color) {
                if (font != nullptr && font->line_height() > 0.0f) {
                    const float line_h = font->line_height() + 2.0f;
                    const gui::Rect row =
                        layout.next(layout.remaining_width(), line_h);
                    (void)ws::ui::r2d::draw_text(row.x, row.y, line, *font,
                                                 color);
                } else {
                    gui::text(layout, theme, line);
                }
            };
            // The harmonic spectrum: one bar per harmonic, height = its
            // share of the fundamental (%fund), on a 0..max scale. The
            // numbers below say exactly; the bars say at a glance which
            // harmonics matter - the fundamental in the accent, the
            // distortion content in amber.
            const auto draw_spectrum = [&](const ws::spice::Fourier& f) {
                const ws::ui::r2d::Font* sf =
                    theme.font != nullptr ? theme.font : ed.font;
                const std::size_t n = f.harmonics.size();
                if (n == 0 || sf == nullptr || !(sf->line_height() > 0.0f)) {
                    return;
                }
                const float lh = sf->line_height();
                const float height = 76.0f + lh;
                const gui::Rect box =
                    layout.next(layout.remaining_width(), height);
                const float left = box.x + 38.0f;  // the scale's labels
                const float right = box.x + box.width - 6.0f;
                const float top = box.y + 6.0f;
                const float base = box.y + height - lh - 6.0f;
                if (right - left < 24.0f || base - top < 12.0f) {
                    return;
                }
                canvas::Canvas2D& rc = ed.results_draw_canvas();
                rc.set_view_scale(1.0f);
                double top_value = 100.0;
                for (const ws::spice::FourierHarmonic& h : f.harmonics) {
                    top_value = std::max(top_value, h.normalized);
                }
                rc.fill_rounded_rect(left, top, right - left, base - top,
                                     3.0f, theme.canvas_bg);
                Paint rail;
                rail.width = 1.0f;
                rail.color = gui::dim(theme.text, 0.12f);
                for (int q = 0; q <= 2; ++q) {  // 0, half, full scale
                    const float gy =
                        base - (base - top) * static_cast<float>(q) * 0.5f;
                    rc.stroke_line({left, gy}, {right, gy}, rail);
                    char scale[24];
                    std::snprintf(scale, sizeof scale, "%.3g%%",
                                  top_value * q * 0.5);
                    const float sw = rc.measure_text(scale, *sf);
                    (void)rc.draw_text(left - sw - 4.0f, gy - lh * 0.5f,
                                       scale, *sf,
                                       gui::dim(theme.text, 0.5f));
                }
                const float slot = (right - left) / static_cast<float>(n);
                const float bar_w = std::clamp(slot * 0.62f, 3.0f, 30.0f);
                // A label under every bar when they fit, every kth when
                // they do not (the number of a 40-harmonic run would
                // otherwise overprint itself).
                const int step = std::max(
                    1, static_cast<int>(std::ceil(26.0f / slot)));
                for (std::size_t k = 0; k < n; ++k) {
                    const ws::spice::FourierHarmonic& h = f.harmonics[k];
                    const float bx =
                        left + slot * static_cast<float>(k) +
                        (slot - bar_w) * 0.5f;
                    float bh = static_cast<float>(
                        (h.normalized / top_value) * (base - top));
                    bh = std::clamp(bh, 0.0f, base - top);
                    if (h.normalized > 0.0 && bh < 1.5f) {
                        bh = 1.5f;  // a present harmonic never vanishes
                    }
                    const std::uint32_t ink =
                        h.n == 1 ? theme.control_on
                                 : gui::dim(theme.toast_warning, 0.95f);
                    if (bh > 0.0f) {
                        rc.fill_rounded_rect(bx, base - bh, bar_w, bh,
                                             std::min(2.0f, bar_w * 0.4f),
                                             ink);
                    }
                    if (static_cast<int>(k) % step == 0) {
                        const std::string num = std::to_string(h.n);
                        const float nw = rc.measure_text(num.c_str(), *sf);
                        (void)rc.draw_text(bx + (bar_w - nw) * 0.5f,
                                           base + 3.0f, num.c_str(), *sf,
                                           gui::dim(theme.text, 0.6f));
                    }
                }
            };
            int index = 0;
            for (const ws::spice::Fourier& f :
                 ed.results.run.fouriers) {
                if (f.analysis != shown) {
                    continue;
                }
                gui.ids().push(index);
                const char* unit = unit_of(f.signal);
                char line[224];
                if (!f.ok()) {
                    std::snprintf(line, sizeof line, "%s: failed - %s",
                                  f.signal.c_str(), f.note.c_str());
                    row_line(line, gui::dim(theme.toast_warning, 0.95f));
                } else if (f.harmonics.empty()) {
                    // The .op shape: the DC component is the whole answer.
                    std::snprintf(line, sizeof line,
                                  "%s - dc %s (.op: harmonics need .tran)",
                                  f.signal.c_str(),
                                  with_unit(f.dc, unit, 5).c_str());
                    row_line(line, gui::dim(theme.text, 0.85f));
                } else {
                    std::snprintf(
                        line, sizeof line,
                        "%s - fundamental %s Hz, %zu period%s, THD %.4g %%",
                        f.signal.c_str(),
                        ws::circsim::format_eng(f.fundamental, 4).c_str(),
                        f.periods, f.periods == 1 ? "" : "s",
                        f.thd_percent);
                    row_line(line, gui::dim(theme.text, 0.85f));
                    std::snprintf(line, sizeof line, "  dc  %s",
                                  with_unit(f.dc, unit, 5).c_str());
                    row_line(line, gui::dim(theme.text, 0.85f));
                    if (f.periods == 0) {
                        row_line("  (the run is shorter than one period -"
                                 " the bins carry window leakage)",
                                 gui::dim(theme.text, 0.55f));
                    }
                    draw_spectrum(f);
                    row_line("   n  frequency     magnitude      phase"
                             "  %fund",
                             gui::dim(theme.text, 0.55f));
                    for (const ws::spice::FourierHarmonic& h :
                         f.harmonics) {
                        std::snprintf(
                            line, sizeof line,
                            "  %2d  %-12s %-14s %8.1f  %6.2f", h.n,
                            (ws::circsim::format_eng(h.freq, 4) + " Hz")
                                .c_str(),
                            with_unit(h.magnitude, unit, 4).c_str(),
                            h.phase_deg, h.normalized);
                        row_line(line, gui::dim(theme.text, 0.85f));
                    }
                    std::snprintf(line, sizeof line,
                                  "  thd  %.4f %%  (harmonics 2..%d)",
                                  f.thd_percent,
                                  f.harmonics.back().n);
                    row_line(line, gui::dim(theme.text, 0.85f));
                }
                gui.ids().pop();
                ++index;
            }
        }
    }
}

}  // namespace editor
