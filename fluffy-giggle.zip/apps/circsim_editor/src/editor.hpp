#pragma once

// apps/circsim_editor stage 3 - the shared editor core: the state the
// panels and commands all drive, plus the pure helpers (view mapping,
// snapping, hit-testing, wire routing, symbol rendering) that live
// with it. One struct, `Editor`, owned by the app; the panel draw
// callbacks and the commands receive `Editor&` and nothing else.
//
// The world frame is the MODEL's: grid units, y up, rotations CCW.
// The screen frame is gui pixels, y down. EditorView is the mapping
// (a zoom/pan camera with the y flip baked in) - deliberately NOT
// ws::ui::canvas::ViewTransform2D, whose screen-space convention is
// y-down world (its own docs say so); the schematic's math must stay
// in the model's frame or pins and pictures would disagree, so the
// editor owns its own 60-line camera instead of fighting the layer's.
// Everything drawn still goes through ws::ui::canvas's Canvas2D (the
// stage-14 layer) - strokes, tessellation, dashes and text.
//
// The interaction model (v1, one pointer):
//   Select tool  press on a part/junction/wire/label selects it;
//                dragging moves the part/junction live (the undo
//                command lands at release, capturing from/to);
//                press on empty space clears the selection.
//   Place tool   armed from the Palette; the ghost follows the
//                snapped cursor; R/M rotate/mirror the ghost; each
//                click places one part (the tool stays armed); Esc or
//                a right click disarms.
//   Wire tool    click a pin or junction starts a draft; the preview
//                follows the cursor with the ortho route (the first
//                leg honors the pin's dir, the last approaches the
//                target's); clicking a pin/junction commits, clicking
//                free space commits onto a fresh junction; every
//                commit disarms (W re-arms cheaply).
//   Label tool   armed with the Palette's name field; each click
//                places one label; stays armed.
// Wheel zooms toward the cursor; middle-drag and space+left-drag pan.

#include <algorithm>
#include <array>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <cmath>
#include <deque>
#include <functional>
#include <map>
#include <optional>
#include <set>
#include <string>
#include <string_view>
#include <unordered_map>
#include <unordered_set>

#include <ws/ui/gui/rect.hpp>
#include <utility>
#include <vector>

#include <ws/circsim/export.hpp>
#include <ws/circsim/geom.hpp>  // the interaction geometry (stage 11:
                                // route/tidy/order/refdes/hits/bounds/
                                // magnetism/series_color - the pure math
                                // this header's methods forward onto)
#include <ws/circsim/library.hpp>
#include <ws/gestures/arbiter.hpp>
#include <ws/circsim/locate.hpp>
#include <ws/circsim/model.hpp>
#include <ws/circsim/nets.hpp>
#include <ws/circsim/plot.hpp>
#include <ws/circsim/render.hpp>
#include <ws/math/vecmath.hpp>
#include <ws/spice/run.hpp>
#include <ws/ui/canvas/canvas2d.hpp>
#include <ws/ui/canvas/grid.hpp>  // GridSpec: the grid the panel draws
#include <ws/ui/canvas/tessellation.hpp>
#include <ws/ui/gui/theme.hpp>
#include <ws/ui/gui/widgets.hpp>

#include "document.hpp"
#include "schematic_adapter.hpp"

namespace ws::jobs {
class JobSystem;
}
namespace ws::ui::shell {
class AppShell;
}

namespace editor {

namespace gui = ws::ui::gui;
namespace canvas = ws::ui::canvas;
using ws::circsim::Bounds;
using ws::circsim::Pos;

// Screen-space rectangle (min corner + width/height), used by the
// annotation placement engine for overlap tests in pixel space.
struct ScreenRect {
    float x = 0.0f;
    float y = 0.0f;
    float w = 0.0f;
    float h = 0.0f;
};

// Epsilon compare on world coordinates (grid units).
inline bool eps_eq(double a, double b, double eps) {
    return std::fabs(a - b) <= eps;
}

// The "Tidy Wires" command's seam (document.cpp): lands the given
// shapes as ONE undo step, skipping wires that would not change, and
// returns how many wires actually changed (0 = nothing pushed). Declared
// here because document.hpp was not part of the change; moving this
// declaration into document.hpp is the intended home (a redeclaration
// in both places is harmless).
std::size_t push_tidy_wires(SchematicDocument& doc,
                            std::vector<WireRoute> routes);

// Rotate/mirror WITH the attached wires' fresh shapes, as one undo step
// (push_transform_part stays for callers with no routes). The Editor's
// transform_part() computes the routes and calls this.
void push_transform_part_routed(SchematicDocument& doc, std::uint32_t part_id,
                                int rot, bool mirror, std::string name,
                                std::vector<WireRoute> wire_routes,
                                std::vector<GluedJunctionMove> glue);

// A whole-sheet renumbering as one undo step: (part id, new ref) pairs;
// entries that would not change a ref are dropped. Returns how many refs
// changed (0 = nothing pushed). Same declaration note as push_tidy_wires.
std::size_t push_annotate(
    SchematicDocument& doc,
    std::vector<std::pair<std::uint32_t, std::string>> changes);

// --- the camera -------------------------------------------------------------

struct EditorView {
    // The zoom range and the default, in screen pixels per grid unit.
    // One source of truth: zoom_at, fit, fly_to and the document load
    // all clamp through clamp_zoom (the limits used to be magic numbers
    // repeated at every call site).
    static constexpr double kMinZoom = 3.0;
    static constexpr double kMaxZoom = 400.0;
    static constexpr double kDefaultZoom = 26.0;
    [[nodiscard]] static double clamp_zoom(double z) {
        return std::clamp(z, kMinZoom, kMaxZoom);
    }

    double zoom = kDefaultZoom;  // screen pixels per grid unit
    Pos center{0.0, 0.0};        // the world point at the viewport's center

    // The viewport, set each frame before use (screen px, the panel
    // body's rect). Invalid (w/h <= 0) until the first draw.
    float vx = 0.0f, vy = 0.0f, vw = 0.0f, vh = 0.0f;

    // --- the smooth camera (opt-in) ---------------------------------------
    // fly_to() glides the camera to a target (an ease-in-out in log-zoom,
    // so a big zoom change feels even). It is OFF by default: with
    // `animate == false` fly_to() snaps, exactly the old behavior, so
    // nothing changes until the app opts in. When on, the app calls
    // step(dt) once per frame (dt in seconds) and keeps redrawing while
    // it returns true. Any manual zoom/pan cancels a glide in flight -
    // the user's hands always win over the camera's.
    struct Glide {
        bool active = false;
        Pos from_center{0.0, 0.0};
        Pos to_center{0.0, 0.0};
        double from_zoom = kDefaultZoom;
        double to_zoom = kDefaultZoom;
        double t = 0.0;         // seconds elapsed
        double duration = 0.35;  // seconds
    };
    bool animate = false;
    Glide glide;

    void cancel_glide() { glide.active = false; }

    void fly_to(Pos target, double target_zoom, double seconds = 0.35) {
        target_zoom = clamp_zoom(target_zoom);
        if (!animate || seconds <= 0.0 || !valid()) {
            center = target;
            zoom = target_zoom;
            glide.active = false;
            return;
        }
        glide.active = true;
        glide.from_center = center;
        glide.to_center = target;
        glide.from_zoom = zoom;
        glide.to_zoom = target_zoom;
        glide.t = 0.0;
        glide.duration = seconds;
    }

    // Advance a glide by `dt` seconds; true while it is still moving.
    bool step(double dt) {
        if (!glide.active) {
            return false;
        }
        glide.t += dt;
        const double u = std::min(1.0, glide.t / glide.duration);
        const double e = u * u * (3.0 - 2.0 * u);  // smoothstep
        center = {glide.from_center.x +
                      (glide.to_center.x - glide.from_center.x) * e,
                  glide.from_center.y +
                      (glide.to_center.y - glide.from_center.y) * e};
        const double lz0 = std::log(glide.from_zoom);
        const double lz1 = std::log(glide.to_zoom);
        zoom = clamp_zoom(std::exp(lz0 + (lz1 - lz0) * e));
        if (u >= 1.0) {
            center = glide.to_center;
            zoom = glide.to_zoom;
            glide.active = false;
        }
        return glide.active;
    }

    [[nodiscard]] bool valid() const { return vw > 1.0f && vh > 1.0f; }

    // world (y up) <-> screen (y down): x maps straight, y flips.
    [[nodiscard]] ws::math::Vec2 w2s(Pos world) const {
        return {static_cast<float>(vx + vw * 0.5f +
                                   (world.x - center.x) * zoom),
                static_cast<float>(vy + vh * 0.5f -
                                   (world.y - center.y) * zoom)};
    }
    [[nodiscard]] Pos s2w(ws::math::Vec2 screen) const {
        return {center.x + (screen.x - vx - vw * 0.5f) / zoom,
                center.y - (screen.y - vy - vh * 0.5f) / zoom};
    }

    // Zoom by `factor` toward `anchor` (screen px): the world point
    // under the anchor stays put. Clamped to the editor's range.
    void zoom_at(ws::math::Vec2 anchor, double factor) {
        if (!valid()) {
            return;
        }
        glide.active = false;  // the wheel beats a glide in flight
        const Pos under = s2w(anchor);
        zoom = clamp_zoom(zoom * factor);
        // Keep `under` at the anchor: center = under + (center-anchor
        // in world units at the new zoom).
        const double dx = (vx + vw * 0.5f - anchor.x) / zoom;
        const double dy = (anchor.y - vy - vh * 0.5f) / zoom;
        center = {under.x + dx, under.y + dy};
    }

    // Pan by a screen-pixel delta.
    void pan_by(ws::math::Vec2 screen_delta) {
        glide.active = false;  // a drag beats a glide in flight
        center.x -= screen_delta.x / zoom;
        center.y += screen_delta.y / zoom;
    }

    // Fit `b` (world) with `margin` world units of air on every side.
    // A degenerate box keeps the zoom and centers. The screen-space
    // insets (px bands the canvas's overlays occupy: the mode toggle
    // top-right, the transport strip along the bottom) shrink the
    // viewport the fit answers through, so nothing the user just fitted
    // hides under a control.
    float inset_top = 0.0f;     // the mode toggle's band (top-right)
    float inset_bottom = 0.0f;  // the transport strip's band (bottom)

    void fit(const Bounds& b, double margin) {
        if (!valid()) {
            return;
        }
        const Pos target{(b.min_x + b.max_x) * 0.5, (b.min_y + b.max_y) * 0.5};
        const double w = (b.max_x - b.min_x) + 2.0 * margin;
        const double h = (b.max_y - b.min_y) + 2.0 * margin;
        if (w <= 0.0 || h <= 0.0) {
            fly_to(target, zoom);  // degenerate: center, keep the zoom
            return;
        }
        const float usable_h = std::max(8.0f, vh - inset_top - inset_bottom);
        // fly_to clamps the zoom, and glides when `animate` is on.
        fly_to(target, std::min(static_cast<double>(vw) / w,
                                static_cast<double>(usable_h) / h));
    }
};

// --- selection & tools --------------------------------------------------------

enum class Tool : std::uint8_t { Select, Place, Wire, Label, Probe };

struct Selection {
    enum class Kind : std::uint8_t { None, Part, Wire, Junction, Label };
    Kind kind = Kind::None;
    std::uint32_t id = 0;

    [[nodiscard]] bool is(Kind k, std::uint32_t of) const {
        return kind == k && id == of;
    }
    void clear() { kind = Kind::None; }
};

struct WireGeom {
    std::vector<Pos> path;
    double min_x = 0.0, max_x = 0.0, min_y = 0.0, max_y = 0.0;
};

class SelectionIndex {
public:
    SelectionIndex(const Selection& primary,
                   const std::vector<Selection>& multi)
        : primary_(primary) {
        multi_.reserve(multi.size());
        for (const Selection& m : multi) {
            if (m.kind != Selection::Kind::None) multi_.insert(key(m));
        }
    }

    [[nodiscard]] bool contains(const Selection& of) const {
        if (of.kind == Selection::Kind::None) return false;
        if (primary_.kind == of.kind && primary_.id == of.id) return true;
        return !multi_.empty() && multi_.count(key(of)) != 0u;
    }

private:
    [[nodiscard]] static std::uint64_t key(const Selection& s) {
        return (static_cast<std::uint64_t>(s.kind) << 32) | s.id;
    }
    Selection primary_;
    std::unordered_set<std::uint64_t> multi_;
};

// A hovered pin (the wire tool's target highlight) - the lib's own
// shape (ws::circsim::PinHit, geom.hpp); the alias keeps the editor's
// historical spelling.
using PinHit = ws::circsim::PinHit;

// --- the group edit: the working set and the clipboard ------------------

// The multi-selection beside the primary: the box tool's set and the
// shift-clicks' toggles. `sel` stays the anchor - the Properties
// panel's subject, the frame command's target - while `multi` widens
// the WORKING set (sel + multi, deduped) the group commands act on:
// copy/paste/duplicate, the group drag, the group delete. Selection
// is view state, never document state - it is not undoable, and an
// undo that removes an entity simply drops it from both halves
// (selection_set skips ids the schematic no longer finds).
struct BoxSelect {
    bool active = false;
    Pos start_world{0.0, 0.0};
    Pos cur_world{0.0, 0.0};

    // The world rectangle (normalized: min corner, max corner).
    [[nodiscard]] std::pair<Pos, Pos> rect() const {
        return {{std::min(start_world.x, cur_world.x),
                 std::min(start_world.y, cur_world.y)},
                {std::max(start_world.x, cur_world.x),
                 std::max(start_world.y, cur_world.y)}};
    }
};

// What a copy captured: the entities verbatim (ids still the
// ORIGINALS' - paste mints fresh ones against the target schematic)
// plus the set's bounds center, the paste's own anchor. A wire rides
// along when BOTH endpoints resolve into the set; a wire whose
// endpoint does not (a pin of an unselected part, a junction outside
// the box) is carried as a boundary junction minted at the endpoint's
// world position, so the pasted stub looks exactly like the drawn
// one. Editor-lifetime state: the clipboard crosses documents (the
// whole point of copy/paste), so it lives here, not in the document.
struct Clipboard {
    std::vector<ws::circsim::Part> parts;
    std::vector<ws::circsim::Junction> junctions;
    std::vector<ws::circsim::Wire> wires;
    std::vector<ws::circsim::Label> labels;
    std::optional<Pos> center;  // nullopt = empty clipboard

    [[nodiscard]] bool empty() const {
        return parts.empty() && junctions.empty() && wires.empty() &&
               labels.empty();
    }
};

// --- the caches ----------------------------------------------------------------

// The Problems panel's list: whatever produced it (ERC, a run, a
// load's repairs) plus the maps the rows locate through.
struct ProblemsCache {
    bool has = false;          // a check ran at least once
    bool from_run = false;     // a simulation's outcome (not plain ERC)
    std::uint64_t version = 0;  // the schematic version it ran against
    std::string header;        // "erc: 2 errors, 3 warnings" and friends
    std::vector<ws::circsim::Diag> diags;
    std::vector<std::string> lines;  // the rendered rows (borrowed bytes)
    ws::circsim::NetList nets;       // the check's net build
    bool nets_valid = false;
    ws::circsim::SpiceExport map;    // the run's export back-map
    bool map_valid = false;
};

struct NetlistCache {
    bool has = false;
    std::uint64_t version = 0;
    std::string text;                 // the exported deck
    std::vector<std::string> lines;   // split for the panel's rows
};

// The Results plot's manual view (stage 5): the zoom/pan window the
// wheel, the rubber band and the drags produce, in DATA units,
// riding over the automatic fit (ws::circsim::clamp_view keeps it
// inside the data's padded extent). Inactive = the auto fit, the
// stage-4 behavior exactly. Stage 6 gives the two-axis plot its
// second window: y_* is the LEFT spine's window (the volt company),
// y1_* the RIGHT one's (the amp company) - each clamped into its own
// home, so a mixed legend zooms one spine without dragging the other.
struct PlotView {
    bool active = false;
    double x_lo = 0.0, x_hi = 0.0;
    double y_lo = 0.0, y_hi = 0.0;    // the left y axis (volts)
    double y1_lo = 0.0, y1_hi = 0.0;  // the right y axis (amperes)
};

// The plot's in-flight pointer gesture (stage 5): the rubber-band box
// zoom, the two axis-drag zooms, and the pan. The press-time view is
// captured so the drag rebases from it every frame (no drift) and a
// right-click restores it exactly. The double-click clock rides the
// input frame's dt - the reset gesture's "two clicks, same spot".
// Stage 6 adds the right strip's drag (zoom_axis 1 vs 0) and the
// right spine's press-time capture (y1_*, anchor_y1) so its drag
// rebases and cancels exactly like the left one always did.
struct PlotGesture {
    enum class Kind : std::uint8_t { None, Band, ZoomX, ZoomY, Pan };
    Kind kind = Kind::None;
    float from_x = 0.0f, from_y = 0.0f;     // the press point, screen px
    double anchor_x = 0.0, anchor_y = 0.0;  // the data point under the press
    double anchor_y1 = 0.0;                 // ... on the right spine (stage 6)
    double x_lo = 0.0, x_hi = 0.0;          // the x view at press
    double y_lo = 0.0, y_hi = 0.0;          // the left y view at press
    double y1_lo = 0.0, y1_hi = 0.0;        // the right y view at press
    int zoom_axis = 0;  // the ZoomY strip: 0 = left, 1 = right (stage 6)
    bool was_active = false;                // the view at press (the cancel restore)
    // The double-click detector: the clock runs while the pointer is
    // over the plot, resets on every press there.
    float click_clock = 100.0f;
    float click_x = 0.0f, click_y = 0.0f;
};

// The Results panel's cache (stage 4): the last run's output plus the
// view over it - which table is shown, which signals are visible, and
// the sample the cursor hovers (the crosshair's index, -1 when off).
// Stage 5 adds the plot's manual view and its in-flight gesture, both
// keyed to the table they belong to. Stage 6 widens both to the two
// spines: the view carries the right axis's window beside the left's,
// the gesture its press-time capture - a mixed V/I legend zooms and
// pans each spine alone. A document switch clears it
// (document_changed); an EDIT does not -
// the panel marks itself stale against the schematic's version, the
// same contract the Problems and Netlist panels keep.
struct ResultsCache {
    static constexpr std::size_t kNoTable = static_cast<std::size_t>(-1);

    bool has = false;
    std::uint64_t version = 0;           // the schematic version it ran against
    ws::spice::RunOutput run;            // tables + measurements
    // The run's OWN net build and export back-map (deliver_run moves the
    // outcome's originals here; the Problems cache holds a copy for its
    // locate seam, and an ERC pass may replace that copy without ever
    // touching these). The canvas's voltage coloring and the LED glow
    // read THEM: node_net answers net id -> node token (the v(name)
    // column), element_part answers part id -> deck element (the i(name)
    // probe column).
    ws::circsim::NetList nets;
    ws::circsim::SpiceExport map;
    std::size_t table = 0;               // the selected table
    std::size_t visible_for = kNoTable;  // the table `visible` belongs to
    std::vector<std::uint8_t> visible;   // per-signal flags of that table
    int hover = -1;                      // sample index under the cursor
    PlotView view;                       // the manual zoom/pan window
    std::size_t view_for = kNoTable;     // the table `view` belongs to (synced every frame, plot or not)
    PlotGesture gesture;                 // the in-flight plot gesture
    // The shown table's x axis is strictly increasing - a per-table
    // constant of the run (the axis data is immutable once delivered),
    // cached with the same key shape as `visible`/`view` so the plot
    // does not re-walk every sample every frame. Reset with the other
    // per-run keys when a delivery lands (a same-indexed table of a
    // NEW run is a different axis).
    bool x_sorted = false;
    std::size_t x_sorted_for = kNoTable;  // the table `x_sorted` belongs to
    // Stage 9 (the .step family fix): the axis's MONOTONE RUNS plus
    // its finite envelope, the same per-table constant `x_sorted` is
    // (same key shape, reset beside it on a delivery). A sorted axis
    // answers one run; a stepped run's repeating inner axis (time
    // restarting every step point, a nested .dc's inner sweep walking
    // back to its start) answers ONE RUN PER PASS - the plot overlays
    // the passes on the shared window instead of chording every reset
    // into the lines-between-vertices mess one polyline made.
    ws::circsim::AxisRuns x_runs;
    std::size_t x_runs_for = kNoTable;   // the table `x_runs` belongs to

    // --- the frame-budget caches (the big-circuit fix) -------------------------
    //
    // A big circuit's run carries dozens of signals over tens of
    // thousands of samples, and the panel used to re-walk ALL of it
    // EVERY frame: the y fit scanned every visible column end to end,
    // each legend row's sparkline scanned its whole signal twice, and
    // every series re-decimated from scratch - three O(signals x
    // samples) passes at the frame rate on a plot that only changes
    // when the view, the hover or the table does. The caches below pin
    // each pass to what it actually depends on:
    //   * stats - per-signal constants of the TABLE (the finite
    //     envelope for the y fit, the sparkline's 40-bucket envelope,
    //     the spine flag): computed once per (run, table), read every
    //     frame. The y fit becomes O(visible signals), the sparkline
    //     O(buckets).
    //   * decim - per-signal keep lists for the series polylines,
    //     recomputed only when the x window or the pixel budget moves
    //     (a gesture, a resize), reused verbatim on idle frames.
    // Both key on run_id (bumped by every delivery, main.cpp) beside
    // the table index, so a same-indexed table of a new run never
    // reads a stale entry; a document switch replaces the whole cache.
    // The tables are immutable once delivered, so a (run, table) hit
    // is valid by construction.
    std::uint64_t run_id = 0;  // the delivery the cached work belongs to

    struct SeriesStats {
        bool finite = false;   // any finite sample at all
        double lo = 0.0;       // the finite envelope's min (y fit +
        double hi = 1.0;       //  sparkline scale; sane-empty when !finite)
        // The sparkline envelope: 2 entries per bucket (the min and
        // max SAMPLE's value in occurrence order, duplicated when the
        // bucket holds one sample, NaN pair when it holds none) - the
        // exact point list draw_sparkline used to rebuild per frame,
        // mapped straight through py() at draw time.
        std::vector<double> spark_env;
        bool right = false;    // signal_y_axis's answer (the spine flag)
    };
    std::size_t stats_for = kNoTable;   // the table `stats` belongs to
    std::uint64_t stats_run = 0;        // ... and the delivery of it
    std::vector<SeriesStats> stats;

    // One RUN's cached decimation (stage 9's shape): `i0`/`i1` are the
    // run's visible slice in ABSOLUTE sample positions (the x window
    // the keeps were decimated over), `idx` the kept positions in
    // ascending order, likewise ABSOLUTE (positions into the table's
    // columns, never offsets from `i0` - the draw pushes them as is) -
    // EMPTY separates "computed, and legitimately
    // empty - the slice fits the budget, draw every sample in
    // [i0, i1)" from nothing (a run with no visible sample answers an
    // empty idx AND an empty slice, which draws nothing).
    struct RunKeep {
        std::vector<std::size_t> idx;
        std::size_t i0 = 0;
        std::size_t i1 = 0;
    };
    // One signal's cached decimation: one keep per axis RUN - a
    // sorted axis has exactly one, a step family one per pass (the
    // overlay), the axisless table one pseudo-run over the index.
    // `built` separates "computed" from "not computed".
    struct DecimKeep {
        std::vector<RunKeep> runs;
        bool built = false;
    };
    // The shared key of the keep lists: which table/run, which x window
    // (the effective view - the slice the keeps were decimated over),
    // which pixel budget (the plot's inner width). An exact-window
    // compare is sound: the window only moves through discrete
    // gestures, and the auto fit is recomputed deterministically from
    // immutable axis ends.
    std::size_t decim_for = kNoTable;
    std::uint64_t decim_run = 0;
    double decim_lo = 0.0;
    double decim_hi = 0.0;
    std::size_t decim_budget = 0;
    std::vector<DecimKeep> decim;

    struct SeriesGeometryKey {
        std::uint64_t run = 0;
        std::size_t table = kNoTable;
        double decim_x_lo = 0.0, decim_x_hi = 0.0;
        std::size_t decim_budget = 0;
        double x_lo = 0.0, x_hi = 0.0;
        double y_lo = 0.0, y_hi = 0.0;
        // SIZES only: the buffer holds the series relative to the frame's
        // top-left, so where the frame sits on screen (a panel scroll,
        // a layout shift above the plot, a docked window moving) is no
        // part of the key - the replay places it.
        float plot_w = 0.0f, plot_h = 0.0f;
        float frame_w = 0.0f, frame_h = 0.0f;
        float width = 0.0f;
        canvas::StrokeJoin join = canvas::StrokeJoin::round;
        std::uint32_t color = 0;
        bool operator==(const SeriesGeometryKey&) const = default;
    };
    struct SeriesGeometry {
        SeriesGeometryKey key;
        bool built = false;
        canvas::TessBuffer buffer;
    };
    // One retained tessellation per signal, in FRAME-LOCAL space (the
    // origin is the plot frame's top-left; the replay adds it back). A
    // hit can replay its quads directly without remapping or CPU
    // tessellation; TessBuffer::clear retains capacity when a key
    // changes.
    std::vector<SeriesGeometry> geometry;

    // The series/sparkline point scratch: one buffer reused across
    // signals and frames (a fresh vector per series per signal was
    // 2 x signals heap round-trips a frame for nothing - the canvas
    // consumes points synchronously, so no draw holds them).
    std::vector<canvas::Point> scratch_pts;

    // E1's persistent markers: sample indices meant to be planted by a
    // click (a sub-threshold left release in the frame - a drag is a
    // zoom, a click is a question), at most `kMaxMarkers` of them. The
    // hover answers while the pointer rests; a MARKER stays for the
    // readout the legend spells beside each signal row (the "exact
    // value at a point I choose" the hover alone cannot keep).
    // NOTE: nothing plants them yet - the click handler E1 describes was
    // never written (the plot PNG export is the one reader). Their
    // lifecycle is in place for when it is: per-table view state beside
    // `visible`/`view`, same key shape - dropped on a table switch
    // (sync_view) and on a delivery (begin_delivery).
    static constexpr std::size_t kMaxMarkers = 8;
    std::vector<int> markers;
    std::size_t markers_for = kNoTable;  // the table `markers` belong to

    // A run was just delivered into `run` (the caller assigned it):
    // every piece of per-delivery state resets HERE, in one place. The
    // app's delivery block and each test bench used to copy this list by
    // hand and had to be kept in step - the markers' reset was forgotten
    // in all of them.
    void begin_delivery() {
        // A new run_id re-keys the per-signal stats, the decimation keeps
        // and the retained geometry (a same-indexed table of the new run
        // is a different table even where the address matches).
        ++run_id;
        visible_for = kNoTable;
        visible.clear();
        x_sorted_for = kNoTable;
        x_runs_for = kNoTable;
        hover = -1;
        // A fresh run's waveforms start on the auto fit: the old plot's
        // zoom/pan window, any in-flight gesture and the markers belong
        // to numbers that no longer exist.
        view = PlotView{};
        view_for = kNoTable;
        gesture = PlotGesture{};
        markers.clear();
        markers_for = kNoTable;
    }
};

// One editable field's caller-owned buffer (the Properties panel's
// editing state): the bytes the text_input edits, the model value it
// loaded from, and the epoch it loaded at - an epoch move (a selection
// change, an undo/redo landing) reloads it; a typing frame never does.
struct FieldBuf {
    // Text fields grow to fit the value they load. A fixed 128-byte
    // buffer silently discarded the tail of long .model/.include cards
    // as soon as the user edited any character.
    std::vector<char> buf = std::vector<char>(128, '\0');
    std::string shadow;
    std::uint64_t stamp = 0;
    bool combo_open = false;  // the Choice rows' dropdown state
};

// --- the interactive canvas: how the run paints back -------------------------

// The wires' paint mode. Plain is the classic single-ink look; Nets
// gives every net its own wheel color (the drawing reads back the
// connectivity - which pins share a net is visible at a glance);
// Voltage rides the LAST run's node voltages as a blue-gray-red ramp
// (needs results; unknown nets fall back to the plain ink). Editor view
// state, not document state: it survives a document switch like the
// palette's search does, because "how this user reads a canvas" is the
// same question in the next schematic.
enum class WireColorMode : std::uint8_t { Plain, Nets, Voltage };

// The .tran/.dc playback: the transport strip's playhead, in the
// sweep table's OWN axis units - seconds for a .tran, the swept
// source's value for a .dc. A paused canvas shows the sample at
// playback.t (a delivery parks it at the run's END - the settled
// state, what an .op reader means by "the answer"); playing sweeps
// t across the table's window at a pace that fits the whole run into
// ~4 s of wall clock (the rate below stretches or shrinks that),
// looping. The voltage coloring and the LED glow both read the
// playhead's sample, so a playing transient animates the canvas -
// and the Results plot wears the same playhead as a swept cursor
// line (one clock: the canvas strip and the plot's transport row
// scrub the same field, so no two surfaces can disagree).
struct Playback {
    static constexpr double kLoopSeconds = 4.0;  // wall clock per sweep
    bool playing = false;
    double t = 0.0;
    // The sweep's pace, off ws::circsim's rate ladder (1/4, 1/2, 1, 2
    // - overlay.hpp): 1x fits the run into kLoopSeconds, 2x halves
    // the wall clock, 1/4x stretches it. The transport strip's rate
    // chip and the Results row's cycle the same field.
    double rate = 1.0;
};

// --- the editor ----------------------------------------------------------------

struct Editor {
    // Wiring, set once at setup (borrowed; the app owns every piece).
    ws::circsim::SymbolLibrary library;  // built-ins (a .csim layer is a later stage)
    ws::ui::shell::AppShell* shell = nullptr;   // toasts + status
    ws::jobs::JobSystem* jobs = nullptr;
    ws::ui::r2d::Font* font = nullptr;          // the UI face
    ws::ui::r2d::Font* font_mono = nullptr;     // the netlist panel's face
    // The canvas labels' face: the UI face's own SDF bake (same face,
    // same advances, distance-field pages). Null falls the labels back
    // to `font`, so a test build (or a failed bake) keeps the bitmap
    // path. The canvas panel uses it for the world-space text only;
    // chrome rows keep `font`'s texel-on-pixel snap.
    ws::ui::r2d::Font* font_canvas = nullptr;
    gui::Toasts* toasts = nullptr;              // the shell's store
    std::function<void(std::string)> set_status;
    // Backing store for toast text. Toasts BORROWS the bytes, so every
    // toast needs a string of its own whose address stays put until the
    // toast expires (a deque never moves its elements on push/pop at
    // the ends). Bounded: the oldest entries are long expired by the
    // time the cap recycles them (4s toasts, 16 slots).
    mutable std::deque<std::string> toast_text_;
    // The Results panel's export button: true = JSON, false = CSV.
    // The app installs it (the path policy - derive from the
    // document, write through the fs seam - is the app's to own).
    std::function<void(bool json)> export_results;
    // E3's scoped pair: the SHOWN table only (the button beside the
    // selector says its scope), and the plot as a PNG (the visible
    // series, axes and ticks rendered headless through RasterCanvas -
    // the plot carries itself out of the panel). Same install shape
    // as export_results; unset (the headless bench) simply disables
    // the buttons.
    std::function<void()> export_table_csv;
    std::function<void()> export_plot_png;

    // The active document (null = none open). The app re-points this
    // on every activation change and calls document_changed().
    SchematicDocument* doc = nullptr;

    // The interaction state.
    Tool tool = Tool::Select;
    std::string place_symbol;  // the armed symbol key
    int ghost_rot = 0;
    bool ghost_mirror = false;
    char label_text[64] = "net";
    // The Palette panel's view state: the search box, and the groups
    // the user collapsed (open is the default, so a new group shows).
    char palette_filter[48] = "";
    std::set<std::string> palette_closed;
    // The Palette's layout: false = the compact picture-tile grid, true =
    // one named row per symbol (names visible without hovering).
    bool palette_list_view = false;
    // The Palette's recently-armed symbols, newest first, capped at
    // six. Editor-lifetime convenience state, not document state: a
    // document switch keeps it ("what did I place last?" is the same
    // question in the next schematic), and each Editor owns its own -
    // the file-static list it replaces was process-wide, so two
    // editors (the app and a test bench) shared one history.
    std::vector<std::string> palette_recent;
    Selection sel;
    // The multi-selection and the box gesture (see BoxSelect/
    // Clipboard above). The box arms on a Select-tool press over
    // empty space and lands its set at release; Shift extends the
    // landing (and a shift-click toggles one entity) instead of
    // replacing.
    std::vector<Selection> multi;
    BoxSelect box;

    // The interactive canvas's view state: the wire paint mode and the
    // .tran playback (see WireColorMode / Playback above). The
    // transport scrub's drag arm rides beside the playback - a scrub in
    // flight owns the pointer the way the pan drag does.
    WireColorMode wire_colors = WireColorMode::Nets;
    Playback playback;
    bool transport_scrub = false;
    // The origin crosshair (the grid's x=0/y=0 axis lines + origin
    // marker), hidden by default - a full-length crosshair reads as
    // structure crossing the schematic. View menu > "Show Origin
    // Axes"; editor view state like wire_colors, so it survives a
    // document switch.
    bool show_origin_axes = false;
    // Part annotations on the canvas: the refdes always (it is the
    // part's name), the value/model line beside it. On by default -
    // the classic EDA look; View menu > "Show Part Values", and a
    // per-part row in Properties (annotate_off) opts one part out.
    bool show_part_values = true;
    // The Results panel's transport row scrub, the strip's own rule: a
    // press in the row's track arms it, the drag owns the pointer
    // until release, and both surfaces write the one playback above -
    // a scrub on the plot animates the canvas, and back.
    bool results_scrub = false;
    // The move-drag (press to release). `live` writes the position
    // directly (no undo) while the pointer holds; the command lands at
    // release with the captured from/to.
    struct Drag {
        enum class Kind : std::uint8_t { None, Part, Junction, Label };
        Kind kind = Kind::None;
        std::uint32_t id = 0;
        Pos start_world{0.0, 0.0};
        Pos grab_offset{0.0, 0.0};  // world: press point - entity pos
        bool moved = false;         // past the click threshold
    } drag;

    // The GROUP move-drag: a press on an entity already in the
    // working set (when the set holds more than the anchor) drags
    // the whole set as one. Every member's press-time position is
    // captured here; the live drag moves them by the (grid-snapped)
    // DELTA so relative geometry never distorts, and the release
    // lands ONE undo step over all of them (the attached ortho wires
    // re-routed once, at the landing). The pressed entity's own
    // target rules the snap - the same "no jump under the pointer"
    // the single drag keeps.
    struct GroupDrag {
        bool active = false;
        std::vector<Selection> set;   // the working set at press
        std::vector<Pos> starts;      // parallel: positions at press
        std::size_t pressed = 0;      // index into set: the pressed one
        Pos grab_offset{0.0, 0.0};    // world: press point - its pos
        Pos start_world{0.0, 0.0};    // the press point
        bool moved = false;
    } group_drag;

    // The clipboard (see Clipboard above) - copy fills it, paste (and
    // duplicate, its one-liner) reads it.
    Clipboard clipboard;

    // The wire draft (the Wire tool between its two clicks).
    struct WireDraft {
        bool active = false;
        ws::circsim::WireEndpoint a{};
        Pos a_pos{0.0, 0.0};
        int a_dir = 0;  // the start pin's direction, -1 when free
        // A start with no entity behind it (a wire's body - stage
        // 18b - or free space - stage 19f): the start endpoint is not
        // a pin or junction, so the commit mints a junction at `a_pos`
        // and binds the new wire's `a` to it - the same path the
        // commit-side wire-point takes, just deferred past a cancel.
        // a_wire is the id of the wire that was hit when the draft
        // started; the commit validates that the same wire still
        // exists at that position. `a_free` marks the free-space
        // flavor: no anchor wire to revalidate (the point is just a
        // grid position; it cannot go stale).
        bool a_mint = false;
        bool a_free = false;
        std::uint32_t a_wire = 0;
        // Which way the route's corner bends: false = horizontal
        // first (the stock L), true = vertical first. The panel flips
        // it on Tab while a draft is live and passes it to route_wire
        // for BOTH the preview and the commit, so what you see is what
        // lands. Cleared with the draft.
        bool flip_route = false;
        void flip() { flip_route = !flip_route; }
    } wire_draft;

    // True when the last frame's Properties draw saw a focused text
    // field - the chord loop then resolves at the text_editing rung so
    // the panel keys stay out of the field (one frame of settle, the
    // same cadence every gui claim rides).
    bool text_field_focused = false;

    // The camera + the caches.
    EditorView view;
    ProblemsCache problems;
    // The Problems panel's cursor: the diag index the row highlight
    // stands on and the Prev/Next walk steps from (-1 = none). It
    // indexes problems.diags and resets wherever that list is replaced
    // (refresh_problems, document_changed) - a cursor left over from a
    // replaced check would highlight a stranger's row.
    int problems_cursor = -1;
    // The severity filter's three toggles, all on by default: the walk
    // and the row draw both skip a hidden severity, while the header's
    // counts stay the full counts whatever is hidden.
    bool problems_show_error = true;
    bool problems_show_warning = true;
    bool problems_show_note = true;
    NetlistCache netlist;
    ResultsCache results;

    // auto_junction_dots' answer - empty since the partition rule
    // landed (the old coincidence rules minted silent joins; the new
    // rule connects by authored structure only, and the NetBuild
    // silent_joins field no longer exists). Kept as the draw seam.
    std::vector<std::pair<Pos, std::uint32_t>> join_dots_;

    // The canvas's own net build: one build_nets per edit (the same seam
    // ERC and the export read), cached against the schematic version.
    // The wire coloring and the auto-junction dots both read it.
    ws::circsim::NetList nets_cache_;
    std::uint64_t nets_version_ = 0;
    bool nets_valid_ = false;

    // part_bounds cache: per-part world AABBs keyed by part id,
    // invalidated when the schematic version changes.
    mutable std::map<std::uint32_t, Bounds> part_bounds_cache_;
    mutable std::uint64_t bounds_version_ = 0;
    mutable bool bounds_valid_ = false;
    mutable std::unordered_map<std::uint32_t, WireGeom> wire_geom_cache_;
    mutable std::uint64_t wire_geom_version_ = 0;
    mutable bool wire_geom_valid_ = false;

    // The drag overlay seam (schematic-current.md's rewrite): the ONE
    // routing answer a live drag and its release both read. While a
    // drag moves, the canvas rebuilds the adapter view, builds the
    // session from the input, and resolves the OVERLAY once per frame;
    // the PREVIEW draws doc + overlay, and the RELEASE lands the SAME
    // overlay's landing() through one undo command. adapter_ holds the
    // built view (rebuild_drag_overlay() refreshes it); overlay_ the
    // pure answer; overlay_valid_ gates it off outside a live drag.
    editor::SchematicAdapter adapter_;
    ws::sch::Overlay overlay_;
    bool overlay_valid_ = false;
    // The cached PRESS-pose view: what the drag is built from (kinds /
    // ids / press positions / the schematic) and the schematic version
    // it is consistent with. The press geometry never changes during a
    // drag, so the view is built once per drag, not once per frame; only
    // the session (the live landings) and the resolve run per frame.
    struct DragViewKey {
        const ws::circsim::Schematic* schem = nullptr;
        std::vector<std::uint32_t> kinds;  // 1 part, 3 junction (per member)
        std::vector<std::uint32_t> ids;
        std::vector<ws::circsim::Pos> starts;
    };
    DragViewKey view_key_;
    bool view_valid_ = false;
    std::uint64_t view_version_ = 0;
    std::uint64_t drag_view_builds_ = 0;
    // The live landings the cached overlay_ answers (an idle frame - the
    // pointer held still - reuses it instead of re-resolving).
    std::vector<ws::circsim::Pos> live_key_;
    bool live_key_valid_ = false;

    // The Properties panel's editing state: the field buffers keyed
    // by stable strings, the epoch that reloads them, the selection
    // they were built for, and the analysis entry being edited. The
    // tab strip's selection rides beside them (0 Properties, 1
    // Netlist, 2 Simulation) - caller-owned state the tab_bar writes,
    // surviving frames and document switches like every panel view.
    std::map<std::string, FieldBuf> fields;
    std::uint64_t field_stamp = 1;
    int fields_sel_kind = -1;
    std::uint32_t fields_sel_id = 0;
    int analysis_index = -1;
    int properties_tab = 0;
    // D2: the Properties tab's collapsed "Part details" section - the
    // debug-shaped rows (the position readout) live behind it, closed
    // by default so prime space stays with the editable fields. View
    // state like the tab selection, not circuit state: it survives
    // frames and selection moves, and nothing on the undo stack knows
    // it exists.
    bool part_details_open = false;
    // The Properties panel's Annotation section (nudge / hide / reset):
    // view state beside part_details_open, collapsed by default so the
    // fields the user edits come first.
    bool annotation_open = false;

    // Bumps the edit epoch (the app wires the undo stacks' listeners
    // here, so an undo/redo lands back into the field rows).
    void bump_edit_epoch() { ++field_stamp; }

    // The pan drag's arm state (middle / space+left).
    struct Pan {
        bool armed = false;
        ws::math::Vec2 from{0.0f, 0.0f};
    } pan;

    // THE TOUCH GESTURE SEAM (the ws::gestures rewrite): the arbiter
    // that turns multi-touch frames into view actions. A finger is not
    // a mouse - the InputFrame bridges the first touch as button 0,
    // which is exactly what would make the first finger of a pinch arm
    // a tool. So while the arbiter holds contacts (Touching, Drag,
    // Pinch, LongPress) the pointer handler MUST NOT read the bridged
    // mouse as a click source; the ONLY click it may honor is the
    // arbiter's own deferred tap, answered at the finger's LIFT frame
    // (and never for a contact that rode a pinch). Pinch frames apply
    // zoom_at (span ratio toward the finger mid) and pan_by (the mid
    // drift) directly - the same calls the wheel and the pan drags
    // already make, so the camera code stays single-pathed.
    ws::gestures::TouchArbiter touch;
    // The deferred tap's landing (screen px), set by the gesture pass
    // on the finger's lift frame and consumed by the pointer handler's
    // one-frame replay (a LEFT press+release at the point) - exactly
    // once, the same frame it was answered.
    bool touch_tap_pending = false;
    ws::math::Vec2 touch_tap_at{0.0f, 0.0f};
    // The one-finger drag's deferred press (the slop crossing point),
    // replayed as the mouse path's own LEFT press edge on the drag's
    // first frame - the finger's contact keeps the button held through
    // the platform's bridge from there, so the drag follows exactly the
    // mouse drag's own machinery. touch_drag_id names the contact whose
    // drag owns the replay (kNoPointer = none).
    bool touch_press_pending = false;
    ws::math::Vec2 touch_press_at{0.0f, 0.0f};
    ws::input::PointerId touch_drag_id{ws::input::kNoPointer.value};

    // --- the frame tick, the locate pulse, the panel's key edges ---------
    // The Schematic panel calls tick() once per frame: it advances the
    // smooth camera and the pulse by the REAL elapsed time (steady
    // clock, clamped to 100 ms so a stalled frame never teleports the
    // view). It returns true while something is still moving - the app
    // may use that to keep requesting frames.
    [[nodiscard]] bool tick();
    // The last tick()'s answer: true while the camera glide, the locate
    // pulse or a playing sweep is still moving. The Schematic panel sets
    // it each frame it draws; the app clears it at the top of on_update,
    // so a panel that is no longer drawn cannot leave a stale "yes"
    // behind. Idle-frame pacing reads it (CircsimApp::wants_frame).
    bool animating = false;

    // The locate pulse: a ring that blooms at a world point and fades
    // (jump_to and zoom_to_selection fire it, so "where did the view
    // just go?" answers itself). Drawn by the panel, skipped when the
    // theme's motion is off.
    struct Pulse {
        static constexpr double kLife = 0.9;  // seconds
        bool active = false;
        Pos pos{0.0, 0.0};
        double age = 0.0;
    } pulse;
    void pulse_at(Pos p) {
        pulse.active = true;
        pulse.pos = p;
        pulse.age = 0.0;
    }

    // Key-edge memory for the panel's own shortcuts (F frames the
    // selection, / flips the wire corner): "was down last frame".
    bool key_frame_prev_ = false;
    bool key_flip_prev_ = false;
    bool key_tidy_prev_ = false;
    bool key_annotate_prev_ = false;
    // Alt+Arrow nudges (C1): one slot per direction so a held nudge
    // fires once per press edge (repeat is the panel's own policy).
    // 0=Up, 1=Down, 2=Left, 3=Right, 4=Reset (Shift+R in the patch,
    // but we reuse the same array - the reset chord is wired in
    // handle_pointer and reads key_nudge_prev_[4]).
    std::array<bool, 5> key_nudge_prev_ = {false, false, false, false, false};

    // Quiet toasts: an identical toast pushed while its twin is still
    // on screen is dropped instead of stacking (a command mashed ten
    // times used to paint ten copies). Off switch for tests.
    bool dedupe_toasts = true;
    mutable std::string last_toast_;
    mutable std::chrono::steady_clock::time_point last_toast_until_{};
    std::chrono::steady_clock::time_point last_tick_{};
    bool tick_started_ = false;

    // The canvas the schematic panel renders through (one per
    // editor; the canvas layer's own state is per-instance).
    canvas::Renderer2DCanvas renderer;

    // The Results panel's draw seam: null = &renderer (the live app);
    // a headless test injects a CommandListCanvas here and asserts the
    // plot geometry the panel emits (the same purity seam the gui
    // suite rides - the results panel is app code, so the injection
    // point is a member, not a link-time stub).
    canvas::Canvas2D* plot_canvas = nullptr;

    // The canvas the Results panel draws through.
    [[nodiscard]] canvas::Canvas2D& results_draw_canvas() {
        return plot_canvas != nullptr ? *plot_canvas : renderer;
    }

    // The Schematic panel's draw seam: the same pattern one panel over
    // - null = &renderer (the live app), a headless test injects a
    // CommandListCanvas and asserts the camera mapping the panel
    // emits (every element must land where EditorView::w2s answers -
    // the grid, the snap feedback and the picks speak that mapping).
    canvas::Canvas2D* canvas_panel_canvas = nullptr;

    // The canvas the Schematic panel draws through.
    [[nodiscard]] canvas::Canvas2D& schematic_draw_canvas() {
        return canvas_panel_canvas != nullptr ? *canvas_panel_canvas
                                              : renderer;
    }

    // The Palette panel's draw seam: the same pattern a third time.
    // The palette's tiles draw the symbols' pictures directly, so the
    // seam exists for the same reason the other two do - null =
    // &renderer (the live app); a headless test injects a
    // CommandListCanvas here and asserts the tile grid's geometry
    // (fills, outlines, the fitted symbol strokes) without a renderer.
    canvas::Canvas2D* palette_canvas = nullptr;

    // The canvas the Palette panel draws through.
    [[nodiscard]] canvas::Canvas2D& palette_draw_canvas() {
        return palette_canvas != nullptr ? *palette_canvas : renderer;
    }

    // The Properties panel's draw seam: the same pattern a fourth
    // time. The source editor's waveform preview draws through here -
    // null = &renderer (the live app); a headless test injects a
    // CommandListCanvas and asserts the preview's geometry (the well,
    // the frame, the zero line, the series polyline) the same way the
    // palette and results suites assert theirs.
    canvas::Canvas2D* properties_canvas = nullptr;

    // The canvas the Properties panel draws through.
    [[nodiscard]] canvas::Canvas2D& properties_draw_canvas() {
        return properties_canvas != nullptr ? *properties_canvas : renderer;
    }

    // --- helpers (editor.cpp) ---

    [[nodiscard]] ws::circsim::Schematic* schem() {
        return doc != nullptr ? &doc->schem : nullptr;
    }
    [[nodiscard]] const ws::circsim::Schematic* schem() const {
        return doc != nullptr ? &doc->schem : nullptr;
    }

    [[nodiscard]] const ws::circsim::SymbolDef* sym_of(
        const ws::circsim::Part& p) const;

    // The grid spec the canvas panel draws AND snap() reads - one
    // source of truth (ws::ui::canvas::GridSpec): the base spacing is
    // the schematic's own grid (Schematic::grid, default 1), the
    // major interval the x5 ladder. The panel paints its theme's
    // grid tokens over the faces; the spacing answers both halves.
    [[nodiscard]] canvas::GridSpec grid_spec() const;

    // Snap to the grid spec's fine lattice - the same one the drawn
    // dots mark. `coarse` snaps to the major lattice instead (base *
    // major_interval, an integer multiple: a coarse position is
    // always a fine position too, so wires, pins and junctions can
    // never leave the fine grid). The wire tool and junction drags
    // always pass false; the Shift modifier carries the coarse
    // placement/drag snap.
    [[nodiscard]] Pos snap(Pos world, bool coarse = false) const;

    // The part's world AABB (the transformed symbol bounds).
    [[nodiscard]] std::optional<Bounds> part_bounds(std::uint32_t id) const;

    // The wire's world polyline (endpoints through their refs, then
    // the waypoints between).
    [[nodiscard]] std::vector<Pos> wire_path(
        const ws::circsim::Wire& w) const;
    [[nodiscard]] const WireGeom& wire_geom(const ws::circsim::Wire& w) const;

    // The drag overlay seam: rebuilds the adapter view + resolves the
    // overlay for the CURRENT drag state (part / junction / group; the
    // drag's own live positions are the landings). Answers nullptr
    // when no drag is live (or the schematic is null) - the caller
    // draws the stored geometry instead. The release reads the SAME
    // overlay through drag_overlay_landing() + the drops() the drag
    // showed, so preview and commit are one value.
    [[nodiscard]] const ws::sch::Overlay* drag_overlay();
    // The canvas's drag writers call this INSTEAD of s.bump(): a drag
    // frame only moves positions, so the press-pose view drag_overlay()
    // cached stays valid across the bump - unless something ELSE
    // (undo, a panel edit) changed the schematic since the view was
    // built, in which case the next drag_overlay() rebuilds it.
    void drag_bump(ws::circsim::Schematic& s);
    // How many times a drag has (re)built the adapter view: once per
    // drag while nothing else changes the schematic (the frame-cost
    // regression reads this).
    [[nodiscard]] std::uint64_t drag_view_builds() const {
        return drag_view_builds_;
    }
    // The overlay's wire ids keyed by the CIRCSIM wire id (the draw
    // loop and any consumer holding circsim ids needs this to index
    // overlay->wirePath, whose keys are the adapter's sch ids).
    [[nodiscard]] const std::map<std::uint32_t, ws::sch::WireId>*
    drag_overlay_wire_ids() {
        return overlay_valid_ ? &adapter_.wire_ids : nullptr;
    }
    // The release-side translation of the live overlay: what the ONE
    // command writes (junction positions + fresh wire waypoints, in
    // circsim ids) + the connect-on-drop candidates the drag showed.
    // Valid only right after a drag_overlay() that answered live.
    [[nodiscard]] editor::SchematicAdapter::Landing drag_overlay_landing() const;
    [[nodiscard]] std::vector<editor::SchematicAdapter::Drop> drag_overlay_drops() const;
    [[nodiscard]] SelectionIndex selection_index() const {
        return SelectionIndex{sel, multi};
    }

    // The ortho route for a wire from `a` (leaving along `a_dir`, -1 =
    // free) to `b` (approached along `b_dir`, -1 = free): the waypoint
    // list between the two endpoints - a leads out, an L lands,
    // collinear legs folded away (a reversal keeps its lead-out
    // corner; folding it would run the wire back through the part
    // body it just left). `flip` bends the corner the other way
    // (vertical-first instead of horizontal-first) - the Tab toggle;
    // it only matters when the route needs a corner at all.
    [[nodiscard]] static std::vector<Pos> route_wire(Pos a, int a_dir,
                                                     Pos b, int b_dir,
                                                     bool flip = false);

    // (attached_wire_routes/wire_pin_spots are deleted with the
    // geom.cpp family: the drag/release/rotate read the ONE overlay
    // through drag_overlay() - the adapter seam above.)

    // Hit tests (world space). The pin hit radius is in world units
    // (screen px / zoom), so picks stay steady across zooms.
    [[nodiscard]] std::optional<PinHit> hit_pin(Pos world,
                                                double radius) const;
    // A DIFFERENT part's pin sitting exactly at `at` (within eps):
    // the wire tool's coincident-pin resolution - when the snap's pin
    // hit names the draft's own start pin and another pin is mated at
    // the same coordinates, this one answers it. nullopt when the
    // spot carries only the named pin.
    [[nodiscard]] std::optional<PinHit> hit_other_pin_at(
        Pos world, double radius, const ws::circsim::PinRef& exclude,
        Pos at) const;
    [[nodiscard]] std::optional<std::uint32_t> hit_junction(
        Pos world, double radius) const;
    // A point on an existing wire's path within `radius` of `world`
    // (stage 18b): the nearest grid-aligned point lying on some wire's
    // polyline, falling back to the nearest path vertex when the grid
    // snap would drift off the segment. The returned point is bit-equal
    // to a position the wire's path passes through, so nets.cpp's
    // exact-double on_polyline accepts it when the editor mints a
    // junction there. The wire tool snaps a click near another wire's
    // body to this point and connects through that junction - the
    // standard EDA T-tap, the one thing the wire tool was missing.
    // The T-tap snap's answer - ws::circsim::WirePointSnap (geom.hpp),
    // aliased so `Editor::WirePointSnap` keeps spelling the same type
    // the panels and tests always named.
    using WirePointSnap = ws::circsim::WirePointSnap;
    [[nodiscard]] std::optional<WirePointSnap> hit_wire_point(
        Pos world, double radius) const;
    [[nodiscard]] Selection hit_any(Pos world, double radius) const;

    // The whole schematic's content extent (for the fit command).
    [[nodiscard]] std::optional<Bounds> content_bounds() const;

    // Tidy: re-straightens ortho wires. tidy_route() is the pure core -
    // given a wire's full world path (endpoint, waypoints, endpoint) it
    // returns the cleaned INTERIOR waypoints: every diagonal leg gets an
    // axis-aligned corner, duplicate points and collinear continuing
    // middles fold away, the rest of the author's shape is kept (a
    // gentle fix-up, not a re-route). tidy_selection() applies it, as
    // ONE undo step, to the selected wire - or to every wire on the
    // selected part or junction - and returns how many changed. Freeform
    // (non-ortho) wires are the author's and are left alone.
    [[nodiscard]] static std::vector<Pos> tidy_route(
        const std::vector<Pos>& path);
    std::size_t tidy_selection();

    // Rotate / mirror a placed part to the GIVEN orientation (the caller
    // owns the rot/mirror semantics - this does not guess the units) and
    // keep its ortho wires straight, all as ONE undo step. The part
    // visits the new orientation, the attached wires re-route from the
    // pins' resolved positions there, then it goes back so the command
    // captures the real "was" (the drag-release trick). False when the
    // part is gone or there is no document.
    bool transform_part(std::uint32_t id, int rot, bool mirror,
                        std::string name);

    // Annotate: renumbers every part that has a reference prefix
    // (R, C, U...) 1..N per prefix in reading order - top to bottom in
    // rows, left to right within a row - as ONE undo step. Parts whose
    // ref is custom (not prefix+digits, e.g. "R_load") are left alone
    // and never collide, since generated refs are always prefix+digits.
    // Rows: parts within `row_tol_cells` grid cells of the row's top
    // part share a row (hand-placed symbols are rarely pixel-exact).
    // Warns when a renamed ref is named in the directives. Returns how
    // many refs changed.
    std::size_t annotate(double row_tol_cells = 2.0);
    // The pure ordering core: indices into `at` in reading order.
    [[nodiscard]] static std::vector<std::size_t> annotation_order(
        const std::vector<Pos>& at, double row_tol);

    // The current selection's world extent (nullopt = nothing selected
    // or the selection's entity is gone), and the "frame selected"
    // command built on it: fits the selection with `margin` grid units
    // of air (a lone junction/label just centers, keeping the zoom).
    // Returns false (with a status hint) when there is nothing to frame.
    [[nodiscard]] std::optional<Bounds> selection_bounds() const;
    bool zoom_to_selection(double margin = 3.0);

    // --- the working set (the group edit's face) -------------------------
    //
    // The primary `sel` plus `multi`, deduped, in a stable order
    // (parts, wires, junctions, labels - the schematic's own deque
    // order within each kind). Ids the schematic no longer finds
    // (an undo landed under the selection) are dropped, so the set
    // is always honest to act on.
    [[nodiscard]] std::vector<Selection> selection_set() const;
    // True when `of` is in the working set (the drag's "move the
    // group" test on press).
    [[nodiscard]] bool in_selection(const Selection& of) const;
    // The single-entity select (a plain click): the anchor moves, the
    // multi set clears.
    void set_selection(const Selection& of);
    // A shift-click on an entity: toggles it in the multi set; the
    // anchor follows a joining entity (the Properties panel shows
    // what was just added), and the last toggle out clears the
    // anchor when it was the one leaving.
    void toggle_selection(const Selection& of);
    // The box's landing: every part whose bounds, wire whose path,
    // junction and label whose position the world rectangle touches.
    // Shift extends the current set; plain replaces it. The anchor
    // becomes the first part in the box (else the first wire,
    // junction, label), or the set empties entirely.
    void select_box(const BoxSelect& box, bool extend);

    // --- copy / paste / duplicate -----------------------------------------
    //
    // Copies the working set into the clipboard (empty answer: false,
    // with a status word). Paste lands a fresh-id, offset copy at
    // `at` - the cursor-relative rule: the clipboard's center rides
    // `at`, so a paste lands under the pointer wherever it is; the
    // offsets are grid-snapped so parts land ON the lattice. Refs
    // renumber through next_ref against the live schematic (R1
    // pasted beside R1 becomes R2); custom refs and power symbols
    // keep theirs. Both answer the pasted set (empty = nothing to
    // paste / a refused command), and the pasted entities become the
    // new working selection.
    bool copy_selection();
    std::vector<Selection> paste_clipboard(Pos at);
    // Ctrl+D's body: copy, then paste at the set's center nudged by
    // (2, -2) grid cells - one step apart, the standard EDA offset.
    std::vector<Selection> duplicate_selection();

    // --- the probe tool ----------------------------------------------------
    //
    // Click a net (a wire, a junction, a pin, a label) to toggle its
    // v(net) curve in Results; click a part's BODY to toggle its
    // i(element) current curve. The Results panel switches to the
    // table that carries the signal (the plot follows the probe),
    // the curve's visibility flips, and the answer is the status
    // line ("probe: v(out) shown" - the toast's own words). The
    // locate pulse fires at the click so the canvas answers too.
    // `radius` is the pick radius in world units (the canvas's own).
    [[nodiscard]] std::string probe_at(Pos world, double radius);

    // The Place tool's "pin magnetism": the snapped position for a
    // ghost of `sym` at `world`, nudged so the ghost's nearest pin
    // lands exactly on an existing pin within `magnet_radius` (world
    // units; <= 0 turns it off and this is just snap()). A part dropped
    // near another one mates pin-to-pin instead of a cell off.
    [[nodiscard]] Pos place_snap(const ws::circsim::SymbolDef& sym, Pos world,
                                 int rot, bool mirror, bool coarse,
                                 double magnet_radius) const;

    // A one-line, context-sensitive hint for the status bar - what the
    // pointer and keys do RIGHT NOW (tool, draft, drag). Static text,
    // safe to call every frame; the app feeds it to its status line.
    [[nodiscard]] std::string_view hint() const;

    // Select-and-zoom for a Problems row (locate.hpp's seam).
    void jump_to(const ws::circsim::DiagTarget& t);

    // Cache refreshers (the commands' act; synchronous - ERC and the
    // export are millisecond work at editor scales). `version` is the
    // schematic version the check ran AGAINST: the synchronous ERC
    // path passes the live version; a delivered run passes the version
    // its job snapshot carried at submit time, so an edit that landed
    // mid-run leaves the Problems panel honestly stale instead of
    // re-stamping itself fresh.
    void refresh_problems(bool from_run,
                          std::vector<ws::circsim::Diag> diags,
                          std::string header, std::uint64_t version);
    void run_erc();
    void refresh_netlist();

    // The canvas' auto-junction dots (stage 18): the silent joins the
    // net rules make - pins a wire's path picked up, vertices T-riding
    // another wire - cached against the schematic version, one rebuild
    // per edit, not per frame. Each dot pairs with the NET it landed on
    // (the id net_cache answers), so the canvas can paint it in the
    // net's color.
    [[nodiscard]] const std::vector<std::pair<Pos, std::uint32_t>>&
    auto_junction_dots();

    // The canvas's net build (the auto-junction dots' own seam, shared):
    // one build_nets per edit, cached against the schematic version.
    // The wire coloring reads it; ERC and the export keep their own
    // builds (the same millisecond work, independent staleness).
    [[nodiscard]] const ws::circsim::NetList& net_cache();

    // The canvas's sweep table: the Results panel's selected table
    // when the transport scrubs it (a .tran time axis or a .dc swept
    // source), else the run's first scrubbable table - what the
    // transport strip scrubs and the playback animates. Null when
    // the run has no such table (or no run at all); the playhead's
    // units are the table's own axis (seconds, or the swept source's
    // volts/amps).
    [[nodiscard]] const ws::spice::Table* canvas_sweep_table() const;

    // The table's sample the canvas should show: the playback playhead
    // resolved onto the time axis (a .tran axis is strictly increasing;
    // the LAST sample at or before t, clamped to the ends). For a
    // non-time table the answer is its last row - the sweep's end, the
    // state an .op reader means by "the answer".
    [[nodiscard]] static std::size_t shown_sample(
        const ws::spice::Table& t, double playhead);

    // Clear every per-document surface (the app calls this when the
    // active document changes).
    void document_changed();

    // The toast pair the commands and panels use. `seconds` is the
    // toast's lifetime (the stock 4s; the chord loop's command errors
    // ask for 5) - the text rides toast_text_'s stable slots either
    // way.
    void toast(std::string text, gui::ToastSeverity severity,
               float seconds = 4.0f) const;
    void status(std::string text) const;

    // --- C1-C4: schematic readability pass (annotation placement engine) ---
    // PartAnnotation: one part's refdes and optional value/model text,
    // plus the symbol's text origin (where the picture's refdes *would*
    // draw if the symbol had a refdes field - the anchor we place the
    // annotation around). The placement engine positions the refdes +
    // value as one tile (the refdes left, value right, one space
    // between), with the refdes anchored at the text origin when
    // possible, else the tile center-below the part. The panel draws the
    // placed tiles verbatim; the part symbol itself draws no text.
    struct PartAnnotation {
        std::uint32_t part_id = 0;
        std::string refdes;
        std::string value;   // the effective value/model line (param fallback)
        Pos text_origin{0.0, 0.0};  // the symbol's declared text origin
        bool has_origin = false;    // true when text_origin came from the symbol
    };

    // TextTile: a placed annotation tile (refdes + value), the screen rect
    // the tile occupies (for collision tests), and the world anchor the
    // tile was placed at (the center of the tile). The placement engine
    // returns a vector of these; the panel iterates and draws each.
    struct TextTile {
        std::string refdes;
        std::string value;
        ws::ui::gui::Rect screen_rect{0.0f, 0.0f, 0.0f, 0.0f};  // screen px
        Pos anchor{0.0, 0.0};                                 // world
    };

    // AnnotObstacles: the world-space shapes that annotations must not
    // overlap - part body AABBs, wire polylines (with a small stroke
    // width buffer), junction dots, and the canvas extents. Built once
    // per frame from the schematic and the current view (only obstacles
    // inside the view + a margin matter).
    struct AnnotObstacles {
        std::vector<Bounds> part_bodies;          // part AABBs (world)
        std::vector<std::vector<Pos>> wire_paths; // wire polylines (world)
        std::vector<Pos> junctions;               // junction positions (world)
        Bounds view_bounds;                       // the visible world rect
    };

    // AnnotPlacement: the output of the placement engine - all placed
    // part tiles, all placed net label tiles, and the obstacles they
    // were placed against (for hit-testing / debugging).
    struct AnnotPlacement {
        std::vector<TextTile> part_tiles;
        std::vector<TextTile> net_tiles;
        AnnotObstacles obstacles;
    };

    // AnnotState: the editor-owned annotation state for one part - the
    // user's per-part nudge (world delta from the engine's answer) and
    // the annotate_off opt-out flag. The engine runs every frame and
    // adds this nudge to its computed position; the Properties panel
    // edits the nudge and the flag. The editor owns the map keyed by
    // part id; a part not in the map has zero nudge and annotate_off
    // false (the default on). The map is editor-lifetime state (survives
    // document switches, so nudges persist like wire_colors).
    struct AnnotState {
        Pos nudge{0.0, 0.0};
        bool annotate_off = false;
    };

    // Annotation state is scoped to this Editor, not process-global:
    // component IDs are allocated per schematic and collide across tabs.
    // Keep annotation edits with their schematic across tab switches;
    // part IDs are only unique inside one schematic.
    mutable std::map<const ws::circsim::Schematic*,
                     std::map<std::uint32_t, AnnotState>,
                     std::less<const ws::circsim::Schematic*>> annot_states_;

    // Placement is expensive (obstacle construction + candidate scoring).
    // Reuse it while every input that affects placement remains unchanged.
    mutable bool annot_placement_cache_valid_ = false;
    mutable std::size_t annot_placement_cache_signature_ = 0;
    mutable AnnotPlacement annot_placement_cache_;

    // AnnotCandidate: one candidate position the engine evaluates for a
    // tile. The tile's screen rect at that candidate, the world anchor,
    // the penalty score (overlap area with obstacles + distance from the
    // ideal anchor + a tiny jitter tie-break), and whether the candidate
    // is inside the view bounds (false = dropped).
    struct AnnotCandidate {
        ScreenRect screen_rect{0.0f, 0.0f, 0.0f, 0.0f};
        Pos anchor{0.0, 0.0};
        double score = 0.0;
        bool in_view = true;
    };

    // True when the tile's screen_rect overlaps any obstacle's screen
    // projection (with a small margin). The obstacles are projected to
    // screen through the current view (the same view the panel uses for
    // culling). Used by the placement engine to score candidates.
    [[nodiscard]] bool annot_blocked(const ScreenRect& tile,
                                     const AnnotObstacles& obs,
                                     const EditorView& editor_view) const;

    // Place all part annotations for the current schematic. Returns an
    // AnnotPlacement with the placed part tiles and net tiles. The
    // engine: builds obstacles from the visible schematic, computes the
    // ideal anchor for each part (text_origin if has_origin, else the
    // part's bounds center-bottom), generates a ring of candidates
    // around the ideal (8 directions x 3 radii = 24 candidates, plus the
    // ideal itself), scores each (obstacle overlap + distance from ideal
    // + jitter), picks the best, applies the per-part nudge from
    // annot_state_of, and stores the placed tile. Net labels: the net
    // name at the net's centroid (the average of all pins/junctions on
    // the net), same candidate ring, same scoring. Parts with
    // annotate_off or no refdes are skipped. The engine is called once
    // per frame from draw_canvas_panel (so it rides the view's culling).
    [[nodiscard]] const AnnotPlacement& place_part_annotation() const;

    // Place net labels (the net name at the net's centroid). Called by
    // place_part_annotation; split for testing.
    [[nodiscard]] std::vector<TextTile> place_net_label(
        const AnnotObstacles& obs, const EditorView& editor_view) const;

    // Get (creating if needed) the annotation state for `part_id`.
    [[nodiscard]] AnnotState& annot_state_of(std::uint32_t part_id);

    // Set the annotation state for `part_id` (the Properties panel calls
    // this when the user edits the nudge fields or toggles annotate_off).
    void set_annot_state(std::uint32_t part_id, const AnnotState& st);

};

// The shared symbol renderer: `draw` prims + pin stubs through a
// canvas, in WORLD space (the canvas transform must be the editor's).
// `pos`/`rot`/`mirror` are the placement; used for placed parts, the
// placement ghost and the palette's previews alike. The geometry is
// ws::circsim::render_symbol's (the stage-17a seam shared with the
// CLI's SVG dump and the lib's tests); this is the painting half -
// strokes to canvas calls. The pin-lead safety net rides the seam: a
// pin no prim vertex touches gets a stub into the body (the .csym
// path's net for symbols whose prims fall short of their pins).
// `switch_closed` (0 = open, 1 = closed) eases the SwitchBlade the
// s/w symbols carry; every static caller (the ghost, the palette
// preview) passes nothing and draws the blade at rest.
void draw_symbol(canvas::Canvas2D& c, const ws::circsim::SymbolDef& sym,
                 Pos pos, int rot, bool mirror,
                 const canvas::Paint& body, std::uint32_t text_color,
                 const ws::ui::r2d::Font* font,
                 double switch_closed = 0.0);

// The data-color wheel every colored series in the app shares (i mod N,
// the scope's rule): the Results plot's signals and the canvas's per-NET
// wire coloring both ride it, so a net and its waveform can never look
// like strangers. Pure data - no canvas, no theme. Lives in the lib now
// (ws::circsim::series_color, geom.hpp); the using keeps the editor's
// historical spelling (`editor::series_color`) resolving.
using ws::circsim::series_color;

}  // namespace editor
