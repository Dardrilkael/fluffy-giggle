// apps/circsim_editor stage 4/5 - the Results panel's headless gate.
// The panel is app code, so its purity seam is the Editor's
// plot_canvas injection (a CommandListCanvas stands in for the r2d
// canvas): the cases below drive draw_results_panel the way the shell
// does - a GuiContext frame, a panel rect, a scripted mouse - and
// assert the recorded command stream: the plot frame, the grid, the
// series polylines (point counts, colors, and the data-to-screen
// mapping), the decimation of a long sweep, the hover crosshair
// markers, the .op table's value-row shape (no plot at all), and -
// stage 5 - the plot interaction: the wheel zoom, the rubber band
// (box, outline, commit), the axis-drag zooms, the pan, the
// double-click reset, the right-click cancel, and the per-table view
// reset.

#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include <doctest/doctest.h>

#include "../src/editor.hpp"
#include "../src/results_panel.hpp"

#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <limits>
#include <optional>
#include <vector>

#include <stb_image.h>  // declarations: stb_impl.cpp is a source of this target

#include <ws/settings/filesystem.hpp>
#include <ws/spice/results.hpp>
#include <ws/spice/run.hpp>
#include <ws/circsim/plot.hpp>
#include <ws/ui/canvas/canvas2d.hpp>
#include <ws/ui/gui/gui_context.hpp>
#include <ws/ui/gui/layout_cursor.hpp>
#include <ws/ui/gui/theme.hpp>
#include <ws/ui/renderer2d.hpp>

#include "ui_gui_stub.hpp"

namespace {

namespace gui = ws::ui::gui;
namespace canvas = ws::ui::canvas;
using editor::Editor;
using editor::PlotGesture;
using editor::PlotView;
using editor::ResultsCache;
using editor::SchematicDocument;

// getenv trips MSVC's C4996 deprecation under /W4 /WX; the Win32 call is
// the sanctioned spelling. Empty string = unset (getenv's null maps to
// "" here - both mean "not configured").
static std::string env_value(const char* name) {
#if defined(_WIN32)
    char buffer[MAX_PATH];
    const DWORD size = GetEnvironmentVariableA(name, buffer, MAX_PATH);
    if (size == 0 || size >= MAX_PATH) {
        return "";
    }
    return buffer;
#else
    const char* v = std::getenv(name);
    return v ? v : "";
#endif
}

// The series palette the panel draws with (results_panel.cpp's wheel).
[[nodiscard]] std::uint32_t series_color(std::size_t i) {
    constexpr std::uint32_t kSeries[] = {
        ws::ui::r2d::rgba(224, 90, 78),   ws::ui::r2d::rgba(78, 161, 224),
        ws::ui::r2d::rgba(88, 181, 92),   ws::ui::r2d::rgba(211, 154, 42),
        ws::ui::r2d::rgba(154, 111, 211), ws::ui::r2d::rgba(78, 201, 192),
        ws::ui::r2d::rgba(211, 90, 158),  ws::ui::r2d::rgba(143, 154, 78),
    };
    return kSeries[i % 8u];
}

[[nodiscard]] ws::spice::Table ramp_table(std::size_t rows) {
    ws::spice::Table t;
    t.analysis = ws::spice::AnalysisKind::Tran;
    t.sweep = ws::spice::SweepKind::Time;
    t.sweep_names = {"time"};
    t.sweep_axes.emplace_back();
    t.sweep_axes.back().reserve(rows);
    for (std::size_t i = 0; i < rows; ++i) {
        t.sweep_axes.back().push_back(
            1.0e-4 * static_cast<double>(i));  // 0 .. (rows-1)*100u
    }
    ws::spice::Signal out;
    out.name = "v(out)";
    out.data.reserve(rows);
    for (std::size_t i = 0; i < rows; ++i) {
        // 0 -> 5: a clean ramp, monotonically rising.
        out.data.push_back(5.0 * static_cast<double>(i) /
                           static_cast<double>(rows - 1u));
    }
    ws::spice::Signal cur;
    cur.name = "i(V1)";
    cur.data.reserve(rows);
    for (std::size_t i = 0; i < rows; ++i) {
        const double x = static_cast<double>(i) /
                         static_cast<double>(rows - 1u);
        cur.data.push_back(1.0e-3 * std::sin(2.0 * 3.14159265358979 * x));
    }
    t.signals.push_back(std::move(out));
    t.signals.push_back(std::move(cur));
    return t;
}

// The mixed table's voltage column alone: the stage-6 contrast bench
// for the right spine (no current column, no second axis).
[[nodiscard]] ws::spice::Table v_only_table(std::size_t rows) {
    ws::spice::Table t = ramp_table(rows);
    t.signals.erase(t.signals.begin() + 1);  // drop i(V1)
    return t;
}

[[nodiscard]] ws::spice::Table op_table() {
    ws::spice::Table t;
    t.analysis = ws::spice::AnalysisKind::Op;
    t.sweep = ws::spice::SweepKind::None;
    t.signals.push_back({"v(N001)", {5.0}});
    t.signals.push_back({"v(out)", {2.5}});
    t.signals.push_back({"i(V1)", {-2.5e-4}});
    return t;
}

// A .noise table: the log frequency axis plus the two spectra columns
// the .noise run delivers (V/sqrt(Hz) densities, both positive).
[[nodiscard]] ws::spice::Table noise_table(std::size_t rows) {
    ws::spice::Table t;
    t.analysis = ws::spice::AnalysisKind::Noise;
    t.sweep = ws::spice::SweepKind::Frequency;
    t.sweep_names = {"frequency"};
    t.sweep_axes.emplace_back();
    t.sweep_axes.back().reserve(rows);
    for (std::size_t i = 0; i < rows; ++i) {
        const double k = static_cast<double>(i) /
                         static_cast<double>(rows - 1u);
        t.sweep_axes.back().push_back(1.0 * std::pow(1e5, k));
    }
    ws::spice::Signal onoise;
    onoise.name = "onoise_spectrum";
    onoise.data.reserve(rows);
    ws::spice::Signal inoise;
    inoise.name = "inoise_spectrum";
    inoise.data.reserve(rows);
    for (std::size_t i = 0; i < rows; ++i) {
        // White spectra: flat densities, the input-referred pair twice
        // the output's (a 1/2 forward gain).
        onoise.data.push_back(2.9e-9);
        inoise.data.push_back(5.8e-9);
    }
    t.signals.push_back(std::move(onoise));
    t.signals.push_back(std::move(inoise));
    return t;
}

// The bench: an Editor over an untitled document, a CommandListCanvas
// injected at the plot seam, and one drawn frame per call.
struct Bench {
    // When set, the panel draws under this hit clip (the rect the dock's
    // scroll panel pushes into the gui and r2d): rows outside it are
    // invisible to the real app, and the panel may skip drawing them.
    std::optional<gui::Rect> hit_clip;
    ws::settings::StdFileSystem fs;
    SchematicDocument doc{std::string{}, fs};
    Editor ed;
    gui::GuiContext gui;
    canvas::CommandListCanvas clc;

    Bench() {
        ed.doc = &doc;
        ed.plot_canvas = &clc;
        ed.results.has = true;
        ed.results.version = doc.schem.version();
    }

    void load(ws::spice::Table table) {
        ed.results.run.results.tables.clear();
        ed.results.run.results.tables.push_back(std::move(table));
        ed.results.table = 0;
        // The app's run delivery, by the same call (main.cpp's block).
        ed.results.begin_delivery();
    }

    // The scripted mouse one draw sees. Defaults keep the stage-4
    // shape: a pointer parked off-panel, no buttons, no scroll, no
    // clock (dt 0 - the double-click detector only runs when a test
    // feeds it time).
    struct Mouse {
        float x = -1000.0f, y = -1000.0f;
        bool left_down = false;
        bool left_pressed = false;
        bool left_released = false;
        bool middle_down = false;
        bool right_pressed = false;
        float scroll_dy = 0.0f;
        float dt = 0.0f;
    };

    // Draws the panel once with the given mouse; clc.cmds holds
    // exactly this frame's commands on return.
    void draw(const Mouse& m) {
        clc.cmds.clear();
        ws::input::InputFrame in{};
        in.mouse_x = m.x;
        in.mouse_y = m.y;
        in.mouse_present = true;  // a scripted session has a mouse - the
                                  // wheel resolution gates on it
        in.mouse_down[0] = m.left_down;
        in.mouse_pressed[0] = m.left_pressed;
        in.mouse_released[0] = m.left_released;
        in.mouse_down[ws::input::mouse::kMiddle] = m.middle_down;
        in.mouse_pressed[ws::input::mouse::kRight] = m.right_pressed;
        in.scroll_dy = m.scroll_dy;
        in.dt_seconds = m.dt;
        gui.begin_frame(in);
        gui::LayoutCursor layout;
        (void)layout.begin_panel(gui::Rect{0.0f, 0.0f, 640.0f, 520.0f},
                                 12.0f, 8.0f);
        // What the dock's scroll panel pushes around a panel body.
        if (hit_clip.has_value()) {
            gui.push_hit_clip(*hit_clip);
        }
        const gui::ChromeTheme theme = gui::kDefaultChrome;
        editor::draw_results_panel(ed, gui, layout, theme);
        if (hit_clip.has_value()) {
            gui.pop_hit_clip();
        }
        layout.end_panel();
        gui.end_frame();
    }

    void draw(float mouse_x = -1000.0f, float mouse_y = -1000.0f) {
        Mouse m;
        m.x = mouse_x;
        m.y = mouse_y;
        draw(m);
    }

    // The plot frame: the first 4-point stroke (the legend swatches are
    // fills; the frame is the only 4-point CLOSED stroke).
    [[nodiscard]] const canvas::CanvasCmd* frame_cmd() const {
        for (const canvas::CanvasCmd& c : clc.cmds) {
            if (c.kind == canvas::CanvasCmdKind::stroke_polyline &&
                c.points.size() == 4u) {
                return &c;
            }
        }
        return nullptr;
    }

    // The series strokes: polylines carrying more than 4 points AND
    // the main data-series width (~2.0f, full opacity). Sparklines use
    // width 1.2f with alpha 200 so they are excluded by the width gate.
    [[nodiscard]] std::vector<const canvas::CanvasCmd*>
    series_cmds() const {
        std::vector<const canvas::CanvasCmd*> out;
        for (const canvas::CanvasCmd& c : clc.cmds) {
            if (c.kind == canvas::CanvasCmdKind::stroke_polyline &&
                c.points.size() > 4u &&
                c.width >= 1.5f) {
                out.push_back(&c);
            }
        }
        return out;
    }

    [[nodiscard]] std::size_t stroke_count() const {
        return clc.count(canvas::CanvasCmdKind::stroke_polyline);
    }

    // The frame's bounding box (fx, fy, fx2, fy2).
    struct FrameBox {
        float fx = 0.0f, fy = 0.0f, fx2 = 0.0f, fy2 = 0.0f;
    };
    [[nodiscard]] FrameBox frame_box(const canvas::CanvasCmd* frame) const {
        FrameBox b;
        REQUIRE(frame != nullptr);
        b.fx = b.fx2 = frame->points[0].x;
        b.fy = b.fy2 = frame->points[0].y;
        for (const canvas::Point& p : frame->points) {
            b.fx = std::min(b.fx, p.x);
            b.fy = std::min(b.fy, p.y);
            b.fx2 = std::max(b.fx2, p.x);
            b.fy2 = std::max(b.fy2, p.y);
        }
        return b;
    }
};

}  // namespace

TEST_CASE("a swept table draws frame, grid, and both series") {
    Bench b;
    b.load(ramp_table(41u));
    b.draw();

    // The frame: a closed 4-point polyline somewhere in the panel.
    const Bench::FrameBox f = b.frame_box(b.frame_cmd());
    CHECK(f.fx2 - f.fx > 400.0f);  // the plot spans the panel's width
    CHECK(f.fy2 - f.fy > 180.0f);  // ...and its fixed height minus margins

    // The grid: frame + x/y tick strokes, all 2-point lines.
    CHECK(b.stroke_count() >= 5u);

    // The series: two polylines, the palette's first two colors, one
    // point per sample (41 rows fit any pixel budget - no decimation).
    const std::vector<const canvas::CanvasCmd*> series = b.series_cmds();
    REQUIRE(series.size() == 2u);
    bool saw_red = false;
    bool saw_blue = false;
    for (const canvas::CanvasCmd* s : series) {
        CHECK(s->points.size() == 41u);
        saw_red = saw_red || s->color == series_color(0);
        saw_blue = saw_blue || s->color == series_color(1);
        // x is monotonically increasing (the sweep direction).
        for (std::size_t i = 1; i < s->points.size(); ++i) {
            CHECK(s->points[i].x > s->points[i - 1].x);
        }
    }
    CHECK(saw_red);
    CHECK(saw_blue);

    // The data-to-screen mapping: the ramp's FIRST sample sits at the
    // frame's bottom edge (y=0 of 0..5), the LAST at the top (y=5) -
    // remembering screen y grows DOWN.
    const canvas::CanvasCmd* ramp =
        series[0]->color == series_color(0) ? series[0] : series[1];
    CHECK(ramp->points.front().y > f.fy2 - 14.0f);  // near the bottom
    CHECK(ramp->points.back().y < f.fy + 14.0f);    // near the top

    // The legend swatches: two fills in the series colors left of the
    // plot frame (the legend rows sit above it).
    std::size_t swatches = 0;
    for (const canvas::CanvasCmd& c : b.clc.cmds) {
        if (c.kind != canvas::CanvasCmdKind::fill_polygon) {
            continue;
        }
        if (c.color == series_color(0) || c.color == series_color(1)) {
            float cx = 0.0f;
            for (const canvas::Point& p : c.points) {
                cx += p.x;
            }
            cx /= static_cast<float>(c.points.size());
            if (cx < f.fx) {
                ++swatches;
            }
        }
    }
    CHECK(swatches == 2u);
}

TEST_CASE("a .noise table plots both spectra like any swept table") {
    Bench b;
    b.load(noise_table(51u));  // 10 pts/decade over 1Hz..100kHz
    b.draw();

    // The plot itself: frame + grid + the two spectra strokes.
    const Bench::FrameBox f = b.frame_box(b.frame_cmd());
    CHECK(f.fx2 - f.fx > 400.0f);
    const std::vector<const canvas::CanvasCmd*> series = b.series_cmds();
    REQUIRE(series.size() == 2u);

    // The visibility flags minted for exactly the two spectra.
    REQUIRE(b.ed.results.visible.size() == 2u);
    CHECK(b.ed.results.visible[0] == 1u);
    CHECK(b.ed.results.visible[1] == 1u);

    // Hiding one spectrum (the legend checkbox) drops one stroke and
    // leaves the other: the noise pair toggles per signal like every
    // table the panel already drew.
    b.ed.results.visible[0] = 0u;
    b.draw();
    CHECK(b.series_cmds().size() == 1u);
}

TEST_CASE("a long sweep decimates to the pixel budget") {
    Bench b;
    b.load(ramp_table(1200u));
    b.draw();
    const std::vector<const canvas::CanvasCmd*> series = b.series_cmds();
    REQUIRE(series.size() == 2u);
    for (const canvas::CanvasCmd* s : series) {
        // The budget is the plot's inner width (~570): 1200 samples
        // fold to at most ~budget + 2 vertices...
        CHECK(s->points.size() <= 580u);
        CHECK(s->points.size() >= 8u);  // ...but never collapse
    }
    // The ramp's envelope still reaches both rails: first point low,
    // last point high (decimation keeps the global extremes).
    const canvas::CanvasCmd* ramp =
        series[0]->color == series_color(0) ? series[0] : series[1];
    const Bench::FrameBox f = b.frame_box(b.frame_cmd());
    CHECK(ramp->points.front().y > f.fy2 - 16.0f);
    CHECK(ramp->points.back().y < f.fy + 16.0f);
}

TEST_CASE("hovering the plot drops a crosshair and per-series markers") {
    Bench b;
    b.load(ramp_table(41u));
    b.draw();  // pass 1: locate the frame

    const Bench::FrameBox f = b.frame_box(b.frame_cmd());
    const float cx = (f.fx + f.fx2) * 0.5f;
    const float cy = (f.fy + f.fy2) * 0.5f;

    // Off the plot: no hover state.
    CHECK(b.ed.results.hover == -1);

    // Pass 2: the mouse at the frame's center.
    b.draw(cx, cy);
    REQUIRE(b.ed.results.hover >= 0);
    const std::size_t k = static_cast<std::size_t>(b.ed.results.hover);
    CHECK(k < 41u);

    // The crosshair: a vertical 2-point stroke at the hovered sample's
    // x (the series strokes are the only >4-point polylines).
    const std::vector<const canvas::CanvasCmd*> series = b.series_cmds();
    REQUIRE(series.size() == 2u);
    const float cross_x = series[0]->points[k].x;
    bool cross = false;
    for (const canvas::CanvasCmd& c : b.clc.cmds) {
        if (c.kind == canvas::CanvasCmdKind::stroke_polyline &&
            c.points.size() == 2u &&
            std::fabs(c.points[0].x - cross_x) < 1.5f &&
            std::fabs(c.points[1].x - cross_x) < 1.5f) {
            cross = true;
        }
    }
    CHECK(cross);

    // The markers: one small fill per visible series AT the series'
    // own (x, y) of sample k - in the series colors.
    for (const canvas::CanvasCmd* s : series) {
        const canvas::Point at = s->points[k];
        bool marked = false;
        for (const canvas::CanvasCmd& c : b.clc.cmds) {
            if (c.kind != canvas::CanvasCmdKind::fill_polygon ||
                c.color != s->color) {
                continue;
            }
            float mx = 0.0f;
            float my = 0.0f;
            for (const canvas::Point& p : c.points) {
                mx += p.x;
                my += p.y;
            }
            mx /= static_cast<float>(c.points.size());
            my /= static_cast<float>(c.points.size());
            if (std::fabs(mx - at.x) < 4.0f && std::fabs(my - at.y) < 4.0f) {
                marked = true;
            }
        }
        CHECK(marked);
    }
}

TEST_CASE("an .op table draws value rows and no plot") {
    Bench b;
    b.load(op_table());
    b.draw();

    // No plot for a sweep-less table: nothing through the canvas at
    // all (the value rows are gui text, drawn via the r2d seam).
    CHECK(b.stroke_count() == 0u);
    CHECK(b.clc.cmds.empty());
    CHECK(b.frame_cmd() == nullptr);
}

TEST_CASE("a missing run or empty tables never draws") {
    Bench b;
    b.draw();
    CHECK(b.clc.cmds.empty());  // results.has, but no tables

    b.load(ramp_table(4u));
    b.ed.results.run.results.tables.clear();
    b.draw();
    CHECK(b.clc.cmds.empty());
}

TEST_CASE("stale results note themselves but still draw") {
    Bench b;
    b.load(ramp_table(10u));
    b.ed.results.version = b.doc.schem.version() + 1u;  // edited since
    b.draw();
    CHECK(b.frame_cmd() != nullptr);  // the plot draws regardless
    CHECK(b.series_cmds().size() == 2u);
}

// --- stage 5/6: the plot's hands, on two spines ---------------------------------
//
// The bench's home windows for ramp_table(41) SPLIT per axis (stage
// 6 - the fixture is the mixed V/I table the split exists for): the
// ramp v(out) owns the LEFT spine, the sine i(V1) the RIGHT one. x =
// [-2e-4, 4.2e-3] (span 4.4e-3); the LEFT y spans the ramp alone -
// expand(0, 5) = [-0.25, 5.25] (span 5.5); the RIGHT y spans the
// sine alone - expand pads 5% of the SPAN, so expand(-1e-3, 1e-3) =
// [-1.1e-3, 1.1e-3] (span 2.2e-3). The numbers the band and zoom
// asserts below read against; the single-scale fit the stage-5
// constants answered (-0.25105.. 5.25005, the sine dip dragging the
// volts' span) is exactly what the split un-does.
constexpr double kHomeXLo = -2.0e-4;
constexpr double kHomeXHi = 4.2e-3;
constexpr double kHomeXSpan = kHomeXHi - kHomeXLo;
constexpr double kHomeYLo = -0.25;
constexpr double kHomeYHi = 5.25;
constexpr double kHomeYSpan = kHomeYHi - kHomeYLo;
constexpr double kHomeY1Lo = -1.1e-3;
constexpr double kHomeY1Hi = 1.1e-3;
constexpr double kHomeY1Span = kHomeY1Hi - kHomeY1Lo;

// The band's fill/outline (results_panel.cpp's with_alpha split of
// kDefaultChrome's accent).
constexpr std::uint32_t kBandFill = ws::ui::r2d::rgba(84, 144, 212, 36);
constexpr std::uint32_t kBandLine = ws::ui::r2d::rgba(84, 144, 212, 200);

TEST_CASE("the wheel zooms both axes toward the cursor") {
    Bench b;
    b.load(ramp_table(41u));
    b.draw();  // pass 0: a frame locates the plot geometry
    // Pass 1: the cursor ARRIVES over the plot - the claim registers
    // and its win settles for the next frame (the gui's one-frame
    // rule: the first notch after arriving still scrolls the panel).
    const Bench::FrameBox f0 = b.frame_box(b.frame_cmd());
    b.draw((f0.fx + f0.fx2) * 0.5f, (f0.fy + f0.fy2) * 0.5f);

    const Bench::FrameBox f = b.frame_box(b.frame_cmd());
    Bench::Mouse m;
    m.x = (f.fx + f.fx2) * 0.5f;
    m.y = (f.fy + f.fy2) * 0.5f;
    m.scroll_dy = 1.0f;  // one notch in
    b.draw(m);           // pass 2: the settled win consumes the notch

    const PlotView& v = b.ed.results.view;
    CHECK(v.active);
    // All three windows narrowed by the 1.15 notch, still centered -
    // each y spine toward its own mapped anchor (stage 6).
    CHECK((v.x_hi - v.x_lo) ==
          doctest::Approx(kHomeXSpan / 1.15).epsilon(1e-6));
    CHECK((v.y_hi - v.y_lo) ==
          doctest::Approx(kHomeYSpan / 1.15).epsilon(1e-6));
    CHECK((v.y1_hi - v.y1_lo) ==
          doctest::Approx(kHomeY1Span / 1.15).epsilon(1e-6));

    // A second notch: the x slice bites. The decimation window keeps
    // one sample of slack past each edge (the stroke needs the
    // neighbor to draw across the boundary), so one 1.15 notch still
    // carries every sample; two leave the ends out for real.
    b.draw(m);
    CHECK((v.x_hi - v.x_lo) ==
          doctest::Approx(kHomeXSpan / (1.15 * 1.15)).epsilon(1e-5));
    const std::vector<const canvas::CanvasCmd*> series = b.series_cmds();
    REQUIRE(series.size() == 2u);
    CHECK(series[0]->points.size() < 41u);

    // Two notches back out at the same spot return all three spans
    // (the math is invertible about the same anchor).
    m.scroll_dy = -1.0f;
    b.draw(m);
    b.draw(m);
    CHECK((v.x_hi - v.x_lo) ==
          doctest::Approx(kHomeXSpan).epsilon(1e-5));
    CHECK((v.y_hi - v.y_lo) ==
          doctest::Approx(kHomeYSpan).epsilon(1e-5));
    CHECK((v.y1_hi - v.y1_lo) ==
          doctest::Approx(kHomeY1Span).epsilon(1e-5));
}

TEST_CASE("a rubber band zooms to the box and draws itself") {
    Bench b;
    b.load(ramp_table(41u));
    b.draw();  // locate the frame

    const Bench::FrameBox f = b.frame_box(b.frame_cmd());
    const float iw = f.fx2 - f.fx;
    const float ih = f.fy2 - f.fy;
    Bench::Mouse m;
    m.x = f.fx + iw * 0.25f;
    m.y = f.fy + ih * 0.75f;
    m.left_pressed = true;
    m.left_down = true;
    b.draw(m);
    CHECK(b.ed.results.gesture.kind == PlotGesture::Kind::Band);
    CHECK_FALSE(b.ed.results.view.active);  // nothing commits mid-drag

    // The in-flight band paints: an accent wash, an accent outline.
    bool saw_fill = false;
    bool saw_line = false;
    for (const canvas::CanvasCmd& c : b.clc.cmds) {
        saw_fill = saw_fill || (c.kind == canvas::CanvasCmdKind::fill_polygon &&
                                c.color == kBandFill);
        saw_line = saw_line ||
                   (c.kind == canvas::CanvasCmdKind::stroke_polyline &&
                    c.points.size() == 4u && c.color == kBandLine);
    }
    CHECK(saw_fill);
    CHECK(saw_line);

    // Drag to the opposite corner and release: the view is the band.
    m.x = f.fx + iw * 0.75f;
    m.y = f.fy + ih * 0.25f;
    m.left_pressed = false;
    b.draw(m);
    m.left_down = false;
    m.left_released = true;
    b.draw(m);
    CHECK(b.ed.results.gesture.kind == PlotGesture::Kind::None);
    const PlotView& v = b.ed.results.view;
    CHECK(v.active);
    // The middle half of the home window, both axes (the band's box,
    // clamped into home - well inside here).
    CHECK(v.x_lo == doctest::Approx(kHomeXLo + 0.25 * kHomeXSpan)
                       .epsilon(1e-3));
    CHECK(v.x_hi == doctest::Approx(kHomeXLo + 0.75 * kHomeXSpan)
                       .epsilon(1e-3));
    CHECK(v.y_lo == doctest::Approx(kHomeYHi - 0.75 * kHomeYSpan)
                       .epsilon(1e-3));
    CHECK(v.y_hi == doctest::Approx(kHomeYHi - 0.25 * kHomeYSpan)
                       .epsilon(1e-3));
    // The band's y corners map through the RIGHT spine's own
    // transform too (stage 6): the same screen band, in amps - the
    // sine's window lands on the box's middle half of ITS span.
    CHECK(v.y1_lo ==
          doctest::Approx(kHomeY1Hi - 0.75 * kHomeY1Span).epsilon(1e-3));
    CHECK(v.y1_hi ==
          doctest::Approx(kHomeY1Hi - 0.25 * kHomeY1Span).epsilon(1e-3));
    // The series now covers only the band's samples (the x slice).
    const std::vector<const canvas::CanvasCmd*> series = b.series_cmds();
    REQUIRE(series.size() == 2u);
    CHECK(series[0]->points.size() < 41u);
}

TEST_CASE("dragging an axis strip stretches that axis only") {
    Bench b;
    b.load(ramp_table(41u));
    b.draw();

    const Bench::FrameBox f = b.frame_box(b.frame_cmd());

    // The x strip: inside the frame's width, below its bottom edge.
    Bench::Mouse m;
    m.x = (f.fx + f.fx2) * 0.5f;
    m.y = f.fy2 + 5.0f;
    m.left_pressed = true;
    m.left_down = true;
    b.draw(m);
    CHECK(b.ed.results.gesture.kind == PlotGesture::Kind::ZoomX);
    // The arm seeded the manual view with the effective (home) window
    // - the axis zoom lands its axis into that base as the drag moves
    // (both spines seed together, stage 6).
    CHECK(b.ed.results.view.active);
    CHECK(b.ed.results.view.y_lo ==
          doctest::Approx(kHomeYLo).epsilon(1e-6));
    CHECK(b.ed.results.view.y_hi ==
          doctest::Approx(kHomeYHi).epsilon(1e-6));
    CHECK(b.ed.results.view.y1_lo ==
          doctest::Approx(kHomeY1Lo).epsilon(1e-6));
    CHECK(b.ed.results.view.y1_hi ==
          doctest::Approx(kHomeY1Hi).epsilon(1e-6));

    // 100 px right: e^0.5 in. The x window narrows about the anchor;
    // the y window is untouched.
    m.x += 100.0f;
    m.left_pressed = false;
    b.draw(m);
    const PlotView& v = b.ed.results.view;
    CHECK(v.active);
    CHECK((v.x_hi - v.x_lo) ==
          doctest::Approx(kHomeXSpan * std::exp(-0.5)).epsilon(1e-3));
    CHECK(v.y_lo == doctest::Approx(kHomeYLo).epsilon(1e-6));
    CHECK(v.y_hi == doctest::Approx(kHomeYHi).epsilon(1e-6));

    // Release, then the y strip: inside the frame's height, left of
    // its left edge. 100 px up: e^0.5 in, y only.
    m.left_down = false;
    m.left_released = true;
    b.draw(m);
    CHECK(b.ed.results.gesture.kind == PlotGesture::Kind::None);

    Bench::Mouse my;
    my.x = f.fx - 5.0f;
    my.y = (f.fy + f.fy2) * 0.5f;
    my.left_pressed = true;
    my.left_down = true;
    b.draw(my);
    CHECK(b.ed.results.gesture.kind == PlotGesture::Kind::ZoomY);
    my.y -= 100.0f;
    my.left_pressed = false;
    b.draw(my);
    CHECK(b.ed.results.view.active);
    CHECK((b.ed.results.view.y_hi - b.ed.results.view.y_lo) ==
          doctest::Approx(kHomeYSpan * std::exp(-0.5)).epsilon(1e-3));
    // The x window kept its drag-1 answer.
    CHECK((b.ed.results.view.x_hi - b.ed.results.view.x_lo) ==
          doctest::Approx(kHomeXSpan * std::exp(-0.5)).epsilon(1e-3));
}

TEST_CASE("middle-drag pans and a double-click resets") {
    Bench b;
    b.load(ramp_table(41u));
    b.draw();

    const Bench::FrameBox f = b.frame_box(b.frame_cmd());
    const float iw = f.fx2 - f.fx;
    const float ih = f.fy2 - f.fy;
    const float cx = f.fx + iw * 0.5f;
    const float cy = f.fy + ih * 0.5f;

    // Establish a manual view (the band's middle half).
    Bench::Mouse m;
    m.x = f.fx + iw * 0.25f;
    m.y = f.fy + ih * 0.75f;
    m.left_pressed = true;
    m.left_down = true;
    b.draw(m);
    m.x = f.fx + iw * 0.75f;
    m.y = f.fy + ih * 0.25f;
    m.left_pressed = false;
    b.draw(m);
    m.left_down = false;
    m.left_released = true;
    b.draw(m);
    const double band_lo = b.ed.results.view.x_lo;
    const double band_span = b.ed.results.view.x_hi - band_lo;
    REQUIRE(b.ed.results.view.active);

    // Age the double-click clock (the pointer stays OVER the plot -
    // the clock dies when it leaves), then pan right 100 px: the
    // window slides LEFT by the data-space shift (content follows
    // the cursor).
    Bench::Mouse gap;
    gap.x = cx;
    gap.y = cy;
    gap.dt = 0.5f;
    b.draw(gap);
    b.draw(gap);
    Bench::Mouse pan;
    pan.x = cx;
    pan.y = cy;
    pan.middle_down = true;
    pan.dt = 0.016f;
    b.draw(pan);
    CHECK(b.ed.results.gesture.kind == PlotGesture::Kind::Pan);
    pan.x = cx + 100.0f;
    b.draw(pan);
    const double shift = -(100.0 / static_cast<double>(iw)) * band_span;
    CHECK(b.ed.results.view.active);
    CHECK(b.ed.results.view.x_lo ==
          doctest::Approx(band_lo + shift).epsilon(1e-3));

    // The middle releases: the pan ends, the view stays where it
    // landed.
    pan.middle_down = false;
    b.draw(pan);
    CHECK(b.ed.results.gesture.kind == PlotGesture::Kind::None);
    CHECK(b.ed.results.view.active);

    // The double click: two presses, same spot, inside the clock.
    // Press 1 arms a band (the clock is aged past 0.35 by the gaps).
    Bench::Mouse click;
    click.x = cx;
    click.y = cy;
    click.left_pressed = true;
    click.left_down = true;
    click.dt = 0.1f;
    b.draw(click);
    CHECK(b.ed.results.gesture.kind == PlotGesture::Kind::Band);
    click.left_pressed = false;  // the release carries no press edge
    click.left_down = false;
    b.draw(click);               // the tiny band's release
    click.left_pressed = true;
    click.left_down = true;
    b.draw(click);               // press 2, ~0.2 s later, same spot
    CHECK(b.ed.results.gesture.kind == PlotGesture::Kind::None);
    CHECK_FALSE(b.ed.results.view.active);
    // The auto fit is back: every sample draws again.
    const std::vector<const canvas::CanvasCmd*> series = b.series_cmds();
    REQUIRE(series.size() == 2u);
    CHECK(series[0]->points.size() == 41u);
}

TEST_CASE("a right-click cancels the drag and restores the press view") {
    Bench b;
    b.load(ramp_table(41u));
    b.draw();  // pass 0: a frame locates the plot geometry
    {   // The cursor arrives over the plot: the claim registers, the
        // win settles for the next frame.
        const Bench::FrameBox f0 = b.frame_box(b.frame_cmd());
        b.draw((f0.fx + f0.fx2) * 0.5f, (f0.fy + f0.fy2) * 0.5f);
    }

    // A manual view to endanger: one wheel notch.
    const Bench::FrameBox f = b.frame_box(b.frame_cmd());
    Bench::Mouse wheel;
    wheel.x = (f.fx + f.fx2) * 0.5f;
    wheel.y = (f.fy + f.fy2) * 0.5f;
    wheel.scroll_dy = 1.0f;
    b.draw(wheel);
    REQUIRE(b.ed.results.view.active);
    const PlotView before = b.ed.results.view;

    // A band drag goes astray; a right-click kills it and restores
    // the press-time window exactly.
    Bench::Mouse m;
    m.x = f.fx + 30.0f;
    m.y = f.fy + 30.0f;
    m.left_pressed = true;
    m.left_down = true;
    b.draw(m);
    REQUIRE(b.ed.results.gesture.kind == PlotGesture::Kind::Band);
    m.x += 200.0f;
    m.y += 100.0f;
    m.left_pressed = false;
    b.draw(m);
    m.right_pressed = true;
    b.draw(m);
    CHECK(b.ed.results.gesture.kind == PlotGesture::Kind::None);
    CHECK(b.ed.results.view.active);
    CHECK(b.ed.results.view.x_lo == before.x_lo);
    CHECK(b.ed.results.view.x_hi == before.x_hi);
    CHECK(b.ed.results.view.y_lo == before.y_lo);
    CHECK(b.ed.results.view.y_hi == before.y_hi);
    CHECK(b.ed.results.view.y1_lo == before.y1_lo);
    CHECK(b.ed.results.view.y1_hi == before.y1_hi);
}

TEST_CASE("a table switch drops the manual view") {
    Bench b;
    b.load(ramp_table(41u));
    b.ed.results.run.results.tables.push_back(ramp_table(10u));
    b.draw();

    // A manual view on table 0.
    const Bench::FrameBox f = b.frame_box(b.frame_cmd());
    const float iw = f.fx2 - f.fx;
    const float ih = f.fy2 - f.fy;
    Bench::Mouse m;
    m.x = f.fx + iw * 0.25f;
    m.y = f.fy + ih * 0.75f;
    m.left_pressed = true;
    m.left_down = true;
    b.draw(m);
    m.x = f.fx + iw * 0.75f;
    m.y = f.fy + ih * 0.25f;
    m.left_pressed = false;
    b.draw(m);
    m.left_down = false;
    m.left_released = true;
    b.draw(m);
    REQUIRE(b.ed.results.view.active);

    // The combo moves to table 1: the view drops (it belonged to
    // table 0), and moving back does not resurrect it.
    b.ed.results.table = 1;
    b.draw();
    CHECK_FALSE(b.ed.results.view.active);
    b.ed.results.table = 0;
    b.draw();
    CHECK_FALSE(b.ed.results.view.active);
}

TEST_CASE("a round trip through a table without a plot drops the manual view") {
    // The view belongs to the table it was made on. A table with no plot
    // (.op: value rows) never reaches draw_plot, so a reset that lives
    // there never saw the switch - the zoom came back after tran -> op
    // -> tran, while the visible set (reset for every table) did not.
    Bench b;
    b.load(ramp_table(41u));
    b.ed.results.run.results.tables.push_back(op_table());  // table 1
    b.draw();
    b.ed.results.view = PlotView{true,        0.001,      0.003,
                                 kHomeYLo,    kHomeYHi,   kHomeY1Lo,
                                 kHomeY1Hi};
    b.draw();
    REQUIRE(b.ed.results.view.active);  // a manual view on table 0

    b.ed.results.table = 1;  // the .op table: no plot is drawn
    b.draw();
    b.ed.results.table = 0;  // and back
    b.draw();
    CHECK_FALSE(b.ed.results.view.active);
}

TEST_CASE("begin_delivery resets every piece of per-delivery state") {
    // One call is the whole delivery reset (the app and the benches used
    // to copy the list by hand). Dirty each field it owns, then deliver.
    ResultsCache c;
    c.table = 1;
    c.visible_for = 1;
    c.visible.assign(3u, 0u);
    c.x_sorted_for = 1;
    c.x_runs_for = 1;
    c.hover = 7;
    c.view = PlotView{true, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0};
    c.view_for = 1;
    c.gesture.kind = PlotGesture::Kind::Pan;
    c.markers = {2, 5};
    c.markers_for = 1;
    const std::uint64_t run = c.run_id;

    c.begin_delivery();

    CHECK(c.run_id == run + 1u);
    CHECK(c.visible_for == ResultsCache::kNoTable);
    CHECK(c.visible.empty());
    CHECK(c.x_sorted_for == ResultsCache::kNoTable);
    CHECK(c.x_runs_for == ResultsCache::kNoTable);
    CHECK(c.hover == -1);
    CHECK_FALSE(c.view.active);
    CHECK(c.view_for == ResultsCache::kNoTable);
    CHECK(c.gesture.kind == PlotGesture::Kind::None);
    CHECK(c.markers.empty());  // the one the hand-copied lists forgot
    CHECK(c.markers_for == ResultsCache::kNoTable);
}

TEST_CASE("markers belong to their table: a switch drops them, a frame keeps them") {
    Bench b;
    b.load(ramp_table(41u));
    b.ed.results.run.results.tables.push_back(op_table());  // table 1
    b.draw();
    b.ed.results.markers = {3, 17};  // planted on table 0

    b.draw();  // nothing moved: they stay
    CHECK(b.ed.results.markers == std::vector<int>{3, 17});

    b.ed.results.table = 1;  // a table with no plot: still a switch
    b.draw();
    CHECK(b.ed.results.markers.empty());
    CHECK(b.ed.results.markers_for == 1u);

    b.ed.results.table = 0;  // and back: not resurrected
    b.draw();
    CHECK(b.ed.results.markers.empty());
}

TEST_CASE("a delivery drops the markers even on the same table index") {
    // A same-indexed table of a new run is a different table: the
    // markers' key (the table index) cannot see that, the delivery does.
    Bench b;
    b.load(ramp_table(41u));
    b.draw();
    b.ed.results.markers = {5, 9};
    b.load(ramp_table(41u));  // the next run, table 0 again
    b.draw();
    CHECK(b.ed.results.markers.empty());
}

// --- stage 6: the second spine ---------------------------------------------------

TEST_CASE("mixed V/I split the axes: the sine reads on the right spine") {
    Bench b;
    b.load(ramp_table(41u));
    b.draw();

    const Bench::FrameBox both = b.frame_box(b.frame_cmd());
    const float ih = both.fy2 - both.fy;

    // The sine rides the RIGHT window alone: its peak (+1e-3 at
    // sample 10 - the sine tops a quarter-period in) maps near the
    // frame's TOP; the trough (sample 30) mirrors it. Under the
    // single-scale fit the stage-5 plot drew, 1e-3 against a 5.5-volt
    // span sat squashed against the axis zero - the split is what
    // gives the sine its own rails.
    const std::vector<const canvas::CanvasCmd*> series = b.series_cmds();
    REQUIRE(series.size() == 2u);
    const canvas::CanvasCmd* sine =
        series[0]->color == series_color(1) ? series[0] : series[1];
    const canvas::CanvasCmd* ramp =
        series[0] == sine ? series[1] : series[0];
    CHECK(sine->points[10].y < both.fy + ih * 0.25f);
    CHECK(sine->points[30].y > both.fy + ih * 0.75f);
    // The ramp rides the LEFT window: its own mid (2.5 V at sample
    // 20) maps to mid-height, the split's whole point - neither
    // spine flattens the other.
    CHECK(ramp->points[20].y > both.fy + ih * 0.45f);
    CHECK(ramp->points[20].y < both.fy + ih * 0.55f);

    // The right spine's ticks: 2-point strokes leaving the frame's
    // right edge rightward - the y-grid lines leave from the LEFT
    // edge, so the direction tells them apart.
    bool saw_right_tick = false;
    for (const canvas::CanvasCmd& c : b.clc.cmds) {
        if (c.kind == canvas::CanvasCmdKind::stroke_polyline &&
            c.points.size() == 2u &&
            std::fabs(c.points[0].x - both.fx2) < 0.5f &&
            c.points[1].x > both.fx2 + 1.0f) {
            saw_right_tick = true;
        }
    }
    CHECK(saw_right_tick);

    // A v-only table keeps the stage-5 shape: no right ticks, and the
    // frame reclaims the amp axis's label strip.
    Bench solo;
    solo.load(v_only_table(41u));
    solo.draw();
    const Bench::FrameBox f = solo.frame_box(solo.frame_cmd());
    bool solo_right_tick = false;
    for (const canvas::CanvasCmd& c : solo.clc.cmds) {
        if (c.kind == canvas::CanvasCmdKind::stroke_polyline &&
            c.points.size() == 2u &&
            std::fabs(c.points[0].x - f.fx2) < 0.5f &&
            c.points[1].x > f.fx2 + 1.0f) {
            solo_right_tick = true;
        }
    }
    CHECK_FALSE(solo_right_tick);
    CHECK(f.fx2 > both.fx2 + 20.0f);  // 46 - 10: the label strip's width
}

TEST_CASE("the right strip drags the amp window alone") {
    Bench b;
    b.load(ramp_table(41u));
    b.draw();

    const Bench::FrameBox f = b.frame_box(b.frame_cmd());
    // Press the RIGHT strip: right of the frame's right edge, inside
    // its height - the right spine's drag handle (the widened margin
    // the second axis earns).
    Bench::Mouse m;
    m.x = f.fx2 + 5.0f;
    m.y = (f.fy + f.fy2) * 0.5f;
    m.left_pressed = true;
    m.left_down = true;
    b.draw(m);
    CHECK(b.ed.results.gesture.kind == PlotGesture::Kind::ZoomY);
    CHECK(b.ed.results.gesture.zoom_axis == 1);
    CHECK(b.ed.results.view.active);

    // 100 px up: e^0.5 in - on the amp window ONLY. The volt window
    // and the sweep keep their homes.
    m.y -= 100.0f;
    m.left_pressed = false;
    b.draw(m);
    CHECK((b.ed.results.view.y1_hi - b.ed.results.view.y1_lo) ==
          doctest::Approx(kHomeY1Span * std::exp(-0.5)).epsilon(1e-3));
    CHECK((b.ed.results.view.y_hi - b.ed.results.view.y_lo) ==
          doctest::Approx(kHomeYSpan).epsilon(1e-6));
    CHECK((b.ed.results.view.x_hi - b.ed.results.view.x_lo) ==
          doctest::Approx(kHomeXSpan).epsilon(1e-6));

    // The sine re-scales with its window: the drag zoomed IN about
    // the strip's mid (0 A), so the amp span closed to +-0.64 mA and
    // the peak (1 mA) now maps ABOVE the frame - the waveform leaving
    // the frame is what a y zoom-in on its own spine looks like. The
    // ramp's geometry is untouched (its own spine never moved).
    const std::vector<const canvas::CanvasCmd*> series = b.series_cmds();
    REQUIRE(series.size() == 2u);
    const canvas::CanvasCmd* sine =
        series[0]->color == series_color(1) ? series[0] : series[1];
    CHECK(sine->points[10].y < f.fy);   // the peak: past the top edge
    CHECK(sine->points[30].y > f.fy2);  // the trough: past the bottom
}

TEST_CASE("a v-only table has no right strip and the press falls nowhere") {
    Bench b;
    b.load(v_only_table(41u));
    b.draw();

    const Bench::FrameBox f = b.frame_box(b.frame_cmd());
    // Where a right strip WOULD be, if the table had currents: no
    // spine, no handle - the press is outside every claimable region
    // and arms nothing.
    Bench::Mouse m;
    m.x = f.fx2 + 5.0f;
    m.y = (f.fy + f.fy2) * 0.5f;
    m.left_pressed = true;
    m.left_down = true;
    b.draw(m);
    CHECK(b.ed.results.gesture.kind == PlotGesture::Kind::None);
    CHECK_FALSE(b.ed.results.view.active);
}

// --- the x-sortedness cache (the per-table constant) ---------------------------

TEST_CASE("the x-sortedness caches per table and follows table switches") {
    Bench b;

    // A wrap-shaped table: the axis rises then FALLS back (the .dc
    // double-sweep shape), so it is NOT strictly increasing.
    ws::spice::Table wrap = ramp_table(41u);
    for (std::size_t i = 0; i < wrap.sweep_axes[0].size(); ++i) {
        wrap.sweep_axes[0][i] =
            1.0e-4 * static_cast<double>(i < 21u ? i : 40u - i);
    }
    b.load(std::move(wrap));
    b.draw();
    CHECK(b.ed.results.x_sorted == false);
    CHECK(b.ed.results.x_sorted_for == 0u);

    // The sorted ramp, delivered as a SECOND table: switching to it
    // re-derives (the cache key moved), and switching back re-derives
    // again - a stale key would have carried the old answer across.
    b.ed.results.run.results.tables.push_back(ramp_table(41u));
    b.ed.results.table = 1u;
    b.draw();
    CHECK(b.ed.results.x_sorted == true);
    CHECK(b.ed.results.x_sorted_for == 1u);

    b.ed.results.table = 0u;
    b.draw();
    CHECK(b.ed.results.x_sorted == false);
    CHECK(b.ed.results.x_sorted_for == 0u);

    // A fresh delivery of the same-indexed table re-derives too (the
    // load resets the key): a new run's axis 0 is not the old run's.
    b.load(ramp_table(41u));
    b.draw();
    CHECK(b.ed.results.x_sorted == true);
    CHECK(b.ed.results.x_sorted_for == 0u);
}

// --- the transient wears the plot (patch 0012) --------------------------------
//
// The playhead the canvas animates is the plot's cursor too, and the
// transport row under the plot scrubs the SAME playback: one field, so
// the two surfaces can never disagree. The gate drives the row the way
// a hand would - a press in the track, the drag, the release - and
// asserts the shared state moved (and parked) exactly.
TEST_CASE("the playhead line sweeps the plot at the shared cursor") {
    Bench b;
    b.load(ramp_table(51u));  // 0 .. 5 ms, a clean ramp
    const std::span<const double> xs =
        b.ed.results.run.results.tables[0].axis(0);
    REQUIRE(xs.size() == 51u);
    const double t0 = xs.front();
    const double t1 = xs.back();

    // Park the playhead mid-sweep: the plot draws a vertical line at
    // the playhead's x - the same mapping the series ride, the padded
    // auto fit the panel itself asks ws::circsim for.
    b.ed.playback.t = 2.5e-3;
    b.draw();
    const canvas::CanvasCmd* frame = b.frame_cmd();
    const Bench::FrameBox fb = b.frame_box(frame);
    const float iw = fb.fx2 - fb.fx;
    const float ih = fb.fy2 - fb.fy;
    const ws::circsim::PlotRange xr =
        ws::circsim::expand_range(t0, t1);
    const float want_x =
        fb.fx + static_cast<float>((b.ed.playback.t - xr.lo) /
                                   (xr.hi - xr.lo)) * iw;
    const canvas::CanvasCmd* sweep = nullptr;
    for (const canvas::CanvasCmd& c : b.clc.cmds) {
        if (c.kind == canvas::CanvasCmdKind::stroke_polyline &&
            c.points.size() == 2u && c.width == 1.5f &&
            c.color == gui::kDefaultChrome.control_on) {
            sweep = &c;
            break;
        }
    }
    REQUIRE(sweep != nullptr);
    CHECK(sweep->points[0].x == doctest::Approx(want_x).epsilon(0.01));
    CHECK(sweep->points[1].x == doctest::Approx(want_x).epsilon(0.01));
    CHECK(sweep->points[0].y == doctest::Approx(fb.fy).epsilon(0.01));
    CHECK(sweep->points[1].y == doctest::Approx(fb.fy + ih).epsilon(0.01));

    // An .op table wears no playhead (nothing to sweep): the line is a
    // transient's own.
    b.load(op_table());
    b.draw();
    for (const canvas::CanvasCmd& c : b.clc.cmds) {
        if (c.kind == canvas::CanvasCmdKind::stroke_polyline &&
            c.points.size() == 2u && c.width == 1.5f &&
            c.color == gui::kDefaultChrome.control_on) {
            FAIL("the .op shape drew a playhead line");
        }
    }
}

TEST_CASE("the transport row scrubs the one shared playback") {
    Bench b;
    b.load(ramp_table(51u));
    const std::span<const double> xs =
        b.ed.results.run.results.tables[0].axis(0);
    const double t0 = xs.front();
    const double t1 = xs.back();
    const double span = t1 - t0;
    b.draw();

    // The row drew: a rail (a 2px fill_rects at least 60 px wide) with
    // the knob circle on it - the row's own geometry, found in the
    // command stream the way the canvas suite finds its chrome.
    const canvas::CanvasCmd* rail = nullptr;
    for (const canvas::CanvasCmd& c : b.clc.cmds) {
        if (c.kind == canvas::CanvasCmdKind::fill_rects &&
            c.points.size() == 1u && c.w >= 60.0f && c.h <= 2.5f) {
            rail = &c;
            break;
        }
    }
    REQUIRE(rail != nullptr);
    const float tx = rail->points[0].x;
    const float ty = rail->points[0].y;
    const float tw = rail->w;

    // A press a quarter into the track arms the drag and lands the
    // playhead there - the canvas's own strip rule, on the plot's row.
    Bench::Mouse m;
    m.x = tx + tw * 0.25f;
    m.y = ty + 10.0f;
    m.left_pressed = true;
    m.left_down = true;
    b.draw(m);
    CHECK(b.ed.results_scrub);
    CHECK(b.ed.playback.t == doctest::Approx(t0 + span * 0.25)
                               .epsilon(0.02));

    // The drag owns the pointer: a move to the far end sweeps it, and
    // the same playback field is what the canvas animates.
    m.left_pressed = false;
    m.x = tx + tw * 0.95f;
    b.draw(m);
    CHECK(b.ed.results_scrub);
    CHECK(b.ed.playback.t >= t0 + span * 0.90);  // 0.95 in, slack out

    // Release parks it; a later press in the plot's own frame (the
    // band zoom's turf) never re-arms the row.
    m.left_down = false;
    m.left_released = true;
    b.draw(m);
    CHECK_FALSE(b.ed.results_scrub);
    CHECK(b.ed.playback.t >= t0 + span * 0.90);
}

// --- the .four table (§7.9): the results panel's third section -------------------

namespace {

// A .tran two-tone series: fundamental 0.5 V, 3rd harmonic 0.1 V - the
// closed form the engine's .four tests pin (THD exactly 20 %).
[[nodiscard]] ws::spice::Fourier two_tone_fourier() {
    ws::spice::Fourier f;
    f.signal = "v(out)";
    f.analysis = ".tran";
    f.fundamental = 1000.0;
    f.periods = 1;
    f.dc = 0.0;
    f.thd_percent = 20.0;
    f.harmonics.push_back({1, 1000.0, 0.5, -90.0, 100.0});
    f.harmonics.push_back({2, 2000.0, 0.0, 0.0, 0.0});
    f.harmonics.push_back({3, 3000.0, 0.1, -90.0, 20.0});
    return f;
}

// The synthetic mono face the section's rows install (the side-panels
// suite's own glyph-table pattern: the fill ctor copies the table, so
// the array fills before the Font member constructs).
using GlyphTable = std::array<ws::ui::r2d::Font::Glyph, 95>;

[[nodiscard]] GlyphTable glyph_table(float advance) {
    GlyphTable glyphs{};
    for (ws::ui::r2d::Font::Glyph& g : glyphs) {
        g.advance = advance;
    }
    return glyphs;
}

}  // namespace

TEST_CASE("a .tran run's fourier section renders the harmonic rows") {
    Bench b;
    b.load(ramp_table(16u));
    b.ed.results.run.fouriers.push_back(two_tone_fourier());

    const GlyphTable mono_glyphs = glyph_table(8.0f);
    ws::ui::r2d::Font mono(15.0f, 19.0f, mono_glyphs.data(), 95);
    b.ed.font_mono = &mono;

    ws::ui::gui_test::stub.reset();
    b.draw();
    // The section's own rows through the mono face - header, dc, the
    // column header, three harmonics, the THD footer - and nothing else
    // in this bench draws text through the seam (the plot and the
    // legend ride the canvas and the fontless gui chrome).
    CHECK(ws::ui::gui_test::stub.texts == 7u);
    CHECK(ws::ui::gui_test::stub.last_text_font == &mono);

    // The section renders under the measurements when both exist: the
    // same seven rows plus however many the measurements draw.
    b.ed.results.run.measurements.push_back(
        ws::spice::Measurement{"m1", ".tran", 1.0, ""});
    ws::ui::gui_test::stub.reset();
    b.draw();
    CHECK(ws::ui::gui_test::stub.texts == 8u);
    b.ed.font_mono = nullptr;
}

TEST_CASE("the fourier section gates on the shown table's analysis") {
    Bench b;
    const GlyphTable mono_glyphs = glyph_table(8.0f);
    ws::ui::r2d::Font mono(15.0f, 19.0f, mono_glyphs.data(), 95);
    b.ed.font_mono = &mono;

    // A .noise table: the .tran series never shows, whatever the run
    // carries - the section's rows are the delta between the two draws.
    b.load(noise_table(51u));
    ws::ui::gui_test::stub.reset();
    b.draw();
    const std::uint32_t without = ws::ui::gui_test::stub.texts;
    b.ed.results.run.fouriers.push_back(two_tone_fourier());
    ws::ui::gui_test::stub.reset();
    b.draw();
    CHECK(ws::ui::gui_test::stub.texts == without);  // hidden under .noise

    // The same series under the run's .tran table draws its rows.
    b.load(ramp_table(16u));
    ws::ui::gui_test::stub.reset();
    b.draw();
    CHECK(ws::ui::gui_test::stub.texts == without + 7u);
    b.ed.font_mono = nullptr;
}

TEST_CASE("a failed fourier series reads like a failed measurement") {
    Bench b;
    b.load(ramp_table(16u));
    ws::spice::Fourier f;
    f.signal = "v(nope)";
    f.analysis = ".tran";
    f.note = "unknown signal 'v(nope)'";
    b.ed.results.run.fouriers.push_back(std::move(f));

    const GlyphTable mono_glyphs = glyph_table(8.0f);
    ws::ui::r2d::Font mono(15.0f, 19.0f, mono_glyphs.data(), 95);
    b.ed.font_mono = &mono;

    ws::ui::gui_test::stub.reset();
    b.draw();
    CHECK(ws::ui::gui_test::stub.texts == 1u);
    // The failure wears the measurement's own warning ink.
    CHECK(ws::ui::gui_test::stub.last_text_color ==
          gui::dim(gui::kDefaultChrome.toast_warning, 0.95f));
    b.ed.font_mono = nullptr;
}

TEST_CASE("an .op fourier answers the dc line alone") {
    Bench b;
    b.load(op_table());
    ws::spice::Fourier f;
    f.signal = "v(out)";
    f.analysis = ".op";
    f.fundamental = 1000.0;
    f.dc = 2.5;
    b.ed.results.run.fouriers.push_back(std::move(f));

    const GlyphTable mono_glyphs = glyph_table(8.0f);
    ws::ui::r2d::Font mono(15.0f, 19.0f, mono_glyphs.data(), 95);
    b.ed.font_mono = &mono;

    ws::ui::gui_test::stub.reset();
    b.draw();
    // The .op value rows draw through the mono face too (2 texts per
    // signal x 3 signals), then the fourier section's single dc line.
    CHECK(ws::ui::gui_test::stub.texts == 7u);
    CHECK(ws::ui::gui_test::stub.last_text_font == &mono);
    b.ed.font_mono = nullptr;
}

// --- the frame-budget caches (stage 8) and the family (stage 9) ---------------
//
// The big-circuit fix's gate: the per-frame work over the run's data
// is cached against what it depends on - per-signal constants once per
// (run, table), the series decimations once per (x window, pixel
// budget). The cases below pin the keys (a delivery re-keys, an idle
// frame hits), the bounded vertex counts on EVERY path (the sorted
// sweep, the step family's overlaid passes, the by-index axis), and
// the picture staying byte-identical on the frames nothing changes.

TEST_CASE("an idle frame reuses the cached decimation verbatim") {
    Bench b;
    b.load(ramp_table(1200u));
    b.draw();  // frame 1: builds the stats and the keep lists

    // The caches minted for THIS table of THIS run.
    REQUIRE(b.ed.results.stats.size() == 2u);
    CHECK(b.ed.results.stats_for == 0u);
    CHECK(b.ed.results.stats_run == b.ed.results.run_id);
    CHECK(b.ed.results.stats[0].finite);
    CHECK(b.ed.results.stats[0].spark_env.size() == 80u);  // 40 buckets
    CHECK_FALSE(b.ed.results.stats[0].right);              // v(out)
    CHECK(b.ed.results.stats[1].right);                    // i(V1)
    // A sorted axis: one run a side, its keep list built.
    REQUIRE(b.ed.results.decim.size() == 2u);
    CHECK(b.ed.results.decim[0].built);
    REQUIRE(b.ed.results.decim[0].runs.size() == 1u);
    CHECK(b.ed.results.decim[0].runs[0].i0 == 0u);
    CHECK(b.ed.results.decim[0].runs[0].i1 == 1200u);
    CHECK_FALSE(b.ed.results.decim[0].runs[0].idx.empty());

    // Frame 2, nothing changed: the same series geometry, point for
    // point (the keep lists ride the cache; the mapping is
    // deterministic), and the cache keys did not move.
    std::vector<std::vector<canvas::Point>> before;
    for (const canvas::CanvasCmd* s : b.series_cmds()) {
        before.push_back(s->points);
    }
    b.draw();
    const std::vector<const canvas::CanvasCmd*> after = b.series_cmds();
    REQUIRE(after.size() == before.size());
    for (std::size_t i = 0; i < after.size(); ++i) {
        REQUIRE(after[i]->points.size() == before[i].size());
        for (std::size_t j = 0; j < before[i].size(); ++j) {
            CHECK(after[i]->points[j] == before[i][j]);
        }
    }
    CHECK(b.ed.results.decim_run == b.ed.results.run_id);

    // A delivery re-keys: the stats rebuild against the new run_id and
    // the keeps unbuilt (a same-shaped table is a different table).
    const std::uint64_t was_run = b.ed.results.run_id;
    b.load(ramp_table(1200u));
    CHECK(b.ed.results.run_id != was_run);
    const bool stats_rekeyed = b.ed.results.stats_for == ResultsCache::kNoTable ||
                               b.ed.results.stats_run != b.ed.results.run_id;
    CHECK(stats_rekeyed);
    b.draw();
    CHECK(b.ed.results.stats_run == b.ed.results.run_id);
    CHECK(b.ed.results.decim_run == b.ed.results.run_id);
}

TEST_CASE("a step-family table overlays its passes, no chords") {
    // The .step/.dc wrap shape (the axis rises then walks back - not
    // strictly increasing) at a size the pixel budget cannot fit: the
    // stage-7 code pushed every sample as ONE polyline, chording the
    // reset into the lines-between-vertices mess; stage 9 splits the
    // axis into its monotone passes and OVERLAYS them - one stroke per
    // pass per signal, every stroke inside the frame and spanning the
    // shared window, vertices bounded per pass.
    Bench b;
    ws::spice::Table wrap = ramp_table(4000u);
    for (std::size_t i = 0; i < wrap.sweep_axes[0].size(); ++i) {
        wrap.sweep_axes[0][i] =
            1.0e-4 * static_cast<double>(i < 2000u ? i : 3999u - i);
    }
    b.load(std::move(wrap));
    b.draw();
    CHECK(b.ed.results.x_sorted == false);

    // The axis split: one rising pass, one falling (the .dc wrap's
    // walk back down), covering the table between them.
    REQUIRE(b.ed.results.x_runs.runs.size() == 2u);
    CHECK(b.ed.results.x_runs.runs[0].rising);
    CHECK(b.ed.results.x_runs.runs[0].begin == 0u);
    CHECK(b.ed.results.x_runs.runs[0].end == 2000u);
    CHECK_FALSE(b.ed.results.x_runs.runs[1].rising);
    CHECK(b.ed.results.x_runs.runs[1].begin == 2000u);
    CHECK(b.ed.results.x_runs.runs[1].end == 4000u);

    // One keep list per pass, each built and folded to its SLICE of
    // the shared budget (stage 10: the passes overlay one window, so
    // the pixel budget is split, not multiplied - 2000 rows a pass
    // against a ~524-pixel window).
    REQUIRE(b.ed.results.decim.size() == 2u);
    CHECK(b.ed.results.decim[0].built);
    REQUIRE(b.ed.results.decim[0].runs.size() == 2u);
    const std::size_t budget = b.ed.results.decim_budget;
    std::size_t total_keeps = 0;
    for (const editor::ResultsCache::RunKeep& rk :
         b.ed.results.decim[0].runs) {
        CHECK(rk.i1 > rk.i0);
        // The per-pass fold: its slice of the budget (the floor
        // keeps a many-pass family legible).
        CHECK(rk.idx.size() <=
              std::max<std::size_t>(64u, budget / 2u) + 4u);
        CHECK(rk.idx.size() >= 8u);
        total_keeps += rk.idx.size();
    }
    // The SHARED budget: both passes together cost about one budget,
    // not budget x passes (the 24-pass scr_trigger shape this fixes).
    CHECK(total_keeps <= budget + 8u);

    // The overlay itself: 2 signals x 2 passes = 4 strokes, none
    // chording the reset - every stroke lives inside the frame and
    // spans the DATA extent (the auto view pads 5% a side, so the
    // data fills ~91% of the frame; a stroke spanning the whole frame
    // would be drawing past its samples).
    const std::vector<const canvas::CanvasCmd*> series = b.series_cmds();
    REQUIRE(series.size() == 4u);
    const Bench::FrameBox f = b.frame_box(b.frame_cmd());
    for (const canvas::CanvasCmd* s : series) {
        CHECK(s->points.size() <= 580u);  // the budget, per pass
        float lo = s->points.front().x;
        float hi = lo;
        for (const canvas::Point& p : s->points) {
            lo = std::min(lo, p.x);
            hi = std::max(hi, p.x);
            CHECK(p.x >= f.fx - 1.0f);
            CHECK(p.x <= f.fx2 + 1.0f);
        }
        // The stroke spans the plot's data area (frame width minus right-axis
        // margin when a right spine exists - 46px). The frame box includes
        // that margin, so allow ~60px slack instead of 8px.
        CHECK(hi - lo >= (f.fx2 - f.fx) * 0.9f - 8.0f);  // a full pass
    }
    // The window fits the runs' union envelope (the wrap's extent),
    // not the by-index run the stage-7 fallback used to draw against.
    CHECK(b.ed.results.x_runs.finite);
    CHECK(b.ed.results.x_runs.lo == 0.0);
    CHECK(b.ed.results.x_runs.hi == doctest::Approx(0.1999));
}

// ---- decimation keeps are ABSOLUTE sample positions ------------------
//
// decimate_minmax answers positions relative to the span it is handed;
// the panel hands it a SLICE (xs.subspan(i0, ...)) and the draw pushes
// the answer as table positions. These pin the rebase: a window that
// starts past sample 0, a falling run, and the later passes of a step
// family - each case where the slice start is not 0, the only case the
// older unzoomed tests could see.

namespace {

// Sets a manual x window (the y windows ride their homes) AFTER a first
// draw has keyed view_for, so handle_plot_input keeps it.
void zoom_x(Bench& b, double lo, double hi) {
    b.ed.results.view = PlotView{true, lo, hi, kHomeYLo, kHomeYHi,
                                 kHomeY1Lo, kHomeY1Hi};
}

}  // namespace

TEST_CASE("a zoomed window's keeps are absolute sample positions") {
    Bench b;
    b.load(ramp_table(20000u));  // x = 0 .. 1.9999 s, 1e-4 apart
    b.draw();                    // keys view_for
    zoom_x(b, 0.8, 1.2);         // ~4000 samples: past the ~570 budget
    b.draw();

    const std::vector<double>& xs =
        b.ed.results.run.results.tables[0].sweep_axes[0];
    REQUIRE(b.ed.results.decim.size() == 2u);
    REQUIRE(b.ed.results.decim[0].runs.size() == 1u);
    const editor::ResultsCache::RunKeep& rk =
        b.ed.results.decim[0].runs[0];
    CHECK(rk.i0 > 0u);  // the case the unzoomed tests cannot reach
    REQUIRE_FALSE(rk.idx.empty());
    CHECK(rk.idx.front() == rk.i0);      // the forced first/last keeps
    CHECK(rk.idx.back() == rk.i1 - 1u);  // sit at the slice's ends
    std::size_t prev = rk.idx.front();
    for (std::size_t k : rk.idx) {
        CHECK(k >= prev);  // ascending
        prev = k;
        REQUIRE(k >= rk.i0);
        REQUIRE(k < rk.i1);
        // Every kept sample sits in the window (one sample of slack a
        // side) - not in the head of the table.
        CHECK(xs[k] >= 0.8 - 2.0e-4);
        CHECK(xs[k] <= 1.2 + 2.0e-4);
    }

    // And the drawn strokes stay on the frame: the offset-less draw put
    // them hundreds of px left of it (the head samples, mapped through
    // the zoomed window).
    const Bench::FrameBox f = b.frame_box(b.frame_cmd());
    const std::vector<const canvas::CanvasCmd*> series = b.series_cmds();
    REQUIRE(series.size() == 2u);
    for (const canvas::CanvasCmd* s : series) {
        for (const canvas::Point& p : s->points) {
            CHECK(p.x >= f.fx - 2.0f);
            CHECK(p.x <= f.fx2 + 2.0f);
        }
    }
}

TEST_CASE("a zoomed falling run's keeps are absolute sample positions") {
    // A .dc walking its source DOWN: one falling run. The keeps are
    // decimated over the reversed sub-span (starting at j0 there) and
    // mapped home - the j0 has to ride the mapping.
    Bench b;
    ws::spice::Table t = ramp_table(20000u);
    for (std::size_t i = 0; i < t.sweep_axes[0].size(); ++i) {
        t.sweep_axes[0][i] = 1.0e-4 * static_cast<double>(19999u - i);
    }
    b.load(std::move(t));
    b.draw();
    REQUIRE(b.ed.results.x_runs.runs.size() == 1u);
    REQUIRE_FALSE(b.ed.results.x_runs.runs[0].rising);
    zoom_x(b, 0.8, 1.2);
    b.draw();

    const std::vector<double>& xs =
        b.ed.results.run.results.tables[0].sweep_axes[0];
    REQUIRE(b.ed.results.decim[0].runs.size() == 1u);
    const editor::ResultsCache::RunKeep& rk =
        b.ed.results.decim[0].runs[0];
    REQUIRE_FALSE(rk.idx.empty());
    CHECK(rk.idx.front() == rk.i0);
    CHECK(rk.idx.back() == rk.i1 - 1u);
    for (std::size_t k : rk.idx) {
        REQUIRE(k >= rk.i0);
        REQUIRE(k < rk.i1);
        CHECK(xs[k] >= 0.8 - 2.0e-4);
        CHECK(xs[k] <= 1.2 + 2.0e-4);
    }

    const Bench::FrameBox f = b.frame_box(b.frame_cmd());
    for (const canvas::CanvasCmd* s : b.series_cmds()) {
        for (const canvas::Point& p : s->points) {
            CHECK(p.x >= f.fx - 2.0f);
            CHECK(p.x <= f.fx2 + 2.0f);
        }
    }
}

TEST_CASE("every pass of a step family keeps its own samples") {
    // 4 passes x 1500 rows over the same 0..0.15 s axis: each pass
    // outruns its slice of the shared budget (~570 / 4), so each is
    // decimated - and passes 1..3 start past sample 0. v(out) is a
    // ramp over the WHOLE table, so a pass's level reads which
    // samples it drew: pass p must sit above pass p-1.
    constexpr std::size_t kPasses = 4u;
    constexpr std::size_t kRows = 1500u;
    Bench b;
    ws::spice::Table t = ramp_table(kPasses * kRows);
    for (std::size_t i = 0; i < t.sweep_axes[0].size(); ++i) {
        t.sweep_axes[0][i] = 1.0e-4 * static_cast<double>(i % kRows);
    }
    b.load(std::move(t));
    b.draw();

    REQUIRE(b.ed.results.x_runs.runs.size() == kPasses);
    REQUIRE(b.ed.results.decim[0].runs.size() == kPasses);
    for (std::size_t p = 0; p < kPasses; ++p) {
        const ws::circsim::AxisRun& run = b.ed.results.x_runs.runs[p];
        const editor::ResultsCache::RunKeep& rk =
            b.ed.results.decim[0].runs[p];
        REQUIRE_FALSE(rk.idx.empty());  // the pass IS decimated
        for (std::size_t k : rk.idx) {
            CHECK(k >= run.begin);
            CHECK(k < run.end);
        }
    }

    // The drawn passes of v(out), in pass order: each one higher on
    // the plot (smaller screen y) than the pass before it. The
    // offset-less draw gave every pass the samples of pass 0.
    std::vector<double> mean_y;
    for (const canvas::CanvasCmd* s : b.series_cmds()) {
        if (s->color != series_color(0)) {
            continue;
        }
        double sum = 0.0;
        for (const canvas::Point& p : s->points) {
            sum += static_cast<double>(p.y);
        }
        mean_y.push_back(sum / static_cast<double>(s->points.size()));
    }
    REQUIRE(mean_y.size() == kPasses);
    for (std::size_t p = 1; p < kPasses; ++p) {
        CHECK(mean_y[p] < mean_y[p - 1u] - 1.0);
    }
}

TEST_CASE("a many-signal table draws bounded series and sparklines") {
    // 48 signals x 20000 rows - the big-circuit shape the caches exist
    // for. Every series folds to the pixel budget; every legend row's
    // sparkline is the cached 40-bucket envelope (a width-1.2 stroke
    // of at most 96 points, whatever the row count).
    Bench b;
    ws::spice::Table t;
    t.analysis = ws::spice::AnalysisKind::Tran;
    t.sweep = ws::spice::SweepKind::Time;
    t.sweep_names = {"time"};
    t.sweep_axes.emplace_back();
    t.sweep_axes.back().reserve(20000u);
    for (std::size_t i = 0; i < 20000u; ++i) {
        t.sweep_axes.back().push_back(5.0e-7 * static_cast<double>(i));
    }
    for (std::size_t s = 0; s < 48u; ++s) {
        ws::spice::Signal sig;
        sig.name = "v(n" + std::to_string(1000 + s) + ")";
        sig.data.reserve(20000u);
        for (std::size_t i = 0; i < 20000u; ++i) {
            const double x = static_cast<double>(i) / 19999.0;
            sig.data.push_back(3.3 * (0.5 + 0.5 * std::sin(6.28318530718 *
                                                           x + s)));
        }
        t.signals.push_back(std::move(sig));
    }
    b.load(std::move(t));
    b.draw();

    REQUIRE(b.ed.results.stats.size() == 48u);
    for (const editor::ResultsCache::SeriesStats& st :
         b.ed.results.stats) {
        CHECK(st.finite);
        CHECK(st.spark_env.size() == 80u);
    }
    // Stage 10: the bounded plot copies. 20000 rows fold to the cap
    // per signal (one run - the axis is sorted), the envelope rides
    // the fold EXACTLY (min/max per bucket is the envelope), and the
    // decimation read the copy, not the raw column.
    // TODO: Implement copies/spark_atlas/PlotPoints (Stage 10)
    // REQUIRE(b.ed.results.copies.size() == 48u);
    // REQUIRE(b.ed.results.copies[0].runs.size() == 1u);
    // const ws::circsim::PlotPoints& cp = b.ed.results.copies[0].runs[0];
    // CHECK(cp.size() > 1000u);           // really folded, not a stub
    // CHECK(cp.size() <= 4096u + 2u);     // the cap (+ forced ends)
    // double copy_lo = cp.ys.front();
    // double copy_hi = copy_lo;
    // for (double v : cp.ys) {
    //     copy_lo = std::min(copy_lo, v);
    //     copy_hi = std::max(copy_hi, v);
    // }
    // CHECK(copy_lo == b.ed.results.stats[0].lo);  // exact - the fold
    // CHECK(copy_hi == b.ed.results.stats[0].hi);  // keeps the extremes
    // REQUIRE(b.ed.results.decim[0].runs.size() == 1u);
    // CHECK(b.ed.results.decim[0].runs[0].src == &cp);  // the source
    const std::vector<const canvas::CanvasCmd*> series = b.series_cmds();
    REQUIRE(series.size() == 48u);
    std::size_t sparklines = 0;
    for (const canvas::CanvasCmd& c : b.clc.cmds) {
        if (c.kind == canvas::CanvasCmdKind::stroke_polyline &&
            c.width == 1.2f && c.points.size() > 4u) {
            ++sparklines;
            CHECK(c.points.size() <= 96u);  // 2 per bucket, 40 buckets
        }
    }
    CHECK(sparklines == 48u);
    for (const canvas::CanvasCmd* s : series) {
        CHECK(s->points.size() <= 580u);
    }
}

// ---- the series are clipped to the plot frame ------------------------
//
// The decimation window keeps one sample of slack past each edge, so in
// a zoomed view the boundary segments run past the frame. The series
// loop sits inside one clip rect of the frame; these pin its shape on
// the recorded command stream (the canvas does the cutting).

namespace {

struct ClipPair {
    std::size_t pushes = 0;
    std::size_t pops = 0;
    std::size_t push_at = 0;  // the (last) push's index in the stream
    std::size_t pop_at = 0;
};

[[nodiscard]] ClipPair clip_pair(const Bench& b) {
    ClipPair c;
    for (std::size_t i = 0; i < b.clc.cmds.size(); ++i) {
        const canvas::CanvasCmdKind k = b.clc.cmds[i].kind;
        if (k == canvas::CanvasCmdKind::push_clip) {
            ++c.pushes;
            c.push_at = i;
        } else if (k == canvas::CanvasCmdKind::pop_clip) {
            ++c.pops;
            c.pop_at = i;
        }
    }
    return c;
}

}  // namespace

TEST_CASE("the series are drawn inside a clip of the plot frame") {
    Bench b;
    b.load(ramp_table(41u));
    b.draw();

    // One balanced pair; the rect is the plot's: non-degenerate and
    // inside the frame's box.
    const ClipPair c = clip_pair(b);
    REQUIRE(c.pushes == 1u);
    REQUIRE(c.pops == 1u);
    REQUIRE(c.push_at < c.pop_at);
    const canvas::CanvasCmd& clip = b.clc.cmds[c.push_at];
    const Bench::FrameBox f = b.frame_box(b.frame_cmd());
    CHECK(clip.w > 100.0f);
    CHECK(clip.h > 50.0f);
    CHECK(clip.x >= f.fx - 0.5f);
    CHECK(clip.y >= f.fy - 0.5f);
    CHECK(clip.x + clip.w <= f.fx2 + 0.5f);
    CHECK(clip.y + clip.h <= f.fy2 + 0.5f);

    // Every series stroke is recorded between the push and the pop.
    std::size_t seen = 0;
    for (std::size_t i = 0; i < b.clc.cmds.size(); ++i) {
        const canvas::CanvasCmd& cmd = b.clc.cmds[i];
        if (cmd.kind == canvas::CanvasCmdKind::stroke_polyline &&
            cmd.points.size() > 4u && cmd.width >= 1.5f) {
            ++seen;
            CHECK(i > c.push_at);
            CHECK(i < c.pop_at);
        }
    }
    CHECK(seen == 2u);
}

TEST_CASE("the series clip is balanced when nothing is drawn") {
    // Every signal hidden: the loop `continue`s through all of them -
    // the pair around the loop must still close.
    Bench b;
    b.load(ramp_table(41u));
    b.draw();  // keys visible_for, sizes visible
    REQUIRE(b.ed.results.visible.size() == 2u);
    b.ed.results.visible.assign(2u, 0u);
    b.draw();
    CHECK(b.series_cmds().empty());
    const ClipPair c = clip_pair(b);
    CHECK(c.pushes == 1u);
    CHECK(c.pops == 1u);
}

TEST_CASE("the sparkline atlas declines headless, the polyline rides") {
    // The stage-10 atlas bakes through r2d's texture seam, which
    // answers the white sentinel outside a running app (the
    // headless bench): the panel must keep the stage-8 polyline
    // spelling verbatim, and the atlas keys are still minted - the
    // bake (or its decline) happens once per (run, table), not per
    // frame.
    // TODO: Implement spark_atlas (Stage 10)
    // Bench b;
    // b.load(ramp_table(200u));
    // b.draw();
    // CHECK(b.ed.results.spark_atlas.texture.id == 0);
    // CHECK(b.ed.results.spark_atlas.run == b.ed.results.run_id);
    // CHECK(b.ed.results.spark_atlas.table == 0u);
    // CHECK(b.ed.results.spark_atlas.count == 2u);
    // std::size_t sparklines = 0;
    // for (const canvas::CanvasCmd& c : b.clc.cmds) {
    //     if (c.kind == canvas::CanvasCmdKind::stroke_polyline &&
    //         c.width == 1.2f && c.points.size() > 4u) {
    //         ++sparklines;
    //     }
    // }
    // CHECK(sparklines == 2u);  // the fallback drew both rows
    // // An idle frame does not re-attempt the bake: the keys hold, and
    // // the fallback still draws (the fresh frame's own count).
    // b.draw();
    // CHECK(b.ed.results.spark_atlas.run == b.ed.results.run_id);
    // std::size_t sparklines_again = 0;
    // for (const canvas::CanvasCmd& c : b.clc.cmds) {
    //     if (c.kind == canvas::CanvasCmdKind::stroke_polyline &&
    //         c.width == 1.2f && c.points.size() > 4u) {
    //         ++sparklines_again;
    //     }
    // }
    // CHECK(sparklines_again == 2u);
}

TEST_CASE("hovering a split axis lands on the nearest sample of a pass") {
    // The family axis is not sorted, so the old hover path SCANNED
    // every row per frame; stage 10 binary-searches the monotone
    // passes. The answer is the same shape: the sample whose x is
    // nearest the cursor's, somewhere in one of the passes.
    Bench b;
    ws::spice::Table wrap = ramp_table(4000u);
    for (std::size_t i = 0; i < wrap.sweep_axes[0].size(); ++i) {
        wrap.sweep_axes[0][i] =
            1.0e-4 * static_cast<double>(i < 2000u ? i : 3999u - i);
    }
    b.load(std::move(wrap));
    b.draw();  // mint the frame (and the caches) before reading it
    const Bench::FrameBox f = b.frame_box(b.frame_cmd());
    Bench::Mouse m;
    m.x = (f.fx + f.fx2) * 0.5f;  // the frame's centre column
    m.y = (f.fy + f.fy2) * 0.5f;
    b.draw(m);
    REQUIRE(b.ed.results.hover >= 0);
    const std::vector<double>& xs =
        b.ed.results.run.results.tables[0].sweep_axes[0];
    REQUIRE(static_cast<std::size_t>(b.ed.results.hover) < xs.size());
    // The centre of the padded 0..0.1999 window is ~0.1; the nearest
    // sample sits within a step or two of it, whichever pass won.
    CHECK(std::fabs(xs[static_cast<std::size_t>(b.ed.results.hover)] -
                    0.1) <= 2.0e-4);
}

TEST_CASE("the frame budget stays flat on idle frames") {
    // Opt-in perf smoke, not a gate: run with CIRCSIM_PLOT_PERF=1 to
    // see the numbers. The stage-8 contract in wall clock: the first
    // frame of a table pays the cache builds (O(signals x samples)),
    // and every idle frame after it must NOT - it maps the cached
    // keeps (O(signals x budget)). The check is the generous direction
    // (an idle frame is strictly less work than a build frame), so it
    // cannot flake on a slow machine.
    if (env_value("CIRCSIM_PLOT_PERF").empty()) {
        return;
    }
    Bench b;
    ws::spice::Table t;
    t.analysis = ws::spice::AnalysisKind::Tran;
    t.sweep = ws::spice::SweepKind::Time;
    t.sweep_names = {"time"};
    t.sweep_axes.emplace_back();
    t.sweep_axes.back().reserve(20000u);
    for (std::size_t i = 0; i < 20000u; ++i) {
        t.sweep_axes.back().push_back(5.0e-7 * static_cast<double>(i));
    }
    for (std::size_t s = 0; s < 48u; ++s) {
        ws::spice::Signal sig;
        sig.name = "v(n" + std::to_string(1000 + s) + ")";
        sig.data.reserve(20000u);
        for (std::size_t i = 0; i < 20000u; ++i) {
            const double x = static_cast<double>(i) / 19999.0;
            sig.data.push_back(3.3 * (0.5 + 0.5 * std::sin(6.28318530718 *
                                                           x + s)));
        }
        t.signals.push_back(std::move(sig));
    }
    b.load(std::move(t));

    using Clock = std::chrono::steady_clock;
    const auto draw_many = [&](int frames) {
        const auto t0 = Clock::now();
        for (int i = 0; i < frames; ++i) {
            b.draw();
        }
        return std::chrono::duration<double, std::milli>(Clock::now() - t0)
            .count();
    };
    const double build_ms = draw_many(1);   // the cache-building frame
    const double idle_ms = draw_many(30) / 30.0;
    std::printf("  perf: 48 signals x 20000 rows - build frame %.3f ms, "
                "idle frame %.3f ms (%.1fx)\n",
                build_ms, idle_ms,
                idle_ms > 0.0 ? build_ms / idle_ms : 0.0);
    CHECK(idle_ms <= build_ms);

    // The family shape (stage 10's headline): 10 signals x 24 passes
    // x 1103 rows - the scr_trigger_vfmm table's own form. Stage 9
    // gave each pass the FULL pixel budget (24 x ~500 keeps a signal
    // an idle frame); the shared budget spends ~500 total.
    ws::spice::Table fam;
    fam.analysis = ws::spice::AnalysisKind::Tran;
    fam.sweep = ws::spice::SweepKind::Time;
    fam.sweep_names = {"time"};
    fam.sweep_axes.emplace_back();
    fam.sweep_axes.back().reserve(24u * 1103u);
    for (int pass = 0; pass < 24; ++pass) {
        for (std::size_t i = 0; i < 1103u; ++i) {
            fam.sweep_axes.back().push_back(
                2.0e-5 * static_cast<double>(i));
        }
    }
    for (std::size_t s = 0; s < 10u; ++s) {
        ws::spice::Signal sig;
        sig.name = "v(n" + std::to_string(100 + s) + ")";
        sig.data.reserve(24u * 1103u);
        for (std::size_t i = 0; i < 24u * 1103u; ++i) {
            sig.data.push_back(
                3.3 * (0.5 + 0.5 * std::sin(6.28318530718 *
                                            static_cast<double>(i) /
                                            1103.0 + s)));
        }
        fam.signals.push_back(std::move(sig));
    }
    b.load(std::move(fam));
    const double fam_build = draw_many(1);
    const double fam_idle = draw_many(30) / 30.0;
    const std::size_t fam_budget = b.ed.results.decim_budget;
    std::size_t fam_keeps = 0;
    for (const editor::ResultsCache::DecimKeep& dk :
         b.ed.results.decim) {
        for (const editor::ResultsCache::RunKeep& rk : dk.runs) {
            fam_keeps += rk.idx.size();
        }
    }
    std::printf("  perf: 10 signals x 24 passes x 1103 rows - build "
                "frame %.3f ms, idle frame %.3f ms; %zu keeps total "
                "(budget %zu, one pass's full-budget share was %zu)\n",
                fam_build, fam_idle, fam_keeps, fam_budget,
                10u * 24u * fam_budget);
    // The shared-budget contract: all passes of all visible signals
    // together stay in the same order as ONE signal's old budget.
    CHECK(fam_keeps <= 10u * (fam_budget + 24u * 8u));
    CHECK(fam_idle <= fam_build);
}

// ---- the plot PNG draws one polyline per pass of the axis -----------
//
// render_plot_png used to stroke each signal's whole column as one
// polyline, so a .step family's pass resets (and any axis reset) were
// chords across the plot. The tests decode the PNG and look at pixels:
// the passes are there, the chord's midpoint is bare.

namespace {

struct PngImage {
    int w = 0;
    int h = 0;
    std::vector<unsigned char> rgb;  // w * h * 3

    // True when a pixel within `r` of (cx, cy) is within `tol` per
    // channel of `ink` (0xRRGGBB). The antialiased edge blends toward
    // the background, so the window finds the line's solid core.
    [[nodiscard]] bool near_ink(double cx, double cy, int r,
                                std::uint32_t ink, int tol = 40) const {
        const int ix = static_cast<int>(std::lround(cx));
        const int iy = static_cast<int>(std::lround(cy));
        for (int y = std::max(0, iy - r); y <= std::min(h - 1, iy + r); ++y) {
            for (int x = std::max(0, ix - r); x <= std::min(w - 1, ix + r);
                 ++x) {
                const unsigned char* p =
                    &rgb[(static_cast<std::size_t>(y) * w + x) * 3u];
                if (std::abs(int{p[0]} - static_cast<int>((ink >> 16) & 0xFFu)) <= tol &&
                    std::abs(int{p[1]} - static_cast<int>((ink >> 8) & 0xFFu)) <= tol &&
                    std::abs(int{p[2]} - static_cast<int>(ink & 0xFFu)) <= tol) {
                    return true;
                }
            }
        }
        return false;
    }
};

[[nodiscard]] PngImage decode_png(const std::string& png) {
    PngImage im;
    int comp = 0;
    unsigned char* px = stbi_load_from_memory(
        reinterpret_cast<const stbi_uc*>(png.data()),
        static_cast<int>(png.size()), &im.w, &im.h, &comp, 3);
    REQUIRE(px != nullptr);
    im.rgb.assign(px, px + static_cast<std::size_t>(im.w) * im.h * 3u);
    stbi_image_free(px);
    return im;
}

// render_plot_png's own frame (results_panel.cpp): the pixel of a data
// point, through the same padded ranges.
struct PngMap {
    ws::circsim::PlotRange px;
    ws::circsim::PlotRange py;
    PngMap(double x_lo, double x_hi, double y_lo, double y_hi)
        : px(ws::circsim::expand_range(x_lo, x_hi)),
          py(ws::circsim::expand_range(y_lo, y_hi)) {}
    [[nodiscard]] double sx(double v) const {
        return 72.0 + (v - px.lo) / (px.hi - px.lo) * (1280.0 - 72.0 - 24.0);
    }
    [[nodiscard]] double sy(double v) const {
        return 40.0 + (py.hi - v) / (py.hi - py.lo) * (720.0 - 40.0 - 48.0);
    }
};

// One v(out) signal over a time axis.
[[nodiscard]] ws::spice::Table one_signal_table(std::vector<double> xs,
                                                std::vector<double> ys) {
    ws::spice::Table t;
    t.analysis = ws::spice::AnalysisKind::Tran;
    t.sweep = ws::spice::SweepKind::Time;
    t.sweep_names = {"time"};
    t.sweep_axes.push_back(std::move(xs));
    ws::spice::Signal s;
    s.name = "v(out)";
    s.data = std::move(ys);
    t.signals.push_back(std::move(s));
    return t;
}

constexpr std::uint32_t kPngInk = 0xE05A4Eu;  // series_color(0) >> 8

}  // namespace

TEST_CASE("the plot PNG breaks a step family at each pass reset") {
    // 3 passes x 200 rows over the same 0..19.9 ms axis, pass p a flat
    // line at level p. As one polyline the reset between passes was a
    // diagonal chord from (x_end, level p) to (x_start, level p + 1).
    constexpr std::size_t kPasses = 3u;
    constexpr std::size_t kRows = 200u;
    std::vector<double> xs;
    std::vector<double> ys;
    for (std::size_t p = 0; p < kPasses; ++p) {
        for (std::size_t r = 0; r < kRows; ++r) {
            xs.push_back(1.0e-4 * static_cast<double>(r));
            ys.push_back(static_cast<double>(p));
        }
    }
    const ws::spice::Table t = one_signal_table(xs, ys);
    const PngImage im = decode_png(editor::render_plot_png(
        t, nullptr, "time", nullptr, 0u));
    REQUIRE(im.w == 1280);
    REQUIRE(im.h == 720);

    const PngMap m(0.0, 1.0e-4 * (kRows - 1u), 0.0, 2.0);
    const double x_mid = 0.5e-4 * (kRows - 1u);
    // The passes are drawn (the positive control: three flat lines)...
    for (std::size_t p = 0; p < kPasses; ++p) {
        CHECK(im.near_ink(m.sx(x_mid), m.sy(static_cast<double>(p)), 2,
                          kPngInk));
    }
    // ...and the chord between them is not: its midpoint sits half a
    // level off either line, ~140 px from any ink.
    for (std::size_t p = 0; p + 1u < kPasses; ++p) {
        CHECK_FALSE(im.near_ink(m.sx(x_mid),
                                m.sy(static_cast<double>(p) + 0.5), 4,
                                kPngInk));
    }
}

TEST_CASE("the plot PNG draws a falling axis in sample order") {
    // A .dc walking its source DOWN is one falling run: still one
    // polyline, the whole ramp (the sample at the middle sits on the
    // line).
    constexpr std::size_t kN = 201u;
    std::vector<double> xs;
    std::vector<double> ys;
    for (std::size_t i = 0; i < kN; ++i) {
        xs.push_back(1.0e-4 * static_cast<double>(kN - 1u - i));
        ys.push_back(2.0 * static_cast<double>(i) /
                     static_cast<double>(kN - 1u));
    }
    const ws::spice::Table t = one_signal_table(xs, ys);
    const PngImage im = decode_png(editor::render_plot_png(
        t, nullptr, "time", nullptr, 0u));
    const PngMap m(0.0, 1.0e-4 * (kN - 1u), 0.0, 2.0);
    CHECK(im.near_ink(m.sx(0.01), m.sy(1.0), 2, kPngInk));  // i = 100
    CHECK(im.near_ink(m.sx(0.015), m.sy(0.5), 2, kPngInk)); // i = 50
    CHECK(im.near_ink(m.sx(0.005), m.sy(1.5), 2, kPngInk)); // i = 150
}

TEST_CASE("the plot PNG breaks the line at a non-finite sample") {
    // A flat line at level 1 with sample 100's y, then (a second image)
    // its x, gone: either leaves a gap at that sample.
    constexpr std::size_t kN = 201u;
    std::vector<double> xs;
    std::vector<double> ys(kN, 1.0);
    for (std::size_t i = 0; i < kN; ++i) {
        xs.push_back(1.0e-4 * static_cast<double>(i));
    }
    const double nan = std::numeric_limits<double>::quiet_NaN();
    const PngMap m(0.0, 1.0e-4 * (kN - 1u), 0.0, 2.0);

    std::vector<double> ys_gap = ys;
    ys_gap[100] = nan;
    const PngImage by_y = decode_png(editor::render_plot_png(
        one_signal_table(xs, ys_gap), nullptr, "time", nullptr, 0u));
    CHECK(by_y.near_ink(m.sx(xs[50]), m.sy(1.0), 2, kPngInk));
    CHECK_FALSE(by_y.near_ink(m.sx(xs[100]), m.sy(1.0), 2, kPngInk));

    std::vector<double> xs_gap = xs;
    xs_gap[100] = nan;
    const PngImage by_x = decode_png(editor::render_plot_png(
        one_signal_table(xs_gap, ys), nullptr, "time", nullptr, 0u));
    CHECK(by_x.near_ink(m.sx(xs[50]), m.sy(1.0), 2, kPngInk));
    CHECK_FALSE(by_x.near_ink(m.sx(xs[100]), m.sy(1.0), 2, kPngInk));
}

// ---- legend sparklines the scroll clip hides are not drawn -----------
//
// The dock draws a panel body inside a scroll panel, which pushes its
// viewport into the gui's hit clip. A legend of dozens of signals runs
// far past the viewport; the layout still advances for every row, but a
// sparkline whose rect the clip hides entirely is not tessellated or
// submitted.

namespace {

// 48 flat signals: a flat sparkline rides the middle rail, so its first
// point sits at row.y + 7 and the rows' places read straight off it.
[[nodiscard]] ws::spice::Table flat_legend_table() {
    ws::spice::Table t;
    t.analysis = ws::spice::AnalysisKind::Tran;
    t.sweep = ws::spice::SweepKind::Time;
    t.sweep_names = {"time"};
    t.sweep_axes.emplace_back();
    for (std::size_t i = 0; i < 100u; ++i) {
        t.sweep_axes.back().push_back(1.0e-4 * static_cast<double>(i));
    }
    for (std::size_t s = 0; s < 48u; ++s) {
        ws::spice::Signal sig;
        sig.name = "v(n" + std::to_string(1000 + s) + ")";
        sig.data.assign(100u, 1.0);
        t.signals.push_back(std::move(sig));
    }
    return t;
}

// The first point's y of every legend sparkline (width 1.2), top-down.
[[nodiscard]] std::vector<float> sparkline_ys(const Bench& b) {
    std::vector<float> ys;
    for (const canvas::CanvasCmd& c : b.clc.cmds) {
        if (c.kind == canvas::CanvasCmdKind::stroke_polyline &&
            c.width == 1.2f && c.points.size() > 4u) {
            ys.push_back(c.points.front().y);
        }
    }
    return ys;
}

}  // namespace

TEST_CASE("legend sparklines the scroll clip hides are not drawn") {
    Bench all;
    all.load(flat_legend_table());
    all.draw();
    const std::vector<float> ys_all = sparkline_ys(all);
    REQUIRE(ys_all.size() == 48u);  // no clip pushed: every row draws

    // A clip over the legend's top, and one over its middle (the rows
    // above it scrolled out): exactly the rows whose 14-px sparkline
    // rect crosses the clip are drawn, in their unclipped places.
    const gui::Rect clips[] = {gui::Rect{0.0f, 0.0f, 640.0f, 200.0f},
                               gui::Rect{0.0f, 300.0f, 640.0f, 220.0f}};
    for (const gui::Rect& clip : clips) {
        std::vector<float> expected;
        for (float y : ys_all) {
            const float row_y = y - 7.0f;
            if (row_y < clip.y + clip.height && row_y + 14.0f > clip.y) {
                expected.push_back(y);
            }
        }
        REQUIRE(expected.size() > 0u);
        REQUIRE(expected.size() < 48u);

        Bench b;
        b.hit_clip = clip;
        b.load(flat_legend_table());
        b.draw();
        const std::vector<float> got = sparkline_ys(b);
        REQUIRE(got.size() == expected.size());
        for (std::size_t k = 0; k < got.size(); ++k) {
            CHECK(got[k] == doctest::Approx(expected[k]));
        }
    }
}

TEST_CASE("legend sparklines stroke with the series' join style") {
    // stroke_series' own default is the round join, so a sparkline that
    // does not pass one draws round whatever the plot's (bevel by
    // default, CIRCSIM_PLOT_JOIN to change) - ~570 quads against ~395.
    // The recorded commands carry the join: sparklines match the series.
    Bench b;
    b.load(ramp_table(41u));
    b.draw();
    const std::vector<const canvas::CanvasCmd*> series = b.series_cmds();
    REQUIRE_FALSE(series.empty());
    std::size_t sparklines = 0;
    for (const canvas::CanvasCmd& c : b.clc.cmds) {
        if (c.kind == canvas::CanvasCmdKind::stroke_polyline &&
            c.width == 1.2f && c.points.size() > 4u) {
            ++sparklines;
            CHECK(c.join == series.front()->join);
        }
    }
    CHECK(sparklines == 2u);
}

// --- the visual pass: plot card, axis ink, spectrum, swatch -------------------
//
// These cases hand the panel a synthetic face (every glyph 7 px wide) so
// the labels the canvas draws are present, then read the recorded command
// list: colors and extents, not pixels.

namespace {

[[nodiscard]] ws::ui::r2d::Font visual_test_font(GlyphTable& storage) {
    storage = glyph_table(7.0f);
    return ws::ui::r2d::Font(14.0f, 18.0f, storage.data(), 95);
}

// The bounding box height of a filled polygon command.
[[nodiscard]] float poly_height(const canvas::CanvasCmd& c) {
    float lo = c.points.front().y;
    float hi = lo;
    for (const canvas::Point& p : c.points) {
        lo = std::min(lo, p.y);
        hi = std::max(hi, p.y);
    }
    return hi - lo;
}

[[nodiscard]] std::vector<const canvas::CanvasCmd*> fills_of(
    const Bench& b, std::uint32_t color) {
    std::vector<const canvas::CanvasCmd*> out;
    for (const canvas::CanvasCmd& c : b.clc.cmds) {
        if (c.kind == canvas::CanvasCmdKind::fill_polygon &&
            c.color == color && !c.points.empty()) {
            out.push_back(&c);
        }
    }
    return out;
}

}  // namespace

TEST_CASE("visual: the plot sits on a canvas-colored card") {
    Bench b;
    b.load(ramp_table(16u));
    b.draw();
    // One fill in the canvas color: the card under the frame.
    CHECK(fills_of(b, gui::kDefaultChrome.canvas_bg).size() == 1u);
}

TEST_CASE("visual: with two spines each axis wears its series' color") {
    GlyphTable storage;
    ws::ui::r2d::Font font = visual_test_font(storage);
    Bench b;
    b.ed.font = &font;
    b.load(ramp_table(16u));  // v(out) on the left, i(V1) on the right
    b.draw();
    const std::uint32_t left = gui::dim(series_color(0), 0.92f);
    const std::uint32_t right = gui::dim(series_color(1), 0.92f);
    int left_labels = 0;
    int right_labels = 0;
    for (const canvas::CanvasCmd& c : b.clc.cmds) {
        if (c.kind != canvas::CanvasCmdKind::draw_text) {
            continue;
        }
        left_labels += c.color == left ? 1 : 0;
        right_labels += c.color == right ? 1 : 0;
    }
    CHECK(left_labels >= 2);   // the left ladder
    CHECK(right_labels >= 2);  // the right ladder
}

TEST_CASE("visual: one spine keeps neutral axis ink") {
    GlyphTable storage;
    ws::ui::r2d::Font font = visual_test_font(storage);
    Bench b;
    b.ed.font = &font;
    b.load(v_only_table(16u));  // no second axis
    b.draw();
    for (const canvas::CanvasCmd& c : b.clc.cmds) {
        if (c.kind == canvas::CanvasCmdKind::draw_text) {
            CHECK(c.color != gui::dim(series_color(0), 0.92f));
        }
    }
}

TEST_CASE("visual: the fourier spectrum draws one bar per present "
          "harmonic, scaled to the fundamental") {
    GlyphTable storage;
    ws::ui::r2d::Font font = visual_test_font(storage);
    Bench b;
    b.ed.font = &font;
    b.load(ramp_table(16u));
    b.draw();
    // The accent also fills the checked legend boxes, so the bars are
    // read as the NEW accent fills a fourier series adds.
    const std::size_t accent_before =
        fills_of(b, gui::kDefaultChrome.control_on).size();
    b.ed.results.run.fouriers.push_back(two_tone_fourier());
    b.draw();
    const std::uint32_t amber = gui::dim(gui::kDefaultChrome.toast_warning,
                                         0.95f);
    const auto accents = fills_of(b, gui::kDefaultChrome.control_on);
    const auto harmonics = fills_of(b, amber);
    // n=1 (100 %) in the accent; n=2 is 0 % and draws nothing; n=3 is
    // 20 % in amber.
    CHECK(accents.size() == accent_before + 1u);
    REQUIRE(harmonics.size() == 1u);
    // The fundamental is the tallest accent fill (a checkbox is ~24 px).
    float tallest = 0.0f;
    for (const canvas::CanvasCmd* c : accents) {
        tallest = std::max(tallest, poly_height(*c));
    }
    CHECK(tallest > 50.0f);
    CHECK(poly_height(*harmonics[0]) / tallest ==
          doctest::Approx(0.20f).epsilon(0.05));
}

TEST_CASE("visual: no face, no spectrum (and nothing crashes)") {
    Bench b;  // ed.font stays null
    b.load(ramp_table(16u));
    b.ed.results.run.fouriers.push_back(two_tone_fourier());
    b.draw();
    CHECK(fills_of(b, gui::dim(gui::kDefaultChrome.toast_warning, 0.95f))
              .empty());
}

TEST_CASE("visual: a failed or .op fourier series draws no spectrum") {
    GlyphTable storage;
    ws::ui::r2d::Font font = visual_test_font(storage);
    Bench b;
    b.ed.font = &font;
    b.load(ramp_table(16u));
    b.draw();
    const std::size_t before = b.clc.cmds.size();
    ws::spice::Fourier f;  // no harmonics: the .op shape
    f.signal = "v(out)";
    f.analysis = ".tran";
    f.dc = 1.0;
    b.ed.results.run.fouriers.push_back(std::move(f));
    b.draw();
    // The same canvas commands as before: the section's rows ride the
    // text seam, and nothing here may add a bar.
    CHECK(b.clc.cmds.size() == before);
}

// ---- a plot the scroll clip hides skips its series -------------------
//
// A long legend runs the plot down past the dock's scroll viewport. The
// frame, ticks and overlays are cheap; the series are the expensive
// part (decimate, tessellate-or-hit, ~2.8k quads a signal submitted).
// With the frame entirely outside the clip the series loop is skipped.

TEST_CASE("a plot frame the scroll clip hides draws no series") {
    Bench probe;
    probe.load(ramp_table(41u));
    probe.draw();
    const Bench::FrameBox f = probe.frame_box(probe.frame_cmd());
    REQUIRE(probe.series_cmds().size() == 2u);  // no clip: drawn

    // Hidden: the clip ends above the frame (and exactly at its top -
    // the clip is half-open, a touching edge shows nothing).
    for (float bottom : {f.fy - 5.0f, f.fy}) {
        Bench b;
        b.hit_clip = gui::Rect{0.0f, 0.0f, 640.0f, bottom};
        b.load(ramp_table(41u));
        b.draw();
        CHECK(b.series_cmds().empty());
        CHECK(b.frame_cmd() != nullptr);  // the frame itself still draws
    }

    // Shown: a clip that overlaps the frame by even a few px, or one
    // that holds all of it, draws the series.
    for (float bottom : {f.fy + 4.0f, f.fy2 + 50.0f}) {
        Bench b;
        b.hit_clip = gui::Rect{0.0f, 0.0f, 640.0f, bottom};
        b.load(ramp_table(41u));
        b.draw();
        CHECK(b.series_cmds().size() == 2u);
    }
}
