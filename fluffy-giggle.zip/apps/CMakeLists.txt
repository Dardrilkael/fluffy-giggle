# Apps are added here, one line each. Like libs/ (see libs/CMakeLists.txt),
# each app is gated on its whole lib set being configured: in a WS_BUILD_LIBS
# subset build an app appears iff every ws::<lib> it links exists, so e.g. the
# spice-only preset builds apps/spice and nothing else. The call sites spell
# "app, lib, lib, ..." - the app name rides ARGN's front for readability and
# is skipped by the check.
function(ws_app_wants out)
  set(want TRUE)
  if(WS_BUILD_LIBS)
    list(POP_FRONT ARGN)  # the app name, not a lib to check
    foreach(lib IN LISTS ARGN)
      if(NOT lib IN_LIST WS_ALL_LIBS)
        set(want FALSE)
      endif()
    endforeach()
  endif()
  set(${out} ${want} PARENT_SCOPE)
endfunction()

# One ws_want_<app> variable per app (CMake's if() cannot call functions).
# (playground's sound panel links ws::audio on top of ws_add_app's ui - the
# gate lists the whole set, the gating's own contract.)
ws_app_wants(_want playground ui audio)
set(ws_want_playground ${_want})
ws_app_wants(_want chatter ui net)
set(ws_want_chatter ${_want})
ws_app_wants(_want bounce physics audio ui)
set(ws_want_bounce ${_want})
ws_app_wants(_want ui_gallery ui jobs platform app)
set(ws_want_ui_gallery ${_want})
ws_app_wants(_want shell_example ui jobs platform app)
set(ws_want_shell_example ${_want})
ws_app_wants(_want wavplayer audio)
set(ws_want_wavplayer ${_want})
ws_app_wants(_want netdemo net)
set(ws_want_netdemo ${_want})
ws_app_wants(_want netchat net)
set(ws_want_netchat ${_want})
ws_app_wants(_want bench_physics physics)
set(ws_want_bench_physics ${_want})
ws_app_wants(_want spice spice)
set(ws_want_spice ${_want})
ws_app_wants(_want circsim_cli circsim)
set(ws_want_circsim_cli ${_want})
ws_app_wants(_want circsim_editor ui circsim jobs platform app settings)
set(ws_want_circsim_editor ${_want})
ws_app_wants(_want schematic_test ui schematic jobs platform app settings)
set(ws_want_schematic_test ${_want})
ws_app_wants(_want glyph_probe ui)
set(ws_want_glyph_probe ${_want})
unset(_want)

if(ws_want_playground)
  add_subdirectory(playground)
endif()
# chatter is a gui app too (netchat's protocol behind a palette gui, built
# for the phone and the desktop alike), so it stays ungated like
# playground - only the console apps below are desktop-only.
if(ws_want_chatter)
  add_subdirectory(chatter)
endif()
if(ws_want_bounce)
  # bounce is the first windowed example to compose three libs: a
  # ws::physics2d pit drawn through ws::ui, with ws::audio thuds on impact.
  add_subdirectory(bounce)
endif()
if(ws_want_ui_gallery AND NOT (UNIX AND NOT APPLE))
  # ui_gallery is the gui widget set's acceptance view: one screen with every
  # ws::ui::gui widget family on it, no assets (the system font face, resolved
  # at the platform boundary), so it builds for the phone and the desktop
  # unchanged - ungated for the same reason as the gui apps above. The one
  # build it cannot make is a posix DESKTOP one: its platform page exercises
  # the OS halves (the native dialogs, the message boxes, the clipboard, the
  # single-instance grab) whose TUs exist only for Windows and Android - the
  # workspace's shipped platforms. Excluded there rather than stubbed: the
  # page's whole point is the real OS round trips.
  add_subdirectory(ui_gallery)
endif()
if(NOT ANDROID AND ws_want_shell_example)
  # shell_example is the stage-15 acceptance app: a text-and-plot
  # scratchpad built ONLY from AppShell (two panels - an editor and a
  # plot fed by a background job - a document type, a few commands and
  # a settings schema). Desktop console-style gui app like the gallery.
  add_subdirectory(shell_example)
endif()
if(NOT ANDROID)
  if(ws_want_wavplayer)
    # ws::audio builds on Android too (its engine pimpl is OpenAL Soft on both
    # platforms), but wavplayer is a desktop CONSOLE app - a main() that pumps
    # update()/is_playing() with stdout logging - so the app stays gated.
    add_subdirectory(wavplayer)
  endif()
  if(ws_want_netdemo)
    # netdemo is the same kind of console app - ws::net traffic narrated
    # through ws::core logs.
    add_subdirectory(netdemo)
  endif()
  if(ws_want_netchat)
    # netchat too: several terminals (or machines) find each other over
    # discovery and exchange framed text over TCP.
    add_subdirectory(netchat)
  endif()
  if(ws_want_bench_physics)
    # bench_physics is the fourth console app: steps a falling-boxes scene in
    # ws::physics and prints per-tick wall-clock cost per dimension/backend.
    add_subdirectory(bench_physics)
  endif()
  if(ws_want_spice)
    # spice is the ws::spice CLI: parse -> simulate -> write, nothing else.
    add_subdirectory(spice)
    # spice_example is a tiny embedding: hardcoded RC deck -> v(out) +
    # .meas to stdout. The smallest possible ws::spice C++ program. Built
    # wherever the spice lib is (so the spice subset preset gets it too).
    add_subdirectory(spice_example)
  endif()
  if(ws_want_circsim_cli)
    # circsim_cli is the ws::circsim front door: load a .csim, run an
    # analysis through ws::circsim -> ws::spice, write CSV/JSON (plus erc
    # and netlist subcommands). Desktop console app like apps/spice.
    add_subdirectory(circsim_cli)
  endif()
endif()

if(ws_want_circsim_editor)
  # circsim_editor is the stage-3 acceptance app: the schematic editor
  # (place/move/rotate/mirror parts, wire routing, the property grid,
  # the problems panel, the netlist view) over AppShell + ws::circsim.
  # A phone app too now (the android port): android_main hands the
  # glue's handle to the shell, the activity's paths answer Locations,
  # and the file pickers ride the Storage Access Framework through the
  # app TU's bridge - the pickers' worker dispatch and the touch
  # ->mouse bridge the window layer already owns.
  add_subdirectory(circsim_editor)
endif()

if(ws_want_schematic_test)
  # schematic_test is a minimal test app: schematic + canvas wiring.
  # Simple rectangular components with pins that can be wired together.
  # Uses ws::schematic (the headless routing core) + ws::ui::canvas directly.
  add_subdirectory(schematic_test)
endif()

if(ws_want_glyph_probe)
  # glyph_probe is the text contrast acceptance view: a full-screen text
  # rendering test that exercises the shader-based contrast curve across
  # all theme colors (light/dark text on light/dark backgrounds) with
  # live sliders for gamma/boost overrides. No assets: system font only.
  add_subdirectory(glyph_probe)
endif()
